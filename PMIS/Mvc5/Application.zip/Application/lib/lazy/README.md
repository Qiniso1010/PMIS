jQuery.Lazy();
==============

a delayed image loading plugin for jQuery

See documentation, examples and other information on:
[http://jquery.eisbehr.de/lazy](http://jquery.eisbehr.de/lazy/)
