$(function() {
    // var router = new AppRouter();
        
    // var default_route = new DefaultRouter(router);
});