/// <reference path="lib/jquery.slimscroll.min.js" />
require.config({

    baseUrl: '../Scripts/App/lib', 
    urlArgs: (new Date()).getTime(),
    waitSeconds: 200,
    paths: {
        app: '../app'
    },
    map: {
        "*": {
            "$": "noconflict"
        },
        "noconflict": {
            "$": "jquery"
        }
    },
    shim: {
        'jquery' : {
            exports : 'jquery'
        },
        'backbone': {
            deps: ['underscore', 'jquery'],
            exports: 'Backbone'
        },
        'underscore': {
            exports: '_'
        },
        'handlebars': {
            exports: 'Handlebars'
        },
        'bootstrap.min': {
            deps: ["jquery"],
            exports: 'Bootstrap'
        },
        'modernizr-2.8.3': {
            deps: ["jquery"],
            exports: 'Modernizr'
        },
        'jquery.slimscroll.min': {
            deps: ["jquery"],
            exports: 'AdminLTE'
        },
        'AdminLTE': {
            deps: ["jquery","bootstrap.min","jquery.slimscroll.min"],
            exports: 'AdminLTE'
        },
        'moment': {
            deps: ["jquery"],
            exports: 'Moment'
        },
        'icheck': {
            deps: ["jquery","bootstrap.min"],
            exports: 'iCheck'
        },
        'bootstrap-table/src/bootstrap-table' : {
             deps: ["jquery","bootstrap.min"],
             exports:'bootstrapTable'
        },
        'bootstrap-table/src/extensions/export/bootstrap-table-export' : {
             deps: ["jquery","jquery.base64","tableExport","bootstrap.min","bootstrap-table/src/bootstrap-table"],
             exports:'bootstrapTableExport'
        },

    }
});

require(
    [
        'backbone',
        'AdminLTE',
        'jquery.slimscroll.min',
        'app/router',
        'app/DefaultRouter',
        'app/AgendaRouter',
        'app/NaskahRouter',
        'app/ArsipRouter',
        'app/LaporanRouter',
        'app/DashboardRouter'
    ],
    function (Backbone,AdminLTE,slimscroll,Router,DefaultRouter,AgendaRouter,NaskahRouter,ArsipRouter,LaporanRouter,DashboardRouter) {
        var router = new Router();
        
        var default_route = new DefaultRouter.Init(router);
        var agenda = new AgendaRouter.Init(router);
        var naskah = new NaskahRouter.Init(router);
        var arsip = new ArsipRouter.Init(router);
        var laporan = new LaporanRouter.Init(router);
        var dashboard = new DashboardRouter.Init(router);
        
        Backbone.history.start();
        Backbone.Router.namedParameters = true;
});


