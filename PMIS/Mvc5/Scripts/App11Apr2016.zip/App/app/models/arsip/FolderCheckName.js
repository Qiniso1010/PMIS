define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        FolderCheckName = Backbone.Model.extend({
            urlRoot:"Files/CheckName/",
            defaults: {
                status:null
            }

        }),

        FolderCheckNameCollection = Backbone.Collection.extend({
            model: FolderCheckName,
            url:"Files/CheckName/"
        });

    return {
        FolderCheckName: FolderCheckName,
        FolderCheckNameCollection: FolderCheckNameCollection
    };

});