define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        RenderUsers = Backbone.Model.extend({
            urlRoot:"Units/GetSuratToUnit/",
            defaults: {
                status:null
            }

        }),

        RenderUsersColl = Backbone.Collection.extend({
            model: RenderUsers
        });

    return {
        RenderUsers: RenderUsers,
        RenderUsersColl: RenderUsersColl
    };

});