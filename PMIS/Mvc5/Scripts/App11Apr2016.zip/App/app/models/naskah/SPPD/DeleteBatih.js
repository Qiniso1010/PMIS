define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        DeleteBatih = Backbone.Model.extend({
            urlRoot:"Batihs/DeleteBatih/"

        }),

        DeleteBatihColl = Backbone.Collection.extend({
            model: DeleteBatih
        });

    return {
        DeleteBatih: DeleteBatih,
        DeleteBatihColl: DeleteBatihColl
    };

});