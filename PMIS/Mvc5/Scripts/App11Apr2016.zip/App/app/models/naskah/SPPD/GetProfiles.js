define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetProfiles = Backbone.Model.extend({
            urlRoot:"Dinas/ProfilesList/",
            defaults: {
                status:null
            }

        }),

        GetProfilesColl = Backbone.Collection.extend({
            model: GetProfiles
        });

    return {
        GetProfiles: GetProfiles,
        GetProfilesColl: GetProfilesColl
    };

});