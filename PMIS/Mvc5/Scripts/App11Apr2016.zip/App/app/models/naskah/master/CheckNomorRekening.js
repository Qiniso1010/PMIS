define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        CheckNomorRekening = Backbone.Model.extend({
            urlRoot:"Rekenings/CheckName/",
            defaults: {
                status:null
            }

        }),

        CheckNomorRekeningColl = Backbone.Collection.extend({
            model: CheckNomorRekening
        });

    return {
        CheckNomorRekening: CheckNomorRekening,
        CheckNomorRekeningColl: CheckNomorRekeningColl
    };

});