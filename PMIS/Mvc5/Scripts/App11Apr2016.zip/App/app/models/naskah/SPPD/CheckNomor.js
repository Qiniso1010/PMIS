define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        CheckNomor = Backbone.Model.extend({
            urlRoot:"Dinas/CheckNomor/",
            defaults: {
                status:null
            }

        }),

        CheckNomorColl = Backbone.Collection.extend({
            model: CheckNomor
        });

    return {
        CheckNomor: CheckNomor,
        CheckNomorColl: CheckNomorColl
    };

});