define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        RenderPegawaiAndBatih = Backbone.Model.extend({
            urlRoot:"Dinas/ListProfileSppd/",
            defaults: {
                status:null
            }

        }),

        RenderPegawaiAndBatihColl = Backbone.Collection.extend({
            model: RenderPegawaiAndBatih
        });

    return {
        RenderPegawaiAndBatih: RenderPegawaiAndBatih,
        RenderPegawaiAndBatihColl: RenderPegawaiAndBatihColl
    };

});