define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetNaskah = Backbone.Model.extend({
            urlRoot:"LaporanDocs/DetailDoc/",
            defaults: {
                status:null
            }

        }),

        GetNaskahColl = Backbone.Collection.extend({
            model: GetNaskah,
            url:"LaporanDocs/DetailDoc/"
        });

    return {
        GetNaskah: GetNaskah,
        GetNaskahColl: GetNaskahColl
    };

});