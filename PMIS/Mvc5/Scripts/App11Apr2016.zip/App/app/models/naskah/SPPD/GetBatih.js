define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetBatih = Backbone.Model.extend({
            urlRoot:"Batihs/GetBatih",
            defaults: {
                status:null
            }

        }),

        GetBatihColl = Backbone.Collection.extend({
            model: GetBatih
        });

    return {
        GetBatih: GetBatih,
        GetBatihColl: GetBatihColl
    };

});