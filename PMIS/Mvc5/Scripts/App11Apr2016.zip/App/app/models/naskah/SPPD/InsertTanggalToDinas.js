define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        InsertTanggalToDinas = Backbone.Model.extend({
            urlRoot:"Dinas/InsertTanggalToDinas/"

        }),

        InsertTanggalToDinasColl = Backbone.Collection.extend({
            model: InsertTanggalToDinas
        });

    return {
        InsertTanggalToDinas: InsertTanggalToDinas,
        InsertTanggalToDinasColl: InsertTanggalToDinasColl
    };

});