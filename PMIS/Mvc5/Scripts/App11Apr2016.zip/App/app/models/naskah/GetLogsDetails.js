define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetLogsDetails = Backbone.Model.extend({
            urlRoot:"LaporanDocLogs/Details/",
            defaults: {
                status:null
            }

        }),

        GetLogsDetailsColl = Backbone.Collection.extend({
            model: GetLogsDetails,
            url:"LaporanDocLogs/Details/"
        });

    return {
        GetLogsDetails: GetLogsDetails,
        GetLogsDetailsColl: GetLogsDetailsColl
    };

});