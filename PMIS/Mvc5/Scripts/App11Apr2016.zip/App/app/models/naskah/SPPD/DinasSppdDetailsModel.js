define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        DinasSppdDetailsModel = Backbone.Model.extend({
            urlRoot:"Dinas/Details/"

        }),

        DinasSppdDetailsModelColl = Backbone.Collection.extend({
            model: DinasDetailsModel
        });

    return {
        DinasSppdDetailsModel: DinasSppdDetailsModel,
        DinasSppdDetailsModelColl: DinasSppdDetailsModelColl
    };

});