define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        CategoryEditModel = Backbone.Model.extend({

            urlRoot:"Categories/Edit/",
            initialize:function () {
                this.dat = new CategoryEditCollection();
                this.dat.url = this.urlRoot + "/" + this.id;
            },
            defaults: {
                ModuleId: null,
                Name:null
            }

        }),

       CategoryEditCollection = Backbone.Collection.extend({

            model: CategoryEditCollection,
            url: "Categories/Edit/",

        });

    return {
        CategoryEditModel: CategoryEditModel,
        CategoryEditCollection: CategoryEditCollection
    };

});