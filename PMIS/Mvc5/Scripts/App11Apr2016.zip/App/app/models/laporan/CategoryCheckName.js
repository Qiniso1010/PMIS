define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        CategoryCheckName = Backbone.Model.extend({
            urlRoot:"Categories/CheckName/",
            defaults: {
                status:null
            }

        }),

        CategoryCheckNameCollection = Backbone.Collection.extend({
            model: CategoryCheckName,
            url:"Categories/CheckName/"
        });

    return {
        CategoryCheckName: CategoryCheckName,
        CategoryCheckNameCollection: CategoryCheckNameCollection
    };

});