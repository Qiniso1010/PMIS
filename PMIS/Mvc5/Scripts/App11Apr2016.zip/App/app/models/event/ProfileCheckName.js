define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        ProfileCheckName = Backbone.Model.extend({
            urlRoot:"Profiles/CheckName/",
            defaults: {
                status:null
            }

        }),

        ProfileCheckNameColl = Backbone.Collection.extend({
            model: ProfileCheckName,
            url:"Profiles/CheckName/"
        });

    return {
        ProfileCheckName: ProfileCheckName,
        ProfileCheckNameColl: ProfileCheckNameColl
    };

});