define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        AgendaPimpinanViewModel = Backbone.Model.extend({
            urlRoot:"AgendaPimpinan/Details/",
            defaults: {
                status:null
            }

        }),

        AgendaPimpinanViewModelColl = Backbone.Collection.extend({
            model: AgendaPimpinanViewModel,
            url:"AgendaPimpinan/Details/"
        });

    return {
        AgendaPimpinanViewModel : AgendaPimpinanViewModel,
        AgendaPimpinanViewModelColl: AgendaPimpinanViewModelColl
    };

});