define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        BatihDeleteModel = Backbone.Model.extend({
            urlRoot:"Batihs/Delete/",
            defaults: {
                status:null
            }

        }),

        BatihDeleteModelColl = Backbone.Collection.extend({
            model: BatihDeleteModel,
        });

    return {
        BatihDeleteModel : BatihDeleteModel,
        BatihDeleteModelColl: BatihDeleteModelColl
    };

});