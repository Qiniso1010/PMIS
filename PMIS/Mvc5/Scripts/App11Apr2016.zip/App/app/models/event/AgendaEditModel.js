define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        AgendaEditModel = Backbone.Model.extend({
            urlRoot:"Schedules/Edit/",
            defaults: {
                status:null
            }

        }),

        AgendaEditModelColl = Backbone.Collection.extend({
            model: AgendaEditModel,
            url:"Schedules/Edit/"
        });

    return {
        AgendaEditModel : AgendaEditModel,
        AgendaEditModelColl: AgendaEditModelColl
    };

});