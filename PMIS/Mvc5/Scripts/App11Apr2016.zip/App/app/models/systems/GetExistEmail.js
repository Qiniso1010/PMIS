define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetExistEmail = Backbone.Model.extend({
            urlRoot:"Users/CheckEmailExist/",
            defaults: {
                status:null
            }

        }),

        GetExistEmailCollection = Backbone.Collection.extend({
            model: GetExistEmail,
            url:"Users/CheckEmailExist/"
        });

    return {
        GetExistEmail: GetExistEmail,
        GetExistEmailCollection: GetExistEmailCollection
    };

});