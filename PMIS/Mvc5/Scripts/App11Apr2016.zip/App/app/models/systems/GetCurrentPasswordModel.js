define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetCurrentPasswordModel = Backbone.Model.extend({

            urlRoot:"users/GetCurrentPassword",
            defaults: {
                status:null
            }

        }),

        GetCurrentPasswordCollection = Backbone.Collection.extend({

            model: GetCurrentPasswordModel,
            url:"users/GetCurrentPassword"

        });

    return {
        GetCurrentPasswordModel: GetCurrentPasswordModel,
        GetCurrentPasswordCollection: GetCurrentPasswordCollection
    };

});