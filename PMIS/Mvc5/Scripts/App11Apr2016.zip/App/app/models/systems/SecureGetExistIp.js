define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetExistIp = Backbone.Model.extend({
            urlRoot:"secure/get_exists_ip",
            defaults: {
                status:null
            }

        }),

        GetExistIpCollection = Backbone.Collection.extend({
            model: GetExistIp,
            url:"secure/get_exists_ip"
        });

    return {
        GetExistIp: GetExistIp,
        GetExistIpCollection: GetExistIpCollection
    };

});