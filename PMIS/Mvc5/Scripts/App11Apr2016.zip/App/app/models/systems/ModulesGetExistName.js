define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetExistName = Backbone.Model.extend({
            urlRoot:"Modules/CheckName/",
            defaults: {
                status:null
            }

        }),

        GetExistNameCollection = Backbone.Collection.extend({
            model: GetExistName,
            url:"Modules/CheckName/"
        });

    return {
        GetExistName: GetExistName,
        GetExistNameCollection: GetExistNameCollection
    };

});