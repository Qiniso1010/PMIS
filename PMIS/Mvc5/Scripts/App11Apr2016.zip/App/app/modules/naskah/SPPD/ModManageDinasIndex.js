define(function (require) {
    var Utility             = require('utility'),
        bootstrapTable      = require('bootstrap-table/dist/bootstrap-table.min')

    return {
        Index: function () {

            // Top Nav
            this.Nav();
            // table
            this.Table();
            // caption form
            this.Caption();
            // Delete 
            this.Delete();
            
            // Validasi
            this.Validasi();
            

        },
        Nav: function () {
            // action
            var htm = "";
            htm += "<li class='nav-role'><a href='#/naskah/dinas/spt/new' id='btnUpload' role='button'> <i class='icon ion-ios-copy-outline'></i> Buat SPT </a></li>";

            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnDelete' role='button'> <i class='icon ion-ios-close-outline'></i> Delete </a></li>";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnValidasi' role='button'> <i class='icon ion-ios-checkmark-outline'></i> Validasi SPT? </a></li>";

            $("#navigasi").html(htm);
            // end nav top


            // hide action button
            $("#btnDelete").hide();
            $("#btnValidasi").hide();
        },
        Caption: function() {
            // define title constant
            var appname = "Manage Perjalanan Dinas";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("manage-perjalanan-dinas");
            Utility.SelectedToogleItem("perjalanan-dinas"); // parent

            $("#h1-header").html(appname+ "<small>Manage All Document Perjalanan Dinas</small>");
            $("#header-page").html(appname);

            // refresh
            $("#btnRefresh").on("click", function () {
                $('#listing-grid').bootstrapTable('refresh');
            });
        },
        Table: function() {
            // listing
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Dinas/',
                cache: false,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: true,
                showRefresh: true,
                cardView: false,
                showToggle: true,
                showExport: true,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [{
                    field: 'stat',
                    checkbox: true
                }, {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, 
                {
                    field: 'Kode',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'Nomor',
                    title: 'Nomor',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'NomorAndId',
                    title: 'Maksud / Perihal',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'Tanggal',
                    title: 'Tanggal Berangkat',
                    align: 'right',
                    valign: 'middle',
                    visible: true
                },
                {
                    field: 'IsRead',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    visible: false
                },
                {
                    field: 'IsValidate',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    visible: false
                },
                {
                    field: 'TypeDoc',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    visible: false
                },
                {
                    field: 'PemberiPerintah',
                    title: 'Memberi Tugas',
                    align: 'right',
                    valign: 'middle',
                    sortable: true
                }, 
                {
                    field: 'NomorAndId',
                    title: '',
                    align: 'right',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Information'
                },],
                onCheck: function (row) {
                    $("#btnDelete").show();
                    $("#btnValidasi").show();
                },
                onUncheck: function (row) {
                    $("#btnDelete").hide();
                    $("#btnValidasi").hide();
                },
                onCheckAll: function () {
                    $("#btnDelete").show();
                    $("#btnValidasi").show();
                },
                onUncheckAll: function () {
                    $("#btnDelete").hide();
                    $("#btnValidasi").hide();
                },
                onLoadError: function(err) {
                    alert(err);
                }
            });
        },
        Delete: function () {

            /// delete button action
            $("#btnDelete").on("click", function () {
                Delete();
            });

            // delete
            function Delete() {
                swal({
                    title: "Yakin ingin menghapus Dokumen ini?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                DeleteAction(param[i].Id, param[i].IsRead,param[i].IsValidate);
                            }

                            $("#btnDelete").hide();

                            Utility.prosesLoad("N");
                            Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            var token = $('input[name="__RequestVerificationToken"]').val();

            // delete action
            function DeleteAction(id, isread,isvalidated) {
                if (isread == false || isvalidated == false) {
                    var param = {
                        id: id,
                        __RequestVerificationToken: token,
                    }
                    var url = 'Dinas/Delete/';
                    
                    $.ajax({
                        url: url,
                        cache: false,
                        type: 'POST',
                        data: param,
                        dataType: 'json',
                        success: function (d) {
                            if (d.Attr == "Ok!") {
                                Utility.AlertV2("check", d.Message, "success");
                            } else {
                                Utility.AlertV2("remove", d.Message, "error");
                            }

                            $('#listing-grid').bootstrapTable('refresh');
                        },
                        error: function (err) {
                            alert(err.responseText);
                        }
                    });
                } else {
                    swal('Error!',"Tidak dapat menghapus data ini, dikarenakan data sudah terbaca atau diproses","error");
                }
               
               
            }
            // end action
        },
        Validasi: function () {

            $("#btnValidasi").on("click", function () {
                Validasi();
            });

            // validasi
            function Validasi() {
                swal({
                    title: "Yakin ingin validasi SPT yang dipilih?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                ValidasiAction(param[i].Id, param[i].IsValidate,param[i].TypeDoc);
                            }

                            $("#btnValidasi").hide();

                            Utility.prosesLoad("N");
                            Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            var token = $('input[name="__RequestVerificationToken"]').val();

            // delete action
            function ValidasiAction(id, isvalidated,tipe) {
                if (isvalidated == false) {
                    var param = {
                        DinasId: id,
                        TypeDoc:'SPT',
                        __RequestVerificationToken: token,
                    }
                    var url = 'Dinas/Validasi/';
                    
                    $.ajax({
                        url: url,
                        cache: false,
                        type: 'POST',
                        data: param,
                        dataType: 'json',
                        success: function (d) {
                            if (d.Attr == "Ok!") {
                                Utility.AlertV2("check", d.Message, "success");
                            } else {
                                Utility.AlertV2("remove", d.Message, "error");
                            }

                            $('#listing-grid').bootstrapTable('refresh');
                        },
                        error: function (err) {
                            alert(err.responseText);
                        }
                    });
                } else {
                    Utility.AlertV2("remove","Dokumen telah di proses / validasi", "error");
                }
               
               
            }
            // end action
        }

    };
});
