
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function(id,name) {
             
            Utility.SelectedMenuItem("manage");
            Utility.SelectedToogleItem("tata-naskah-dinas");

            $("#title-header").html("Membuat Tata Naskah Dinas - " + name);

            $("#h1-header").html("Membuat Tata Naskah Dinas - "+ name + " <small>Isikan dengan lengkap kolom dibawah ini.</small>");
            $("#header-page").html("Membuat Tata Naskah Dinas - "+ name);

            // action
            var htm = "";
            htm += "<li class='nav-users'><a href='#/naskah/index/sub/"+id+"/"+name+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";

            $("#navigasi").html(htm);


            Utility.IsLoading("#loading", "hide");
            
        }  
    };
});