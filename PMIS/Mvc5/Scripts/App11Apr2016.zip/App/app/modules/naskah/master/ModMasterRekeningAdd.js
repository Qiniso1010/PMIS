
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function() {
             
            Utility.SelectedMenuItem("master-rekening");
            Utility.SelectedToogleItem("tata-naskah-dinas");
            
            var AppName = "Membuat Rekening Baru";

            $("#title-header").html(AppName);

            $("#h1-header").html(AppName +  "<small>Membuat Rekening beserta Uraiannya.</small>");
            $("#header-page").html(AppName);

            // action
            var htm = "";
            htm += "<li class='nav-users'><a href='#/naskah/master/rekening' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";

            $("#navigasi").html(htm);
            Utility.IsLoading("#loading", "hide");
            
        }  
    };
});