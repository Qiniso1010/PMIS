
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function() {
             
            // menu
            Utility.SelectedMenuItem("Edit Kategori");
            Utility.SelectedToogleItem("manage");

            $("#title-header").html("Edit Kategori");

            $("#h1-header").html("Kategori <small>Edit</small>");
            $("#header-page").html("Edit Kategori");
            
            // action
            var htm = "";
            htm += "<li class='nav-roles'><a href='#/naskah/index' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
            $("#navigasi").html(htm);
            // loading
            Utility.IsLoading("#loading", "hide");   
            
        }
       
    };
});