define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min'),
        NProgress           = require('/Scripts/nprogress.js')

    return {
        Index: function (params) {
            // table
            this.Table();
            // caption form
            this.Caption();

            this.Nav();

        },
        Nav: function() {
            var IsDefault = $('input[name="IsDefault"]').val();
            var htm = "";
            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";

            $("#navigasi").html(htm);

            // refresh
            $("#btnRefresh").on("click", function () {
                $('#listing-grid').bootstrapTable('refresh');
            });

            $('#btnApprove').hide();
            $('#btnReject').hide();
        },
        Caption: function() {
            // define title constant
            var appname = "Manage Agenda Ruang Rapat";

            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("manage-agenda");
            Utility.SelectedToogleItem("ruang-rapat"); // parent

            $("#h1-header").html(appname + "<small>Listing Agenda</small>");
            $("#header-page").html(appname);

        },
        Table: function() {
            
            NProgress.start();
            // listing
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Books/AgendaKu/?Type=room',
                cache: false,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: false,
                showRefresh: true,
                cardView: false,
                showToggle: false,
                showExport: false,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [{
                    field: 'stat',
                    checkbox: true
                }, {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                },
                {
                    field: 'NameAndId',
                    title: 'Title',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'Tanggal',
                    title: 'Tanggal',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'CreatedBy',
                    title: 'Dibuat Oleh',
                    align: 'right',
                    valign: 'middle',
                    sortable: true
                }],
                onCheck: function (row) {
                    $("#btnApprove").show();
                    $("#btnReject").show();
                },
                onUncheck: function (row) {
                    $("#btnApprove").hide();
                    $("#btnReject").hide();
                },
                onCheckAll: function () {
                    $("#btnApprove").show();
                    $("#btnReject").show();
                },
                onUncheckAll: function () {
                    $("#btnApprove").hide();
                    $("#btnReject").hide();
                },
                onLoadSuccess: function() {
                    NProgress.done();
                }
            });
        }


    };
});
