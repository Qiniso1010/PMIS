define(function (require) {
    var $       = require('jquery'),
        Utility = require('utility'),
        table = require('bootstrap-table/dist/bootstrap-table.min'),
        highcharts = require('/Scripts/Highcharts/js/highcharts.js')

    return {
        Index: function (params) {
            
            // caption form
            this.Caption();
            
            this.Nav();
            
            // table
            // this.Chart();
            
            Utility.IsLoading("#loading", "hide");
            
        },
        Nav: function() {
            
            var htm = "";
            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
           
            $("#navigasi").html(htm); 
            
            $('#btnRefresh').click(function(e) {
               location.reload(); 
            });
            
        },
        Caption: function() {
            // define title constant
            var appname = "Dashboard";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("dashboard-menu");
            Utility.SelectedToogleItem("dashboard-menu"); // parent

            $("#h1-header").html(appname + "<small>Laporan Aplikasi</small>");
            $("#header-page").html(appname);

        },
        Chart: function() {
            // this.RenderDate();
            // var tanggal = "";
            // this.RenderDate(function(output){
            //     tanggal += output;
            // });
            
            // console.log(this.RenderDate());
            // var cat = this.RenderDate();
            
            // // var str = "I have a cat, a dog, and a goat.";
            // // var mapObj = {
            // //     cat:"dog",
            // //     dog:"goat",
            // //     goat:"cat"
            // // };
            // // str = str.replace(/cat|dog|goat/gi, function(matched){
            // //     return mapObj[matched];
            // // });
            // // console.log(str);
            
            // String.prototype.allReplace = function(obj) {
            //     var retStr = this;
            //     for (var x in obj) {
            //         retStr = retStr.replace(new RegExp(x, 'g'), obj[x]);
            //     }
            //     return retStr;
            // };
            // var cate = this.RenderDate().allReplace({'Apr': '', '07': ''});
            
            
            // var x1 = cat.replace("[","");
            // var x2 = x1.replace("]","");
            // console.log(x2);
            // var options = {
            //         chart: {
            //             renderTo: 'container',
            //             type: 'line'
            //         },
            //         title: {
            //             text: 'Statistik Pengunjung Website'
            //         },
            //         subtitle: {
            //             text: 'Rumah Sakit Umum Parindu'
            //         },
            //         xAxis: {
            //             categories:['12/03/2016 Saturday','13/03/2016 Sunday','14/03/2016 Monday','15/03/2016 Tuesday','16/03/2016 Wednesday','17/03/2016 Thursday','18/03/2016 Friday','19/03/2016 Saturday','20/03/2016 Sunday','21/03/2016 Monday','22/03/2016 Tuesday'],
            //             tickWidth: 0,
            //             labels: {
            //                 align: 'left',
            //             }
            //         },
            //         yAxis: {
            //             title: {
            //                 text: ''
            //             },
            //             labels: {
            //                 formatter: function() {
            //                     return this.value
            //                 }
            //             },
            //             min: 0
            //         },
            //         // legend: {
            //         //     align: 'left',
            //         //     verticalAlign: 'top',
            //         //     y: 20,
            //         //     floating: true,
            //         //     borderWidth: 0
            //         // },
            //         tooltip: {
            //             headerFormat: '<b>{series.name}</b><br>',
            //             // pointFormat: '{point.x:%e. %b}: {point.y:.2f} m',
            //             shared: true,
            //             crosshairs: true
            //         },
            //         plotOptions: {
            //             spline: {
            //                 marker: {
            //                     enabled: true
            //                 }
            //             }
            //         },
            //         series: []
            //         // series: [{
            //         //         name: 'Unique Visitor',
            //         //         lineWidth: 2,
            //         //         marker: {
            //         //             radius: 2
            //         //         },
            //         //         data: [48,98,35,59,65,53,60]
            //         //     }, {
            //         //         name: 'Existing Visitor',
            //         //         marker: {
            //         //             symbol: 'square'
            //         //         },
            //         //         data: [0,0,0,0,0,0,0]                            
            //         //     }]
            //     };
                // [{
                //     "name": "Month",
                //     "data": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
                // }, {
                //     "name": "Revenue",
                //     "data": [23987, 24784, 25899, 25569, 25897, 25668, 24114, 23899, 24987, 25111, 25899, 23221]
                // }, {
                //     "name": "Overhead",
                //     "data": [21990, 22365, 21987, 22369, 22558, 22987, 23521, 23003, 22756, 23112, 22987, 22897]
                // }]
                // $.getJSON("data.json", function(json) {
                //     options.xAxis.categories = json[0]['data'];
                //     options.series[0] = json[1];
                //     options.series[1] = json[2];
                //     chart = new Highcharts.Chart(options);
                // });
                // var options = {
                //     chart: {
                //         renderTo: 'container',
                //         type: 'line',
                //         marginRight: 130,
                //         marginBottom: 25
                //     },
                //     title: {
                //         text: 'Revenue vs. Overhead',
                //         x: -20 //center
                //     },
                //     subtitle: {
                //         text: '',
                //         x: -20
                //     },
                //     xAxis: {
                //         categories: []
                //     },
                //     yAxis: {
                //         title: {
                //             text: 'Amount'
                //         },
                //         plotLines: [{
                //             value: 0,
                //             width: 1,
                //             color: '#808080'
                //         }]
                //     },
                //     tooltip: {
                //         headerFormat: '<b>{series.name}</b><br>',
                //         // pointFormat: '{point.x:%e. %b}: {point.y:.2f} m',
                //         shared: true,
                //         crosshairs: true
                //     },
                //     legend: {
                //         layout: 'vertical',
                //         align: 'right',
                //         verticalAlign: 'top',
                //         x: -10,
                //         y: 100,
                //         borderWidth: 0
                //     },
                //     series: []
                // };
                // // https://blueflame-software.com/how-to-create-dynamic-x-axis-data-using-json/
                // $.getJSON("Notif/RenderDate", function(json) {
                //     console.log(json.agenda);
                //     options.xAxis.categories = json.days;
                //     options.series[0] = new Object();
                //     options.series[0].name = "Agenda";
                //     options.series[0].data = json.agenda;
                //     options.series[0].color = "#00a65a";
                //     // options.series[1] = json.agenda;
                //     chart = new Highcharts.Chart(options);
                // });
                // chart.xAxis[0].setCategories(["Apr 07","Apr 06","Apr 05","Apr 04","Apr 03","Apr 02","Apr 01"]);
    
        }
       
        

    };
});
