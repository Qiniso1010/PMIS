define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min'),
        NProgress           = require('/Scripts/nprogress.js')

    return {
        Index: function () {

            this.Nav();
            // table
            this.Table();
            // caption form
            this.Caption();

        },
        Nav: function () {
            // action
            var htm = "";
            htm += "<li class='nav-role-refresh'><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            $("#navigasi").html(htm);
            // end nav top
            
            // hide action button
            $("#btnDelete").hide();
        },
        Caption: function() {
            // define title constant
            $("#title-header").html("Shared Files");
            // menu
            Utility.SelectedMenuItem("shared");
            Utility.SelectedToogleItem("arsip"); // parent

            $("#h1-header").html("Shared Files");
            $("#header-page").html("Shared Files");

            // refresh
            $("#btnRefresh").on("click", function () {
                $('#listing-grid').bootstrapTable('refresh');
            });
        },
        Table: function() {
            // listing
            NProgress.start();
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Sharing/GetDataShared/',
                cache: false,
                //height: 500,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: true,
                showRefresh: true,
                cardView: false,
                showToggle: true,
                showExport: true,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [{
                    field: 'stat',
                    checkbox: true
                }, {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, {
                    field: 'NameAndId',
                    title: 'Name',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'FromUnit',
                    title: 'From',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'FromUnit'
                },
                {
                    field: 'NameAndId',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Shared'
                },
                {
                    field: 'UpdatedAt',
                    title: 'Date Modified',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                }, {
                    field: 'FileSize',
                    title: 'Size',
                    align: 'right',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'TypeData',
                    visible: false
                }],
                onLoadSuccess: function() {
                    NProgress.done();
                }
            });
        },
        

    };
});
