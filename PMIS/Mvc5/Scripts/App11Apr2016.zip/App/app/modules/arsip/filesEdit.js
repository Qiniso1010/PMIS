
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function() {
             
            // menu
            Utility.SelectedMenuItem("folder");
            Utility.SelectedToogleItem("arsip");

            $("#title-header").html("Folder Update");

            $("#h1-header").html("Folder <small>Update</small>");
            $("#header-page").html("Update");
            
            // action
            var htm = "";
            htm += "<li class='nav-roles'><a href='#/arsip/files/index' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
            $("#navigasi").html(htm);
            // loading
            Utility.IsLoading("#loading", "hide");   
            
        }
       
    };
});