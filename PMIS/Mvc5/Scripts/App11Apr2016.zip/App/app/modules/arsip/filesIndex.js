define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min'),
        NProgress           = require('/Scripts/nprogress.js')

    return {
        Index: function () {

            // Top Nav
            this.Nav();
            // table
            this.Table();
            // caption form
            this.Caption();
            // Delete 
            this.Delete();
            
            // Make Private
            this.MakePrivate();

        },
        Nav: function () {
            // action
            var htm = "";
            htm += "<li class='nav-role'><a href='#/arsip/files/add' id='btnAdd' role='button'> <i class='icon ion-ios-folder-outline'></i> New Folder </a></li>";
            htm += "<li class='nav-role'><a href='#/arsip/files/upload' id='btnUpload' role='button'> <i class='icon ion-ios-cloud-upload-outline'></i> Upload </a></li>";

            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnDelete' role='button'> <i class='icon ion-ios-close-outline'></i> Delete </a></li>";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnPrivate' role='button'> <i class='icon ion-ios-unlocked-outline'></i> Make Private? </a></li>";

            $("#navigasi").html(htm);
            // end nav top


            // hide action button
            $("#btnDelete").hide();
            $("#btnPrivate").hide();
        },
        Caption: function() {
            // define title constant
            $("#title-header").html("Files");
            // menu
            Utility.SelectedMenuItem("files");
            Utility.SelectedToogleItem("arsip"); // parent

            $("#h1-header").html("Files");
            $("#header-page").html("Files");

            // refresh
            $("#btnRefresh").on("click", function () {
                $('#listing-grid').bootstrapTable('refresh');
            });
        },
        Table: function() {
            NProgress.start();
            // listing
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Files/',
                cache: false,
                //height: 500,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: true,
                showRefresh: true,
                cardView: false,
                showToggle: true,
                showExport: true,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [{
                    field: 'stat',
                    checkbox: true
                }, {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, {
                    field: 'NameAndId',
                    title: 'Name',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'NameAndId',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Shared'
                },
                {
                    field: 'UpdatedAt',
                    title: 'Date Modified',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'UplBy',
                    title: 'Created by',
                    align: 'center',
                    valign: 'middle',
                    sortable: true
                }, {
                    field: 'FileSize',
                    title: 'Size',
                    align: 'right',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'TypeData',
                    visible: false
                }],
                onCheck: function (row) {
                    $("#btnDelete").show();
                    $("#btnPrivate").show();
                },
                onUncheck: function (row) {
                    $("#btnDelete").hide();
                    $("#btnPrivate").hide();
                },
                onCheckAll: function () {
                    $("#btnDelete").show();
                    $("#btnPrivate").show();
                },
                onUncheckAll: function () {
                    $("#btnDelete").hide();
                    $("#btnPrivate").hide();
                },
                onLoadSuccess: function() {
                    NProgress.done();
                }
            });
        },
        Delete: function () {

            /// delete button action
            $("#btnDelete").on("click", function () {
                Delete();
            });

            // delete
            function Delete() {
                swal({
                    title: "Yakin ingin menghapus File?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        // Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                DeleteAction(param[i].Id, param[i].TypeData);
                            }

                            $("#btnDelete").hide();

                            Utility.prosesLoad("N");
                            // Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            var token = $('input[name="__RequestVerificationToken"]').val();

            // delete action
            function DeleteAction(id, tipe) {
                NProgress.start();
                if (tipe == 'File') {
                    var param = {
                        id: id,
                        __RequestVerificationToken: token
                    }

                    var url = 'Files/DeleteFile/';
                } else {
                    var param = {
                        id: id,
                        __RequestVerificationToken: token,
                    }

                    var url = 'Files/Delete/';
                }
                $.ajax({
                    url: url,
                    cache: false,
                    type: 'POST',
                    data: param,
                    dataType: 'json',
                    success: function (d) {
                        NProgress.done();
                        if (d.Attr == "Ok!") {
                            Utility.AlertV2("check", d.Message, "success");
                        } else {
                            Utility.AlertV2("remove", d.Message, "error");
                        }

                        $('#listing-grid').bootstrapTable('refresh');
                    },
                    error: function (err) {
                        alert(err.responseText);
                    }
                });
            }
            // end action
        },
        MakePrivate: function () {

            /// delete button action
            $("#btnPrivate").on("click", function () {
                Private();
            });

            // delete
            function Private() {
                swal({
                    title: "Yakin ingin melakukan proteksi File ini?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        // Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                PrivateAction(param[i].Id, param[i].TypeData);
                            }

                            $("#btnPrivate").hide();

                            Utility.prosesLoad("N");
                            // Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            // Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            
            var token = $('input[name="__RequestVerificationToken"]').val();

            // private action
            function PrivateAction(id, tipe) {
                NProgress.start();
                if (tipe == 'File') {
                    var param = {
                        id: id,
                        __RequestVerificationToken: token
                    }

                    var url = 'Files/MakePrivate/';
                } else {
                    var param = {
                        id: id,
                        __RequestVerificationToken: token,
                    }

                    var url = 'Files/MakePrivateFolder/';
                }

                
                $.ajax({
                    url: url,
                    cache: false,
                    type: 'POST',
                    data: param,
                    dataType: 'json',
                    success: function (d) {
                        NProgress.done();
                        if (d.Attr == "Ok!") {
                            Utility.AlertV2("check", d.Message, "success");
                        } else {
                            Utility.AlertV2("remove", d.Message, "error");
                        }

                        $('#listing-grid').bootstrapTable('refresh');
                    },
                    error: function (err) {
                        alert(err.responseText);
                    }
                });
            }
            // end action
        }

    };
});
