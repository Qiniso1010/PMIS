define(function (require) {

    "use strict";

    var //Handlebars          = require('handlebars'),
        // _                   = require('underscore'),
        // Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        // HandlerHelper       = require('handlebarshelper'),
        summernote          = require('summernote/summernote'),
        select2             = require('select2/select2'),
        datepicker          = require('/Scripts/bootstrap-datepicker.js'),
        NProgress           = require('/Scripts/nprogress.js'),
        ModSharedId         = require('app/models/event/GetSharedId'),
        Users               = require('app/models/event/UsersList'),
        moment              = require('moment'),
        colorpicker         = require('/Scripts/bootstrap-colorpicker.js'),
        GetNaskahDetail     = require('app/models/event/GetNaskahDetails'),
        
    AgendaAdd = Backbone.View.extend({
        template : hb.Tem('event/AgendaAddView'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
        },
        render: function (time,date,querystr) {
            this.$el.html(this.template());
            NProgress.done();
            
            if (querystr.sid != undefined) {
                this.RenderNaskah(querystr.sid);
                this.$('#SharedId').val(querystr.sid);
                // this.$('#title').val('test');
            } else {
                 this.SharedId();
            }
            
            this.StartTime('#start');
            this.EndTime('#end');
            
            this.$('#tanggal').datepicker({
                format:'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true
            });
            
            this.$('#RoomId').val(this.id);
            this.$('#tanggal').val(moment(date,'DD-MM-YYYY').format('YYYY-MM-DD'));
            
            this.$('#UserId').select2();
            // List Invite people
            this.RenderUsers();
            
            this.$('#back_color').colorpicker();
            this.$('#text_color').colorpicker();

            
            this.$('#keterangan').summernote({
               height:300 
            });
            
           
            
            return this;
        },
        RenderNaskah: function(id) {
            var list = new GetNaskahDetail.GetNaskahDetails();
            NProgress.start();
            list.fetch({
               data: $.param({ sid: id }),
                type: 'GET',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#title').val(data.get("Perihal"));
                    $('#keterangan').code(data.get("Keterangan"));
                }
            });
        },
        StartTime:function(selector) {
            var select = this.$(selector);
            var hours, minutes, ampm;
            for(var i = 420; i <= 1420; i += 15){
                hours = Math.floor(i / 60);
                minutes = i % 60;
                if (minutes < 10){
                    minutes = '0' + minutes; // adding leading zero
                }
                ampm = hours % 24 < 12 ? 'AM' : 'PM';
                // hours = hours % 12;
                hours = hours;
                if (hours === 0){
                    hours = 12;
                }
                select.append($('<option></option>')
                    .attr('value', hours + ':' + minutes)
                    .text(hours + ':' + minutes)); 
            }
        },
        EndTime:function(selector) {
            var select = this.$(selector);
            var hours, minutes, ampm;
            
            for(var i = 420; i <= 1420; i += 15){
                hours = Math.floor(i / 60);
                minutes = i % 60;
                if (minutes < 10){
                    minutes = '0' + minutes; // adding leading zero
                }
                ampm = hours % 24 < 12 ? 'AM' : 'PM';
                // hours = hours % 12;
                hours = hours;
                if (hours === 0){
                    hours = 12;
                }
                select.append($('<option></option>')
                    .attr('value', hours + ':' + minutes)
                    .text(hours + ':' + minutes)); 
            }
        },
        RenderUsers: function () {
            var templatex = hb.Tem('Event/_partial/UsersListing');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var list = new Users.UsersList();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token }),
                type: 'GET',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#UserId').html(templatex(data.attributes));
                }
            });
            return this;
        },
        SharedId:function () {
            var list = new ModSharedId.GetSharedId();

            list.fetch({
                data: $.param({ Id: 'GET' }),
                type: 'GET',
                cache:false,
                success: function (data) {
                    $('#SharedId').val(data.get("result"));
                }
            });
            
            return this;
        },
        BeforeSend:function() {
            var param = {
                Title:$("#title").val(),
                Tanggal:$("#tanggal").val(),
                StartTime:$("#start").val(),
                EndTime:$("#end").val()
            
            };
            
            var start = param.StartTime;
            var startValue1 = start.split(':')[0]; 
            var startValue2 = start.split(':')[1]; 
            var start3 = startValue1+startValue2;
            
            var end = param.EndTime;
            var end1 = end.split(':')[0]; 
            var end2 = end.split(':')[1]; 
            var end3 = end1+end2;
            
            if (param.Title == "") {
                $("#title-id").removeClass("has-success");
                $("#title-id").addClass("has-error");
                $("#title").focus();
                Utility.IsLoading("#loading","hide");
                return false;
            } else if (param.Tanggal == "") {
                $("#tanggal-id").removeClass("has-success");
                $("#tanggal-id").addClass("has-error");
                $("#tanggal").focus();
                Utility.IsLoading("#loading","hide");
                return false;
            } else if (param.StartTime == "") {
                $("#time-id").removeClass("has-success");
                $("#time-id").addClass("has-error");
                $("#start").focus();
                Utility.IsLoading("#loading","hide");
                return false;
            } else if (param.StartTime == "") {
                $("#time-id").removeClass("has-success");
                $("#time-id").addClass("has-error");
                $("#start").focus();
                Utility.IsLoading("#loading","hide");
                return false;
            } else if (param.EndTime == "") {
                $("#time-id").removeClass("has-success");
                $("#time-id").addClass("has-error");
                $("#end").focus();
                Utility.IsLoading("#loading","hide");
                return false;
            } 
            
            return true;
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            
            Utility.prosesLoad("Y");
            var token = $('input[name="__RequestVerificationToken"]').val();
            var user = $("#UserId");
            
            if (user.val() == "" || user.val() == null) {
                var userid = "";
            } else {
                var userid = user.val().toString();
            }
            
            var $options = {};
            if(this.BeforeSend()) {
                 var param = {
                    Title:$("#title").val(),
                    __RequestVerificationToken: token,
                    StartDate:$("#tanggal").val(),
                    StartTime:$("#start").val(),
                    EndTime:$("#end").val(),
                    Description:$("#keterangan").code(),
                    Owner:$("#owner").val(),
                    SharedId:$("#SharedId").val(),
                    UserId:userid,
                    RoomId:$("#RoomId").val(),
                    BackColor:$("#back_color").val(),
                    TextColor:$("#text_color").val()
                    
                };
            
                $("#btnSave").attr("disabled",false);
                
                $options.url = "Schedules/Create/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    if (d.Attr == "Ok!") {
                        Utility.IsLoading("#loading","hide");
                        Utility.prosesLoad("N");
                        Utility.AlertV2("check",d.Message,"success");
                        
                        var $v = new AgendaAdd();
                        $v.SharedId();
                    } else if (d.Attr === "ErrorTime!") {
                        Utility.IsLoading("#loading","hide");
                        swal("Warning!","Time Set Not Valid, please check! , " + d.Message,"error");
                        $("#end").removeClass("has-success");
                        $("#end").addClass("has-error");
                        $('#end').focus();
                    } else {
                        Utility.IsLoading("#loading","hide");
                        Utility.AlertV2("exclamation-triangle",d.Message,"error");
                    }
                    $("#title").focus();
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
            }
            
            return this;

        }
      
    });

    return {
        AgendaAdd: AgendaAdd
    };

   
   

});


