define(function(require) {

  "use strict";

 
    var //Handlebars          = require('handlebars'),
        // _                   = require('underscore'),
        // Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        // HandlerHelper       = require('handlebarshelper'),
        slimscroll          = require('jquery.slimscroll.min'),
        NProgress           = require('/Scripts/nprogress.js'),

    ProfileIndex = Backbone.View.extend({
      template: hb.Tem('Event/ProfileIndexView'),
      initialize: function() {
        this.render;
      },
      render: function() {
        this.$el.html(this.template());
        
        
        NProgress.done();
        // this.InitCalendar('ajax');
        
        // this.$("#room").slimscroll({
        //     height: "450px",
        //     alwaysVisible: false,
        //     size: "3px"
        // }).css("width", "100%");
       
        return this;
      }
      

    });

  return {
    ProfileIndex: ProfileIndex
  }



});
