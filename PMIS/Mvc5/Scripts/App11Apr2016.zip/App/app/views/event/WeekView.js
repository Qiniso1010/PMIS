define(function(require) {

  "use strict";


    var //Handlebars          = require('handlebars'),
        // _                   = require('underscore'),
        // Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        // HandlerHelper       = require('handlebarshelper'),
        easycal             = require('/Scripts/calendar/easycal.js'),
        NProgress           = require('/Scripts/nprogress.js'),


    WeekView = Backbone.View.extend({
      template: hb.Tem('Event/_partial/WeekView'),
      initialize: function() {
        this.render;
      },
      render: function() {
        this.$el.html(this.template());
        
        NProgress.done();
        
        return this;
      },
      RenderEasyCal:function() {
        //   alert('a');
        $('.mycal').easycal({
			startDate : '13-03-2016', // OR 31/10/2104
			timeFormat : 'HH:mm',
			columnDateFormat : 'dddd, DD MMM',
			minTime : '09:00:00',
			maxTime : '19:00:00',
			slotDuration : 30,
			timeGranularity : 15,
			
			dayClick : function(el, startTime){
				console.log('Slot selected: ' + startTime);
			},
			eventClick : function(eventId){
				console.log('Event was clicked with id: ' + eventId);
			},
			events : this.DataSet(),
			
			overlapColor : '#FF0',
			overlapTextColor : '#000',
			overlapTitle : 'Multiple'
		});
        
        return this;  
      },
      DataSet:function() {
          return [
            {
                id : 'E01',
                title : 'Meeting with BA',
                start : '13-03-2016 10:30:00',
                end : '13-03-2016 13:00:00',
                backgroundColor: '#443322',
                textColor : '#FFF'
            },
            {
                id : 'E02',
                title : 'Lunch',
                start : '27-03-2016 12:45:00',
                end : '27-03-2016 13:30:00',
                backgroundColor: '#12CA6B',
                textColor : '#FFF'
            },
            {
                id : 'E03',
                title : 'Customer Appointment',
                start : '29-10-2014 09:00:00',
                end : '29-10-2014 10:30:00',
                backgroundColor: '#34BB22',
                textColor : '#FFF'
            },
            {
                id : 'E04',
                title : 'Customer Appointment',
                start : '30-10-2014 09:00:00',
                end : '30-10-2014 10:30:00',
                backgroundColor: '#34BB22',
                textColor : '#FFF'
            },
            {
                id : 'E05',
                title : 'Buddy Time. Proactive contact. Long name',
                start : '30-10-2014 11:00:00',
                end : '30-10-2014 12:30:00',
                backgroundColor: '#AA3322',
                textColor : '#FFF'
            },
            {
                id : 'E06',
                title : 'Proactive Contact',
                start : '01-11-2014 10:30:00',
                end : '01-11-2014 11:15:00',
                backgroundColor: '#443322',
                textColor : '#FFF'
            }
        ];
      }

    });

  return {
    WeekView: WeekView
  }



});
