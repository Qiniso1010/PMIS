define(function (require) {

    "use strict";

    var $                   = require('jquery'),
        Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        Models              = require('app/models/laporan/CategoryCheckName'),

    CategoryAdd = Backbone.View.extend({
        template : hb.Tem('laporan/CategoryAddView'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
            "focusout #name":"CheckName"
        },
        render: function () {
            this.$el.html(this.template());
            this.$("#btnSave").attr("disabled",true);
            return this;
        },
        CheckName: function(e) {
            this.name = this.$("#name").val();

            var token = $('input[name="__RequestVerificationToken"]').val();
            
            var CurrentName = new Models.CategoryCheckName({ name: this.name, __RequestVerificationToken: token });
            var self = this;
            
            
            if (this.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                Utility.AlertV2("check","Name is empty!","error");
                $("#name").focus();
                $("#btnSave").attr("disabled", false);
            } else {
                $("#btnSave").attr("disabled",false);
                CurrentName.fetch({
                    data: $.param({name:this.name,__RequestVerificationToken:token}),
                    type:'POST',
                    success: function(data) {
                        if (data.get("Attr") == "Ok!") {
                            $('#name').val(data.get("Message"));
                        }  
                    }
                
                }); 
            }
            
            return this;       
        },  
        BeforeSend:function() {
            var param = {
                Name:$("#name").val()
            
            };
            
             if (param.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                $("#name").focus();

                $("#btnSave").attr("disabled", true);
                Utility.IsLoading("#loading","hide");
                
                return false;
            } else {
                
            }
            
            return true;
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            var $options = {};
            var token = $('input[name="__RequestVerificationToken"]').val();
            
            if(this.BeforeSend()) {
                 var param = {
                    Name:$("#name").val(),
                    __RequestVerificationToken: token
                };
            
                $("#btnSave").attr("disabled",false);
                
                $options.url = "Categories/Create/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                        if (d.Attr == "Ok!") {
                            Utility.IsLoading("#loading","hide");
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check",d.Message,"success");
                        } else {
                            Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        }
                        $("#name").focus();
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
            }
            
            return this;

        }
      
    });

    return {
        CategoryAdd: CategoryAdd
    };

   
   

});


