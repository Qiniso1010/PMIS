define(function (require) {

    "use strict";

    var //Handlebars          = require('handlebars'),
        // _                   = require('underscore'),
        // Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        // HandlerHelper       = require('handlebarshelper'),
        ModalxView          = require('backbone-modalx'),
        filex               = require('app/models/naskah/GetFiles'),
        select2             = require('select2/select2'),
        summernote          = require('summernote/summernote'),
        models              = require('app/models/naskah/GetNaskah'),
        
        ModalUpdatedLogDetail = Backbone.ModalxView.extend({
            title: "<h5>Menambahkan Dokumen Sebagai Referensi Naskah</h5>",
            buttons: [{
                className: "btn-success btn-custom btn-flat ok",
                label: "Save"
            }],
            events: {
                "click .modal-footer a.ok": "onAction",
                "hidden.bs.modal": "onHidden"
            },
            postRender: function() {
                console.log(this.id);
                this.onRender(this.id);
                return this;
            },
            onRender: function(id) {
                var templatex = hb.Tem('Naskah/_partial/LogsUpdateTemplateDetail');
                this.$body.html(templatex());
                
                var token = $('input[name="__RequestVerificationToken"]').val();
                var list = new models.GetNaskah();
                
                $('#keterangan').summernote({
                    height:800
                });
                    
                list.fetch({
                    data: $.param({ id: id,__RequestVerificationToken:token }),
                    type: 'POST',
                    dataType: 'json',
                    cache:false,
                    success: function (data) {
                        $("#keterangan").code(data.get("Keterangan"));
                        $('#Id').val(data.get("LaporanDocId"));
                    }
                });
                
                return this;
            },
            RenderLogs: function(id) {
                var templatex = hb.Tem('Naskah/_partial/RenderDocLogsDetail');
                var token = $('input[name="__RequestVerificationToken"]').val();
                
                var list = new log_model.GetLogs();

                list.fetch({
                    data: $.param({ __RequestVerificationToken: token,LaporanDocId:id ,tipe : 'SENDING'}),
                    type: 'POST',
                    dataType: 'json',
                    cache:true,
                    success: function (data) {
                        $('#log-lists').html(templatex(data.attributes));
                    }
                });
                return this;
            },
            onAction: function() {
                var $Id = $("#Id").val();
                Utility.prosesLoad("Y");
                
                var token = $('input[name="__RequestVerificationToken"]').val();
                
                swal({
                    title: "Yakin ingin menyimpan data ini?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ya!",
                    closeOnConfirm: true
                },
                function (isConfirm)
                {
                    if (isConfirm) {
                        Utility.IsLoading("#loading","show");
                        var param = {
                            LaporanDocId:$Id,
                            __RequestVerificationToken:token,
                            Keterangan:$('#keterangan').code()
                        };
                        
                        var $options = {};
                        $options.url = "LaporanDocLogs/Saving/";
                        $options.type = "POST";
                        $options.cache = false;
                        $options.data = param;
                        $options.dataType = "json";
                        $options.success = function(d) {
                            if (d.Attr == "Ok!") {
                                Utility.IsLoading("#loading","hide");
                                Utility.prosesLoad("N");
                                Utility.AlertV2("check",d.Message,"success");
                                
                                location.reload();
                            } else {
                                Utility.AlertV2("exclamation-triangle",d.Message,"error");
                            }
                        };
                        $options.error = function(err) {
                            alert(err.responseText);  
                            Utility.IsLoading("#loading","hide");
                        };
                        $.ajax($options);
                    }
                });
                
                return this;
            },
            onHidden: function(e) {
                console.log("Modal hidden");
            },
        });

    return {
        ModalUpdatedLogDetail: ModalUpdatedLogDetail
    };
  

});


