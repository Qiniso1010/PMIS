define(function (require) {

    "use strict";

    var //Handlebars          = require('handlebars'),
        // _                   = require('underscore'),
        // Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        // HandlerHelper       = require('handlebarshelper'),
        inputmask           = require('/Scripts/masking/jquery.inputmask.bundle.js'),
        check               = require('app/models/naskah/master/CheckNomorRekening'),
        NProgress           = require('/Scripts/nprogress.js'),

    MasterRekeningAdd = Backbone.View.extend({
        template : hb.Tem('naskah/_master/MasterRekeningAdd'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
            "focusout #name":"CheckName"
        },
        render: function () {
            this.$el.html(this.template());
            NProgress.done();
            
            this.$("#btnSave").attr("disabled",false);
            
            // Input Mask Nomor Rekening
            this.$('#nomor').inputmask("9.99.9.99.99.99.99.99.9.9.9.99.99");
            
            return this;
        },
        CheckName: function(e) {
            this.nomor = this.$("#nomor").val();
            NProgress.start();
            var token = $('input[name="__RequestVerificationToken"]').val();
            
            var CurrentName = new check.CheckNomorRekening();
            var self = this;
            
            
            if (this.nomor == "") {
                $("#nomor-id").removeClass("has-success");
                $("#nomor-id").addClass("has-error");
                Utility.AlertV2("check","Nomor is empty!","error");
                $("#nomor").focus();
                $("#btnSave").attr("disabled", true);
            } else {
                $("#btnSave").attr("disabled",false);
                CurrentName.fetch({
                    data: $.param({nomor:this.nomor,__RequestVerificationToken:token}),
                    type:'POST',
                    success: function(data) {
                        NProgress.done();
                        if (data.get("Attr") == "Error!") {
                           $("#nomor-id").removeClass("has-success");
                           $("#nomor-id").addClass("has-error");
                           $("#nomor").focus();
                           $("#btnSave").attr("disabled", true);
                           Utility.AlertV2("exclamation-triangle","Nomor Rekening Telah Ada.","error");
                        } 
                    }
                }); 
            }
            
            return this;       
        },  
        BeforeSend:function() {
            var param = {
                nomor:$("#nomor").val(),
                uraian:$("#uraian").val()
            };
            
            if (param.nomor == "") {
                $("#nomor-id").removeClass("has-success");
                $("#nomor-id").addClass("has-error");
                $("#nomor").focus();
                Utility.IsLoading("#loading","hide");
                return false;
            } else if (param.nomor == "") {
                $("#uraian-id").removeClass("has-success");
                $("#uraian-id").addClass("has-error");
                $("#uraian").focus();
                Utility.IsLoading("#loading","hide");
                return false;
            }
            
            return true;
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            
            var $options = {};
            var token = $('input[name="__RequestVerificationToken"]').val();
            
            
            // Check Form Valid Or Not
            if(this.BeforeSend()) {
                var param = {
                    Nomor:$("#nomor").val(),
                    Uraian:$("#uraian").val(),
                    __RequestVerificationToken: token
                
                };
                $("#btnSave").attr("disabled",false);
                
                $options.url = "Rekenings/Create/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    if (d.Attr == "Ok!") {
                        Utility.IsLoading("#loading","hide");
                        Utility.prosesLoad("N");
                        
                        swal('Ok!',d.Message,"success");
                    } else {
                        swal('Error!',d.Message,"error");
                    }
                    $("#nomor").focus();
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
                    
            } else {
                swal("Oops...", "Kolom Masih ada yang kosong!", "error");
            }
            
            return this;

        }
      
    });

    return {
        MasterRekeningAdd: MasterRekeningAdd
    };
});


