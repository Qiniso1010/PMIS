define(function (require) {

    "use strict";

    var //Handlebars          = require('handlebars'),
        // _                   = require('underscore'),
        // Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        // HandlerHelper       = require('handlebarshelper'),
        ModalxView          = require('backbone-modalx'),
        filex               = require('app/models/naskah/GetFiles'),
        select2             = require('select2/select2'),
        summernote          = require('summernote/summernote'),
        models              = require('app/models/naskah/GetLogsDetails'),
        
        ModalUpdatedLogsDetailView = Backbone.ModalxView.extend({
            title: "<h5>Current Updated log</h5>",
            buttons: [{
                className: "btn-success btn-custom btn-flat ok",
                label: "Gunakan!"
            }],
            events: {
                "click .modal-footer a.ok": "onAction",
                "hidden.bs.modal": "onHidden"
            },
            postRender: function() {
                this.onRender(this.id);
                return this;
            },
            onRender: function(id) {
                var templatex = hb.Tem('Naskah/_partial/LogsUpdateTemplate');
                this.$body.html(templatex());
                
                var token = $('input[name="__RequestVerificationToken"]').val();
                var list = new models.GetLogsDetails();

                list.fetch({
                    data: $.param({ Id: id }),
                    type: 'GET',
                    dataType: 'json',
                    cache:false,
                    success: function (data) {
                        $('#template').html(data.get("doc_logs").TemplateText);
                        $('#Id').val(data.get("doc_logs").Id);
                        var stat = data.get("doc");
                        if (stat == false) {
                            $('.modal-footer').hide();
                        }
                        // console.log(stat);
                    }
                });
                
                return this;
            },
            onAction: function() {
                var $Id = $("#Id").val();
                Utility.prosesLoad("Y");
                
                var token = $('input[name="__RequestVerificationToken"]').val();
                
                swal({
                    title: "Yakin ingin Mengganti data sebelumnya dengan yang anda pilih?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ya!",
                    closeOnConfirm: true
                },
                function (isConfirm)
                {
                    if (isConfirm) {
                        Utility.IsLoading("#loading","show");
                        var param = {
                            Id:$Id,
                            __RequestVerificationToken:token
                        };
                        
                        var $options = {};
                        $options.url = "LaporanDocLogs/Restore/";
                        $options.type = "POST";
                        $options.cache = false;
                        $options.data = param;
                        $options.dataType = "json";
                        $options.success = function(d) {
                            if (d.Attr == "Ok!") {
                                Utility.IsLoading("#loading","hide");
                                Utility.prosesLoad("N");
                                Utility.AlertV2("check",d.Message,"success");
                                
                                location.reload();
                            } else {
                                Utility.AlertV2("exclamation-triangle",d.Message,"error");
                            }
                        };
                        $options.error = function(err) {
                            alert(err.responseText);  
                            Utility.IsLoading("#loading","hide");
                        };
                        $.ajax($options);
                    }
                });
                
                return this;
            },
            onHidden: function(e) {
                console.log("Modal hidden");
            },
        });

    return {
        ModalUpdatedLogsDetailView: ModalUpdatedLogsDetailView
    };
  

});


