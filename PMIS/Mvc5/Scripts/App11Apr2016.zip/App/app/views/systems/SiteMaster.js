define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        jc                  = require('jquery.confirm')

    return Backbone.View.extend({
        template : hb.Tem('systems/SiteMasterView'),
        initialize : function() {
            this.render;
        },
        events : {
            "click #keluar_top":"Logout",
            "click #root":"RootIndex"
        },
        render: function () {
            this.$el.html(this.template(this.model.attributes));
            
            return this;
        },
        RootIndex : function (e) {
            this.render;
            return this;
        },
        Logout : function (e) {
            
            e.preventDefault();
            $.confirm({
                text: "Are you sure want quit?",
                confirm: function() {
                    window.location.href = "masuk/keluar";
                },
                cancel: function() {
                    // nothing to do
                }
            });
            return this;
        }
      
    });

   

});