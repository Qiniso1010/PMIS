define(function(require) {

  "use strict";

  var   //Backbone        = require('backbone'),
        // Handlerbars     = require('handlebars'),
        // Boostrap        = require('bootstrap.min'),
        // AdminLTE        = require('dist/js/app'),
        Utility         = require('utility'),
        // hbhelper        = require('handlebarshelper'),
        // iCheck          = require('icheck'),
        // Modernizr       = require('modernizr-2.8.3'),
        // swal            = require('sweetalert.min'),
        NProgress       = require('/Scripts/nprogress.js'),

        $content        = $("#content"),
        $default_routes = $('#routes').val(),
        $headerAction   = $("#content-header");
   
    return {
        Init:function(router) {
            
            router.on("route:commentNaskahIndex", function() {
                require(
                    [
                        "app/views/naskah/CommentIndex",
                        "app/modules/naskah/commentIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        // Utility.IsLoading("#loading", "show");
                        NProgress.start();
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.CommentIndexView().render().el);
                        // load content module
                        Modules.Index();
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
                
            router.on("route:naskahIndex",function(params) {
                require(
                    [
                        "app/views/naskah/NaskahIndex",
                        "app/modules/naskah/naskahIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.NaskahIndexView().render().el);
                        // load content module
                        Modules.Index();
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
                
            router.on("route:naskahAdd", function () {
                require(
                    [
                        "app/views/naskah/NaskahAdd",
                        "app/modules/naskah/naskahAdd",
                        "app/views/systems/DashboardAction"
                    ],
                    function (views, Modules, DashboardAction) {
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new views.NaskahAdd().render().el);
                        
                        // Load Modules
                        Modules.Index();

                        // define logout
                        Utility.Logout();

                    });


            });
            
            router.on("route:naskahSubAdd", function (id,name) {
                require(
                    [
                        "app/views/naskah/NaskahSubAdd",
                        "app/modules/naskah/naskahSubAdd",
                        "app/views/systems/DashboardAction"
                    ],
                    function (views, Modules, DashboardAction) {
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new views.NaskahSubAdd().render(id).el);
                        
                        // Load Modules
                        Modules.Index(id,name);

                        // define logout
                        Utility.Logout();

                    });


            });

            router.on("route:naskahOpen",function (sharedid,id,params) {
                    require(
                    [
                        "app/views/naskah/NaskahDetails",
                        "app/modules/naskah/naskahDetails",
                        "app/models/naskah/NaskahDetails",
                        "app/views/systems/DashboardAction"
                    ],
                    function (views, Modules,models, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        NProgress.start();
                        if (querystr.Current != "" || querystr.Current != undefined) {
                                store.set('Current',sharedid);
                        }
                        if (querystr.Type != undefined || querystr.Type != "") {
                            var tipe = querystr.Type;
                        }
                        var token = $('input[name="__RequestVerificationToken"]').val();
                        // Utility.IsLoading("#loading", "show");
                        
                        // call data from model
                        var fect = new models.NaskahDetails();
                        // loading
                        // Utility.IsLoading("#loading", "show");
                        // retrive data
                        fect.fetch({
                            data: $.param({ __RequestVerificationToken: token,id:id,SharedId:sharedid,tipe:tipe }),
                            type: 'POST',
                            dataType: 'json',
                            success: function (data) {
                                NProgress.done();
                                $headerAction.html(new DashboardAction().render().el);
                                
                                $content.html(new views.NaskahDetails({
                                    model: data
                                }).render().el);

                                // load modules
                                Modules.Index(sharedid,id,querystr);

                            }
                        });
                        
                        

                        // define logout
                        Utility.Logout();

                    });
            });
            
            
            router.on("route:naskahDraft", function (sharedid,id,params) {
                require(
                [
                    "app/views/naskah/NaskahDraft",
                    "app/modules/naskah/naskahDraft",
                    "app/models/naskah/NaskahDraft",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules,models, DashboardAction) {
                    var querystr = Utility.parseQueryString(params);
                    NProgress.start();
                    if (querystr.Current != "" || querystr.Current != undefined) {
                            store.set('Current',sharedid);
                    }
                    if (querystr.Type != undefined || querystr.Type != "") {
                        var tipe = querystr.Type;
                    }
                    
                    var token = $('input[name="__RequestVerificationToken"]').val();
                    // Utility.IsLoading("#loading", "show");
                    
                    // call data from model
                    var fect = new models.NaskahDraft();
                    // loading
                    // Utility.IsLoading("#loading", "show");
                    // retrive data
                    fect.fetch({
                        data: $.param({ __RequestVerificationToken: token,id:id,SharedId:sharedid,tipe:tipe }),
                        type: 'POST',
                        dataType: 'json',
                        success: function (data) {
                            NProgress.done();
                            $headerAction.html(new DashboardAction().render().el);
                            
                            $content.html(new views.NaskahDraft({
                                model: data
                            }).render().el);

                            // load modules
                            Modules.Index(sharedid,id,querystr);

                        }
                    });
                    
                    

                    // define logout
                    Utility.Logout();

                });


            });
            
            router.on("route:naskahSubIndex", function (id,name) {
                require(
                [
                    "app/views/naskah/NaskahSubIndex",
                    "app/modules/naskah/naskahSubIndex",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, DashboardAction) {
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.NaskahSubIndexView().render().el);

                    // Load Modules
                    Modules.Index(id,name);

                    // define logout
                    Utility.Logout();

                });
            });
            
            router.on("route:categoryNaskahAdd", function () {
                require(
                [
                    "app/views/naskah/CategoryAdd",
                    "app/modules/naskah/categoryAdd",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, DashboardAction) {
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.CategoryAdd().render().el);

                    // Load Modules
                    Modules.Index();

                    // define logout
                    Utility.Logout();

                });


            });
            
            router.on("route:categoryNaskahEdit", function (id) {
                require(
                [
                    "app/views/naskah/CategoryEdit",
                    "app/modules/naskah/categoryEdit",
                    "app/models/naskah/CategoryEditModel",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules,models, DashboardAction) {
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // call data from model
                    var fect = new models.CategoryEditModel({
                        id: id
                    });
                    // loading
                    // Utility.IsLoading("#loading", "show");
                    // retrive data
                    fect.fetch({
                        success: function (data) {
                            NProgress.done();
                            $headerAction.html(new DashboardAction().render().el);
                            
                            $content.html(new views.CategoryEdit({
                                model: data
                            }).render().el);

                            // load modules
                            Modules.Index();

                        }
                    });

                    // define logout
                    Utility.Logout();

                });


            });

            router.on("route:inboxNaskahIndex", function(params) {
                require(
                [
                    "app/views/naskah/InboxIndex",
                    "app/modules/naskah/inboxIndex",
                    "app/views/systems/DashboardAction"
                ],
                function(Views, Modules, DashboardAction) {
                    var querystr = Utility.parseQueryString(params);
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new Views.InboxIndexView().render().el);
                    // load content module
                    Modules.Index();
                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();


                });

            });
            
            router.on("route:templateIndex", function(params) {
                require(
                    [
                        "app/views/naskah/MasterTemplateIndex",
                        "app/modules/naskah/masterTemplateIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.MasterTemplateIndexView().render().el);
                        // load content module
                        Modules.Index();
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
            
            router.on("route:templateAdd", function () {
                require(
                [
                    "app/views/naskah/NaskahTemplateAdd",
                    "app/modules/naskah/naskahTemplateAdd",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, DashboardAction) {
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.NaskahTemplateAdd().render().el);

                    // Load Modules
                    Modules.Index();

                    // define logout
                    Utility.Logout();

                });


            });
            
            router.on("route:templateEdit", function (sharedid,id) {
                require(
                [
                    "app/views/naskah/NaskahTemplateEdit",
                    "app/modules/naskah/naskahTemplateEdit",
                    "app/models/naskah/NaskahTemplateEditModel",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules,models, DashboardAction) {
                    // Utility.IsLoading("#loading", "show");
                    NProgress.start();
                    // call data from model
                    var fect = new models.NaskahTemplateEditModel({
                        id: id
                    });
                    // loading
                    // Utility.IsLoading("#loading", "show");
                    // retrive data
                    fect.fetch({
                        success: function (data) {
                            NProgress.done();
                            $headerAction.html(new DashboardAction().render().el);
                            
                            $content.html(new views.NaskahTemplateEdit({
                                model: data
                            }).render().el);

                            // load modules
                            Modules.Index();

                        }
                    });

                    // define logout
                    Utility.Logout();

                });


            });
            
            
            router.on("route:masterRekeningIndex", function (params) {
                require(
                [
                    "app/views/naskah/master/MasterRekeningIndex",
                    "app/modules/naskah/master/ModMasterRekeningIndex",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, DashboardAction) {
                    var querystr = Utility.parseQueryString(params);
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.MasterRekeningIndex().render().el);

                    // Load Modules
                    Modules.Index();
                    
                    Utility.IsLoading("#loading", "hide");
                    // define logout
                    Utility.Logout();

                });
            });
            
            
            router.on("route:masterRekeningAdd", function (params) {
                require(
                [
                    "app/views/naskah/master/MasterRekeningAdd",
                    "app/modules/naskah/master/ModMasterRekeningAdd",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, DashboardAction) {
                    var querystr = Utility.parseQueryString(params);
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    
                    $headerAction.html(new DashboardAction().render().el);
                            
                    $content.html(new views.MasterRekeningAdd().render().el);

                    // load modules
                    Modules.Index();
                    // loading
                    Utility.IsLoading("#loading", "hide");
                    // define logout
                    Utility.Logout();

                });


            });
            
            router.on("route:masterRekeningEdit", function (id,params) {
                require(
                [
                    "app/views/naskah/master/MasterRekeningEdit",
                    "app/modules/naskah/master/ModMasterRekeningEdit",
                    "app/models/naskah/master/MasterRekeningEditModel",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules,models, DashboardAction) {
                    var querystr = Utility.parseQueryString(params);
                    
                    // Utility.IsLoading("#loading", "show");
                    NProgress.start();
                    // call data from model
                    var fect = new models.MasterRekeningEditModel({
                        id: id
                    });
                    
                    // retrive data
                    fect.fetch({
                        success: function (data) {
                            NProgress.done();
                            $headerAction.html(new DashboardAction().render().el);
                            
                            $content.html(new views.MasterRekeningEdit({
                                model: data
                            }).render().el);

                            // load modules
                            Modules.Index();

                        }
                    });
                    // loading
                    Utility.IsLoading("#loading", "hide");
                    // define logout
                    Utility.Logout();

                });


            });
            
            
            // -------------- SPPD ------------------------ //
            
            // Index
            router.on("route:InboxDinas", function (params) {
                require(
                [
                    "app/views/naskah/SPPD/InboxDinas",
                    "app/modules/naskah/SPPD/ModInboxDinas",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, DashboardAction) {
                    var querystr = Utility.parseQueryString(params);
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.InboxDinas().render(querystr).el);

                    // Load Modules
                    Modules.Index(querystr);
                    
                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();

                });


            });
            
            // Index
            router.on("route:ManageDinas", function (params) {
                require(
                [
                    "app/views/naskah/SPPD/ManageDinasIndex",
                    "app/modules/naskah/SPPD/ModManageDinasIndex",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, DashboardAction) {
                    var querystr = Utility.parseQueryString(params);
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.ManageDinasIndex().render(querystr).el);

                    // Load Modules
                    Modules.Index(querystr);
                    
                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();

                });


            });
            
            // Adding New SPT
            router.on("route:AddSPT", function (params) {
                require(
                [
                    "app/views/naskah/SPPD/AddSpt",
                    "app/modules/naskah/SPPD/ModAddSpt",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, DashboardAction) {
                    var querystr = Utility.parseQueryString(params);
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.AddSpt().render(querystr).el);

                    // Load Modules
                    Modules.Index(querystr);

                    // define logout
                    Utility.Logout();

                });


            });
            // Adding New Data SPPD
            router.on("route:AddSPPD", function (sharedid,id,params) {
                require(
                [
                    "app/views/naskah/SPPD/AddSppd",
                    "app/modules/naskah/SPPD/ModAddSppd",
                    "app/models/naskah/SPPD/AddSppdModel",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules,Model, DashboardAction) {
                    var querystr = Utility.parseQueryString(params);
                    NProgress.start();
                    var token = $('input[name="__RequestVerificationToken"]').val();
                    var m = new Model.AddSppdModel();
                    
                    
                    // Utility.IsLoading("#loading", "show");
                    
                    m.fetch({
                        data: $.param({ __RequestVerificationToken: token,id:id,SharedId:sharedid}),
                        type: 'POST',
                        dataType: 'json',
                        success: function (data) {
                            NProgress.done();
                            // header render
                            $headerAction.html(new DashboardAction().render().el);
                            // body render
                            $content.html(new views.AddSppd({
                                model:data
                            }).render(sharedid,id,querystr).el);

                            // Load Modules
                            Modules.Index(sharedid,id,querystr);
                        }
                        
                    });
                    
                    Utility.IsLoading("#loading", "hide");
                    

                    // define logout
                    Utility.Logout();

                });


            });
            
            // // Edit Data SPPD
            // router.on("route:EditSPPD", function (id,params) {
            //     require(
            //     [
            //         "app/views/naskah/SPPD/EditSppd",
            //         "app/modules/naskah/SPPD/ModEditSppd",
            //         "app/models/naskah/SPPD/EditSppdModel",
            //         "app/views/systems/DashboardAction",
            //         "hbtemplate",
            //         "jquery"
            //     ],
            //     function (views, Modules,Models, DashboardAction) {
            //         var querystr = Utility.parseQueryString(params);
                    
                    
            //         Utility.IsLoading("#loading", "show");
            //         var datax = new Models.EditSppdModel({
            //             id:id
            //         });
                    
            //         datax.fetch({
            //            success:function(data) {
            //                 // header render
            //                 $headerAction.html(new DashboardAction().render().el);
            //                 // body render
            //                 $content.html(new views.ModEditSppd({
            //                     model:data
            //                 }).render(querystr).el);

            //                 // Load Modules
            //                 Modules.Index(querystr);
            //            } 
            //         });
                   
            //         Utility.IsLoading("#loading", "hide");

            //         // define logout
            //         Utility.Logout();

            //     });


            // });
            
            // Details Perjalanan Dinas
            router.on("route:DetailsDinas", function (sharedid,id,params) {
                require(
                [
                    "app/views/naskah/SPPD/DinasDetails",
                    "app/modules/naskah/SPPD/ModDinasDetails",
                    "app/models/naskah/SPPD/DinasDetailsModel",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules,Models, DashboardAction) {
                    var querystr = Utility.parseQueryString(params);
                    if (querystr.Type != undefined || querystr.Type != "") {
                        var tipe = querystr.Type;
                    }
                    // Utility.IsLoading("#loading", "show");
                    NProgress.start();
                    
                    var token = $('input[name="__RequestVerificationToken"]').val();
                    var m = new Models.DinasDetailsModel();
                    
                     // retrive data
                    m.fetch({
                        data: $.param({ __RequestVerificationToken: token,id:id,SharedId:sharedid,tipe:tipe }),
                        type: 'POST',
                        dataType: 'json',
                        success: function (data) {
                            NProgress.done();
                             // header render
                            $headerAction.html(new DashboardAction().render().el);
                            // body render
                            $content.html(new views.DinasDetails({
                                model:data
                            }).render(sharedid,id,querystr).el);

                            // Load Modules
                            Modules.Index(sharedid,id,querystr);

                        }
                    });
                    
                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();

                });


            });
            
            
            // Details SPPD
             router.on("route:DetailsSppdDinas", function (sharedid,id,params) {
                require(
                [
                    "app/views/naskah/SPPD/DinasSppdDetails",
                    "app/modules/naskah/SPPD/ModDinasSppdDetails",
                    "app/models/naskah/SPPD/DinasDetailsModel",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules,Models, DashboardAction) {
                    var querystr = Utility.parseQueryString(params);
                    if (querystr.Type != undefined || querystr.Type != "") {
                        var tipe = querystr.Type;
                    }
                    // Utility.IsLoading("#loading", "show");
                    
                    
                    var token = $('input[name="__RequestVerificationToken"]').val();
                    var m = new Models.DinasDetailsModel();
                    
                    // retrive data
                    m.fetch({
                        data: $.param({ __RequestVerificationToken: token,id:id,SharedId:sharedid,tipe:tipe }),
                        type: 'POST',
                        dataType: 'json',
                        success: function (data) {
                             // header render
                            $headerAction.html(new DashboardAction().render().el);
                            // body render
                            $content.html(new views.DinasSppdDetails({
                                model:data
                            }).render(sharedid,id,querystr).el);

                            // Load Modules
                            Modules.Index(sharedid,id,querystr);

                        }
                    });
                    
                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();

                });


            });
            
            // -------------- END SPPD --------------------- //
            
            
            
            
         
        } // End Init
    } // End Return
    
});