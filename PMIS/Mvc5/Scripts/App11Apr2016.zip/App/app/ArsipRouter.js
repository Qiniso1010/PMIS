define(function(require) {

  "use strict";

  var   //Backbone        = require('backbone'),
        // Handlerbars     = require('handlebars'),
        // Boostrap        = require('bootstrap.min'),
        // AdminLTE        = require('dist/js/app'),
        Utility         = require('utility'),
        // hbhelper        = require('handlebarshelper'),
        // iCheck          = require('icheck'),
        // Modernizr       = require('modernizr-2.8.3'),
        // swal            = require('sweetalert.min'),
        NProgress       = require('/Scripts/nprogress.js'),
        $content        = $("#content"),
        $default_routes = $('#routes').val(),
        $headerAction   = $("#content-header");
   
    return {
        Init:function(router) {
            
            
            // Ganti Password
            router.on("route:GantiPassword",function() {
               require([
                    "app/views/systems/GantiPasswordIndexView",
                    "app/views/systems/DashboardAction",
                    "app/models/systems/ChangePasswordModel"
               ],
               function(GantiPasswordIndexView, DashboardAction) {
                   
                    $headerAction.html(new DashboardAction().render().el);
                    var changePassword = new models.ChangePasswordModel();

                    changePassword.fetch({
                        success: function(data) {
                            

                            $content.html(new GantiPasswordIndexView({
                                model: data
                            }).render().el);
                        }
                    });
                    Utility.IsLoading("#loading", "hide");
               }); 
            });
            
            
            router.on("route:filesIndex", function() {
                require(
                [
                    "app/views/arsip/FilesIndex",
                    "app/modules/arsip/filesIndex",
                    "app/views/systems/DashboardAction"
                ],
                function(Views, Modules, DashboardAction) {
                    // Utility.IsLoading("#loading", "show");
                    NProgress.start();
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new Views.FilesIndexView().render().el);
                    // load content module
                    Modules.Index();
                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();


                });

            });
            
            router.on("route:filesAdd", function () {
                require(
                [
                    "app/views/arsip/FilesAdd",
                    "app/modules/arsip/filesAdd",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, DashboardAction) {
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.FilesAdd().render().el);

                    // Load Modules
                    Modules.Index();

                    // define logout
                    Utility.Logout();

                });


            });
            
            router.on("route:filesEdit", function (id) {
                require(
                [
                    "app/views/arsip/FilesEdit",
                    "app/modules/arsip/filesEdit",
                    "app/models/arsip/FilesEditModel",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, models, DashboardAction) {

                    // call data from model
                    var fect = new models.FilesEditModel({
                        id: id
                    });
                    NProgress.start();
                    // loading
                    // Utility.IsLoading("#loading", "show");
                    // retrive data
                    fect.fetch({
                        success: function (data) {
                            NProgress.done();
                            $headerAction.html(new DashboardAction().render().el);
                            
                            $content.html(new views.FilesEdit({
                                model: data
                            }).render().el);

                            // load modules
                            Modules.Index();

                        }
                    });

                    // define logout
                    Utility.Logout();


                });


            });
            
            router.on("route:filesUpload", function () {
                require(
                [
                    "app/views/arsip/FilesUpload",
                    "app/modules/arsip/filesUpload",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, DashboardAction) {
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.FilesUpload().render().el);

                    // Load Modules
                    Modules.Index();

                    // define logout
                    Utility.Logout();

                });


            });
            
            router.on("route:filesMore", function(id) {
                require(
                [
                    "app/views/arsip/FilesMore",
                    "app/modules/arsip/filesMore",
                    "app/views/systems/DashboardAction"

                ],
                function(Views, Modules, DashboardAction) {
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new Views.FilesMoreView().render().el);
                    // load content module
                    Modules.Index(id);

                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();


                });

            });
            
            router.on("route:filesMoreAdd", function (id) {
                require(
                [
                    "app/views/arsip/FilesMoreAdd",
                    "app/modules/arsip/filesMoreAdd",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, DashboardAction) {
                    NProgress.start();
                    
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.FilesMoreAdd().render(id).el);

                    // Load Modules
                    Modules.Index(id);

                    // define logout
                    Utility.Logout();

                });


            });
            
            router.on("route:filesMoreUpload", function (id) {
                require(
                [
                    "app/views/arsip/FilesMoreUpload",
                    "app/modules/arsip/filesMoreUpload",
                    "app/views/systems/DashboardAction"
                ],
                function (views, Modules, DashboardAction) {
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.FilesMoreUpload().render(id).el);

                    // Load Modules
                    Modules.Index(id);

                    // define logout
                    Utility.Logout();

                });


            });
            
            router.on("route:filesSharing", function(id) {
                require(
                [
                    "app/views/arsip/FilesSharing",
                    "app/modules/arsip/filesSharing",
                    "app/models/arsip/FileDetailsModel",
                    "app/views/systems/DashboardAction"
                ],
                function(Views, Modules,Model, DashboardAction) {
                    // Utility.IsLoading("#loading", "show");
                    NProgress.start();
                    var list = new Model.FileDetailsModel({id:id});
                    
                    list.fetch({
                       success:function(data) {
                            NProgress.done();
                            $headerAction.html(new DashboardAction().render().el);
                            
                            $content.html(new Views.FilesSharingView({
                                model: data
                            }).render().el);

                            // load modules
                            Modules.Index(id);
                       }
                        
                    });

                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();


                });

            });

            router.on("route:downloadFiles", function (id) {
                require(
                [
                    "app/views/arsip/FilesIndex",
                    "app/modules/arsip/filesIndex",
                    "app/views/systems/DashboardAction"
                ],
                function (Views, Modules, DashboardAction) {
                    // Utility.IsLoading("#loading", "show");
                    NProgress.start();
                    // header render
                    $headerAction.html(new DashboardAction().render().el);

                    if (id != null || id != "") {
                        window.location.href = "/Downloads/?token=" + id;
                    } else {
                        // body render
                        $content.html(new Views.FilesIndexView().render().el);
                        
                    }
                    // load content module
                    Modules.Index();
                
                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();


                });
            
            });
            
            router.on("route:filesShared", function () {
                require(
                [
                    "app/views/arsip/FilesSharedIndex",
                    "app/modules/arsip/filesSharedIndex",
                    "app/views/systems/DashboardAction"
                ],
                function(Views, Modules, DashboardAction) {
                    // Utility.IsLoading("#loading", "show");
                    NProgress.start();
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new Views.FilesSharedIndexView().render().el);
                    // load content module
                    Modules.Index();

                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();


                });

            });
    
            router.on("route:recentIndex", function () {
                require(
                [
                    "app/views/arsip/FilesRecentIndex",
                    "app/modules/arsip/filesRecentIndex",
                    "app/views/systems/DashboardAction"
                ],
                function(Views, Modules, DashboardAction) {
                    // Utility.IsLoading("#loading", "show");
                    NProgress.start();
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new Views.FilesRecentIndexView().render().el);
                    // load content module
                    Modules.Index();

                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();


                });

            });
    
            router.on("route:recycleIndex", function () {
                require(
                [
                    "app/views/arsip/FilesRecycleIndex",
                    "app/modules/arsip/filesRecycleIndex",
                    "app/views/systems/DashboardAction"
                ],
                function(Views, Modules, DashboardAction) {
                    // Utility.IsLoading("#loading", "show");
                    NProgress.start();
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new Views.FilesRecycleIndexView().render().el);
                    // load content module
                    Modules.Index();

                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();

                    


                });

            });
            
            
            
            
            
            
            
            
            
            
            
            
         
        } // End Init
    } // End Return
    
});