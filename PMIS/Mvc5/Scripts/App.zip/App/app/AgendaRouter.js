define(function(require) {

  "use strict";

  var   //Backbone        = require('backbone'),
        // Handlerbars     = require('handlebars'),
        // Boostrap        = require('bootstrap.min'),
        // AdminLTE        = require('dist/js/app'),
        
        // hbhelper        = require('handlebarshelper'),
        // iCheck          = require('icheck'),
        // Modernizr       = require('modernizr-2.8.3'),
        // swal            = require('sweetalert.min'),
        Utility         = require('utility'),
        NProgress       = require('/Scripts/nprogress.js'),
        $content        = $("#content"),
        $default_routes = $('#routes').val(),
        $headerAction   = $("#content-header");
   
    return {
        Init:function(router) {
            router.on("route:MeetingRoomMonthlyIndex",function(params) {
               require(
                [
                    "app/views/event/MeetingRoomIndex",
                    "app/modules/event/ModMeetingRoomIndex",
                    "app/views/systems/DashboardAction"
                ],
                function(Views, Modules, DashboardAction) {
                    var querystr = Utility.parseQueryString(params);
                    NProgress.start();
                    // Utility.IsLoading("#loading", "show");
                    
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new Views.MeetingRoomIndex().render(querystr).el);
                    
                    // load content module
                    Modules.Index(querystr);
                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();


                });
            });
            
            router.on("route:MeetingRoomWeeklyIndex", function(id,tanggal,params) {
                require(
                    [
                        "app/views/event/MeetingRoomWeekIndex",
                        "app/modules/event/ModMeetingRoomWeekIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.MeetingRoomWeekIndex().render().el);
                        
                        // load content module
                        Modules.Index(id,tanggal);
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
            
            router.on("route:InvitationIndex", function(params) {
                require(
                    [
                        "app/views/event/InvitationIndex",
                        "app/modules/event/ModInvitationIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.InvitationIndex().render(querystr).el);
                        
                        // load content module
                        Modules.Index(querystr);
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
            
                    
            router.on("route:ApprovalIndex",function(params) {
                require(
                    [
                        "app/views/event/ApprovalIndex",
                        "app/modules/event/ModApprovalIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        NProgress.start();
                        
                        var IsDefault = $('input[name="IsDefault"]').val();
                       
                        
                        if (IsDefault == "0") {
                            window.location.href = "#dashboard/index";
                        } else {
                        
                            // header render
                            $headerAction.html(new DashboardAction().render().el);
                            // body render
                            $content.html(new Views.ApprovalIndex().render(querystr).el);
                            
                            // load content module
                            Modules.Index(querystr);
                        
                        }
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
            
            router.on("route:RoomIndex", function(params) {
                require(
                    [
                        "app/views/event/RoomIndex",
                        "app/modules/event/ModRoomIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.RoomIndex().render().el);
                        
                        // load content module
                        Modules.Index(querystr);
                        
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });
            });
            
            router.on("route:RoomAdd", function() {
                require(
                    [
                    "app/views/event/RoomAdd",
                    "app/modules/event/ModRoomAdd",
                    "app/views/systems/DashboardAction"

                    ],
                    function(Views, Modules, DashboardAction) {
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.RoomAdd().render().el);
                        
                        // load content module
                        Modules.Index();
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });
            });
            
            router.on("route:RoomEdit", function (id) {
                require(
                    [
                        "app/views/event/RoomEdit",
                        "app/modules/event/ModRoomEdit",
                        "app/models/event/RoomDetails",
                        "app/views/systems/DashboardAction"
                    ],
                    function (views, Modules,models, DashboardAction) {
                        var IsDefault = $('input[name="IsDefault"]').val();
                        NProgress.start();
                        if (IsDefault == "0") {
                            window.location.href = "#dashboard/index";
                        } else {
                            // Utility.IsLoading("#loading", "show");
                        // call data from model
                            var fect = new models.RoomDetails({
                                id: id
                            });
                            // loading
                            // Utility.IsLoading("#loading", "show");
                            // retrive data
                            fect.fetch({
                                success: function (data) {
                                    $headerAction.html(new DashboardAction().render().el);
                                    
                                    $content.html(new views.RoomEdit({
                                        model: data
                                    }).render().el);

                                    // load modules
                                    Modules.Index();

                                }
                            });
                        }
                        
                        

                        // define logout
                        Utility.Logout();

                    });
            });
            
            router.on("route:AgendaAdd", function(id,tanggal,time,date,params) {
                require(
                    [
                        "app/views/event/AgendaAdd",
                        "app/modules/event/ModAgendaAdd",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        
                        // Utility.IsLoading("#loading", "show");
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.AgendaAdd({id:id,tanggal:date,param:querystr}).render(time,date,querystr).el);
                        
                        // load content module
                        Modules.Index(id,tanggal,querystr);
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
            
            router.on("route:AgendaView", function(id,tanggal,eventid,params) {
                require(
                    [
                        "app/views/event/AgendaView",
                        "app/modules/event/ModAgendaView",
                        "app/models/event/AgendaViewModel",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules,Models, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        
                        // Utility.IsLoading("#loading", "show");
                        
                        var list = new Models.AgendaViewModel({id:eventid});
                        
                        list.fetch({
                            success: function (data) {
                                $headerAction.html(new DashboardAction().render().el);
                                
                                $content.html(new Views.AgendaView({
                                    model: data
                                }).render().el);

                                // load modules
                                Modules.Index(id,tanggal,eventid,querystr);

                            }
                        });
                        
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();

                    });

            });
   
            router.on("route:AgendaEdit", function(id,tanggal,eventid,params) {
                require(
                    [
                        "app/views/event/AgendaEdit",
                        "app/modules/event/ModAgendaEdit",
                        "app/models/event/AgendaEditModel",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules,Models, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        NProgress.start();
                        
                        var IsDefault = $('input[name="IsDefault"]').val();
                        var list = new Models.AgendaEditModel({id:eventid});
                        
                        list.fetch({
                            success: function (data) {
                                $headerAction.html(new DashboardAction().render().el);
                                
                                $content.html(new Views.AgendaEdit({
                                    model: data
                                }).render().el);

                                // load modules
                                Modules.Index(id,tanggal,eventid,querystr);

                            }
                        });
                        // if (IsDefault == "0") {
                        //     window.location.href = "#dashboard/index";
                        // } else {
                        //     // Utility.IsLoading("#loading", "show");
                        
                        //     var list = new Models.AgendaEditModel({id:eventid});
                            
                        //     list.fetch({
                        //         success: function (data) {
                        //             $headerAction.html(new DashboardAction().render().el);
                                    
                        //             $content.html(new Views.AgendaEdit({
                        //                 model: data
                        //             }).render().el);

                        //             // load modules
                        //             Modules.Index(id,tanggal,eventid,querystr);

                        //         }
                        //     });
                            
                        // }
                        
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
            
            router.on("route:ProfileIndex", function(params) {
                require(
                    [
                        "app/views/event/ProfileIndex",
                        "app/modules/event/ModProfileIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.ProfileIndex().render(querystr).el);
                        
                        // load content module
                        Modules.Index(querystr);
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
    
            router.on("route:ProfileAdd", function() {
                require(
                    [
                        "app/views/event/ProfileAdd",
                        "app/modules/event/ModProfileAdd",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.ProfileAdd().render().el);
                        
                        // load content module
                        Modules.Index();
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
            
            router.on("route:ProfileEdit", function (id) {
                require(
                    [
                        "app/views/event/ProfileEdit",
                        "app/modules/event/ModProfileEdit",
                        "app/models/event/ProfileDetails",
                        "app/views/systems/DashboardAction"
                    ],
                    function (views, Modules,models, DashboardAction) {
                        var IsDefault = $('input[name="IsDefault"]').val();
                        NProgress.start();
                        if (IsDefault == "0") {
                            window.location.href = "#dashboard/index";
                        } else {
                            // Utility.IsLoading("#loading", "show");
                        // call data from model
                            var fect = new models.ProfileDetails({
                                id: id
                            });
                            // loading
                            // Utility.IsLoading("#loading", "show");
                            // retrive data
                            fect.fetch({
                                success: function (data) {
                                    $headerAction.html(new DashboardAction().render().el);
                                    
                                    $content.html(new views.ProfileEdit({
                                        model: data
                                    }).render().el);

                                    // load modules
                                    Modules.Index(id);

                                }
                            });
                        }
                        
                        

                        // define logout
                        Utility.Logout();

                    });
            });
    
            router.on("route:AgendaPimpinanIndex", function(params) {
                require(
                    [
                        "app/views/event/AgendaPimpinanIndex",
                        "app/modules/event/ModAgendaPimpinanIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        
                        // Utility.IsLoading("#loading", "show");
                        NProgress.start();
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.AgendaPimpinanIndex().render(querystr).el);
                        
                        // load content module
                        Modules.Index(querystr);
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
                    
            router.on("route:AgendaPimpinanWeeklyIndex", function(id,tanggal,params) {
                require(
                    [
                        "app/views/event/AgendaPimpinanWeeklyIndex",
                        "app/modules/event/ModAgendaPimpinanWeeklyIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        NProgress.start();
                        
                        // Utility.IsLoading("#loading", "show");
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.AgendaPimpinanWeeklyIndex().render().el);
                        
                        // load content module
                        Modules.Index(id,tanggal);
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();
                    });
            });
    
            router.on("route:AgendaPimpinanAdd",function(id,tanggal,time,date,params) {
                require(
                    [
                        "app/views/event/AgendaPimpinanAdd",
                        "app/modules/event/ModAgendaPimpinanAdd",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.AgendaPimpinanAdd({id:id,tanggal:date,param:querystr}).render(time,date).el);
                        
                        // load content module
                        Modules.Index(id,tanggal,querystr);
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
            
            router.on("route:AgendaPimpinanView", function(id,tanggal,eventid,params) {
                require(
                    [
                        "app/views/event/AgendaPimpinanView",
                        "app/modules/event/ModAgendaPimpinanView",
                        "app/models/event/AgendaPimpinanViewModel",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules,Models, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        
                        var list = new Models.AgendaPimpinanViewModel({id:eventid});
                        
                        list.fetch({
                            success: function (data) {
                                $headerAction.html(new DashboardAction().render().el);
                                
                                $content.html(new Views.AgendaPimpinanView({
                                    model: data
                                }).render().el);

                                // load modules
                                Modules.Index(id,tanggal,eventid,querystr);

                            }
                        });
                        
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
    
            router.on("route:AgendaPimpinanEdit", function(id,tanggal,eventid,params) {
                require(
                    [
                        "app/views/event/AgendaPimpinanEdit",
                        "app/modules/event/ModAgendaPimpinanEdit",
                        "app/models/event/AgendaEditModel",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules,Models, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        
                        var IsDefault = $('input[name="IsDefault"]').val();
                        NProgress.start();
                        
                        var list = new Models.AgendaEditModel({id:eventid});
                            
                        list.fetch({
                            success: function (data) {
                                $headerAction.html(new DashboardAction().render().el);
                                
                                $content.html(new Views.AgendaPimpinanEdit({
                                    model: data
                                }).render().el);

                                // load modules
                                Modules.Index(id,tanggal,eventid,querystr);

                            }
                        });
                        
                        // if (IsDefault == "0") {
                        //     window.location.href = "#dashboard/index";
                        // } else {
                        //     // Utility.IsLoading("#loading", "show");
                        
                        //     var list = new Models.AgendaEditModel({id:eventid});
                            
                        //     list.fetch({
                        //         success: function (data) {
                        //             $headerAction.html(new DashboardAction().render().el);
                                    
                        //             $content.html(new Views.AgendaPimpinanEdit({
                        //                 model: data
                        //             }).render().el);

                        //             // load modules
                        //             Modules.Index(id,tanggal,eventid,querystr);

                        //         }
                        //     });
                            
                        // }
                        
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
            
            // Agend Print
            router.on("route:AgendaPrint", function(params) {
                require(
                    [
                        "app/views/event/print/AgendaPrint",
                        "app/modules/event/print/ModAgendaPrint",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        
                        // Utility.IsLoading("#loading", "show");
                        NProgress.start();
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.AgendaPrint({params:querystr}).render(querystr).el);
                        
                        // load content module
                        Modules.Index(querystr);
                        
                        // End Loading
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
            
            
            // Agend Print
            router.on("route:AgendaPimpinanPrint", function(params) {
                require(
                    [
                        "app/views/event/print/AgendaPimpinanPrint",
                        "app/modules/event/print/ModAgendaPimpinanPrint",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        
                        // Utility.IsLoading("#loading", "show");
                        NProgress.start();
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.AgendaPimpinanPrint({params:querystr}).render(querystr).el);
                        
                        // load content module
                        Modules.Index(querystr);
                        
                        // End Loading
                        Utility.IsLoading("#loading", "hide");
                        

                        // define logout
                        Utility.Logout();


                    });

            });
            
            // Approval agenda pimpinan
            router.on("route:AgendaPimpinanApprovalIndex", function(params) {
                require(
                    [
                        "app/views/event/pimpinan/AgendaPimpinanApprovalIndex",
                        "app/modules/event/pimpinan/AgendaPimpinanApprovalIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        
                        // Utility.IsLoading("#loading", "show");
                        NProgress.start();
                        
                        var IsDefault = $('input[name="IsDefault"]').val();
                       
                        
                        if (IsDefault == "0") {
                            window.location.href = "#dashboard/index";
                        } else {
                            // Utility.IsLoading("#loading", "show");
                        
                            // header render
                            $headerAction.html(new DashboardAction().render().el);
                            // body render
                            $content.html(new Views.AgendaPimpinanApprovalIndex({params:querystr}).render(querystr).el);
                            
                            // load content module
                            Modules.Index(querystr);
                            
                        }
                        
                        
                        
                        
                        // End Loading
                        Utility.IsLoading("#loading", "hide");
                        

                        // define logout
                        Utility.Logout();


                    });

            });
            
            
            // Adding New Batih
            router.on("route:BatihAdd", function(id,params) {
                require(
                    [
                        "app/views/event/batih/BatihAdd",
                        "app/modules/event/batih/ModBatihAdd",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        
                        NProgress.start();
                        // Utility.IsLoading("#loading", "show");
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.BatihAdd().render(id,querystr).el);
                        
                        // load content module
                        Modules.Index(id,querystr);
                        
                        // End Loading
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
            
            // Edit Batih
            router.on("route:BatihEdit", function(id,params) {
                require(
                    [
                        "app/views/event/batih/BatihEdit",
                        "app/modules/event/batih/ModBatihEdit",
                        "app/models/event/batih/BatihEditModel",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules,Models, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        
                        // Utility.IsLoading("#loading", "show");
                        NProgress.start();
                        
                        var list = new Models.BatihEditModel({
                            id:id
                        });
                        
                        list.fetch({
                           success:function(data) {
                                // header render
                                $headerAction.html(new DashboardAction().render().el);
                                // body render
                                $content.html(new Views.BatihEdit({
                                    model:data
                                }).render(id,querystr).el);
                                
                                // load content module
                                Modules.Index(id,querystr);
                           } 
                            
                        });
                        
                        // End Loading
                        Utility.IsLoading("#loading", "hide");

                        // define logout
                        Utility.Logout();


                    });

            });
            
            
            // Manage Agenda pimpinan
            router.on("route:AgendaPimpinanManageIndex", function(params) {
                require(
                    [
                        "app/views/event/pimpinan/AgendaPimpinanManageIndex",
                        "app/modules/event/pimpinan/AgendaPimpinanManageIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        
                        // Utility.IsLoading("#loading", "show");
                        NProgress.start();
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.AgendaPimpinanManageIndex({params:querystr}).render(querystr).el);
                        
                        // load content module
                        Modules.Index(querystr);
                        
                        // End Loading
                        Utility.IsLoading("#loading", "hide");
                        

                        // define logout
                        Utility.Logout();


                    });

            });
            
            // Manage Agenda
            router.on("route:AgendaMeetingRoomManageIndex", function(params) {
                require(
                    [
                        "app/views/event/room/AgendaMeetingRoomManageIndex",
                        "app/modules/event/room/AgendaMeetingRoomManageIndex",
                        "app/views/systems/DashboardAction"
                    ],
                    function(Views, Modules, DashboardAction) {
                        var querystr = Utility.parseQueryString(params);
                        
                        // Utility.IsLoading("#loading", "show");
                        NProgress.start();
                        
                        // header render
                        $headerAction.html(new DashboardAction().render().el);
                        // body render
                        $content.html(new Views.AgendaMeetingRoomManageIndex({params:querystr}).render(querystr).el);
                        
                        // load content module
                        Modules.Index(querystr);
                        
                        // End Loading
                        Utility.IsLoading("#loading", "hide");
                        

                        // define logout
                        Utility.Logout();


                    });

            });
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        } // End Init
    } // End Return
    
});