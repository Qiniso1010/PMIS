define(function(require) {

  "use strict";

  var   //Backbone        = require('backbone'),
        // Handlerbars     = require('handlebars'),
        // Boostrap        = require('bootstrap.min'),
        // AdminLTE        = require('dist/js/app'),
        Utility         = require('utility'),
        // hbhelper        = require('handlebarshelper'),
        // iCheck          = require('icheck'),
        // Modernizr       = require('modernizr-2.8.3'),
        swal            = require('sweetalert.min'),

        $content        = $("#content"),
        $default_routes = $('#routes').val(),
        $headerAction   = $("#content-header");
   
    return {
        Init:function(router) {
            
            // // Default Index
            // router.on("route:dashboardIndex",function() {
            //     require([
            //         "hbtemplate",
            //         "jquery"
            //     ],function(hb, $) {
            //         var param = {
            //             id:'GET'
            //         };
            //         var options = {};
            //         options.url = 'Rooms/GetFirstId/';
            //         options.type = 'GET';
            //         options.data = param;
            //         options.dataType = 'json';
            //         options.cache = false;
            //         options.success = function(data) {
            //             var $Id = data.RoomId;
            //             var $Name = data.Name;
            //             if ($Id != undefined || $Id != 0) {
            //                 window.location.href = "#/agenda/meeting-room/monthly/index/?Id=" +$Id+"&Name="+$Name;
            //             } else {
            //                 window.location.href = "#/agenda/meeting-room/monthly/index";
            //             }
            //         };
            //         options.error = function(err) {
            //             alert(err.responseText);
            //         };
            //         $.ajax(options); 
            //     });
            // });
            
            // Ganti Password
            router.on("route:GantiPassword",function() {
               require([
                    "app/views/systems/GantiPasswordIndexView",
                    "app/views/systems/DashboardAction",
                    "app/models/systems/ChangePasswordModel"
               ],
               function(GantiPasswordIndexView, DashboardAction, models) {
                   
                    $headerAction.html(new DashboardAction().render().el);
                    var changePassword = new models.ChangePasswordModel();

                    // Utility.IsLoading("#loading", "show");

                    changePassword.fetch({
                        success: function(data) {
                        

                        $content.html(new GantiPasswordIndexView({
                            model: data
                        }).render().el);
                        }
                    });
                    
                    Utility.IsLoading("#loading", "hide");
               }); 
            });
         
        } // End Init
    } // End Return
    
});