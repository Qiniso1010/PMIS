
define(function (require) {
    var Utility              = require('utility'),
        ModalInviter        = require('app/views/event/modal/ModalInvite'),
        NProgress           = require('/Scripts/nprogress.js')
    

    return {
        Index : function(id,tanggal,eventid,querystr) {
            
            var appname = "View Details Agenda";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("agenda-view");
            Utility.SelectedToogleItem("ruang-rapat"); // parent

            $("#h1-header").html("View Details Agenda <small>Melihat secara lengkap.</small>");
            $("#header-page").html("View Details Agenda");
            
            if (querystr.ReturnUrl != undefined) {
                var ReturnUrl = querystr.ReturnUrl;
            } else {
                var ReturnUrl = "#/agenda/meeting-room/weekly/index/"+id+"/"+tanggal;
            }
            
            var IsDefault = $('input[name="IsDefault"]').val();
            var IsApprove = $('#IsApprove').val();
            var IsMind = $('#IsMind').val();
            // console.log(IsApprove);
            
            var htm = "";
            htm += "<li class='nav-users'><a href='"+ReturnUrl+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
            if (IsDefault === "1" || IsApprove == "false") {
                htm += "<li class='nav-users'><a href='#/agenda/meeting-room/weekly/edit/"+id+"/"+tanggal+"/"+eventid+"' id='btnEdit' role='button'> <i class='icon ion-ios-compose-outline'></i> Edit </a></li>";
                htm += "<li class='nav-users'><a href='javascript:;' data-id='"+eventid+"' id='btnDelete' role='button'> <i class='icon ion-ios-close-outline'></i> Delete </a></li>";
            }
            htm += "<li class='nav-users'><a href='javascript:;' data-id='"+eventid+"' id='btnAttend' role='button'> <i class='icon ion-ios-checkmark-outline'></i> Attend? </a></li>";
           
            if (IsMind == "true") {
                htm += "<li class='nav-users'><a href='javascript:;' data-id='"+eventid+"' id='btnInvite' role='button'> <i class='icon ion-person-add'></i> Mengundang? </a></li>";
   
            }
            
            $("#navigasi").html(htm);
            
            // delete button
            this.Delete(id,tanggal);
            
            // Attend
            this.Attend(id,tanggal);
            
             // View modal disposisi
            $("#btnInvite").click(function() {
               new ModalInviter.ModalInvite().render();
            });


            Utility.IsLoading("#loading", "hide");
            
        },
        Delete : function(idx,tanggal) {
            $('#btnDelete').click(function(e) {
                NProgress.start();
                var id = $(e.currentTarget).data('id');
                var $options = {};
                Utility.prosesLoad("Y");
                var token = $('input[name="__RequestVerificationToken"]').val();
                swal({
                    title: "Yakin ingin menghapus Agenda Ini.?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                   
                    Utility.IsLoading("#loading","show");
                    if (isConfirm) {
                        var param = {
                            id:id,
                            __RequestVerificationToken: token
                        };
                        
                        $options.url = "Schedules/Delete/";
                        $options.type = "POST";
                        $options.cache = false;
                        $options.data = param;
                        $options.dataType = "json";
                        $options.success = function(d) {
                            NProgress.done();
                            if (d.Attr == "Ok!") {
                                Utility.IsLoading("#loading","hide");
                                Utility.prosesLoad("N");
                                Utility.AlertV2("check",d.Message,"success");
                                window.location.href = "#/agenda/meeting-room/weekly/index/"+idx+"/"+tanggal;
                                
                            } else {
                                Utility.IsLoading("#loading","hide");
                                Utility.AlertV2("exclamation-triangle",d.Message,"error");
                            }
                        };
                        $options.error = function(err) {
                            alert(err.responseText);  
                            Utility.prosesLoad("N");
                            Utility.IsLoading("#loading","hide");
                        };
                        $.ajax($options);
                    } else {
                         Utility.IsLoading("#loading","hide");
                    }
                });
            });
        },
        Attend : function(idx,tanggal) {
            $('#btnAttend').click(function(e) {
                var id = $(e.currentTarget).data('id');
                var $options = {};
                Utility.prosesLoad("Y");
                var token = $('input[name="__RequestVerificationToken"]').val();
                swal({
                    title: "Yakin ingin datang pada Agenda Ini.?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                   
                    Utility.IsLoading("#loading","show");
                    if (isConfirm) {
                        var param = {
                            id:id,
                            __RequestVerificationToken: token
                        };
                        
                        $options.url = "Schedules/Attend/";
                        $options.type = "POST";
                        $options.cache = false;
                        $options.data = param;
                        $options.dataType = "json";
                        $options.success = function(d) {
                            if (d.Attr == "Ok!") {
                                Utility.IsLoading("#loading","hide");
                                Utility.prosesLoad("N");
                                 Utility.AlertV2("check",d.Message,"success");
                                
                            } else {
                                Utility.IsLoading("#loading","hide");
                                Utility.AlertV2("exclamation-triangle",d.Message,"error");
                            }
                        };
                        $options.error = function(err) {
                            alert(err.responseText);  
                            Utility.prosesLoad("N");
                            Utility.IsLoading("#loading","hide");
                        };
                        $.ajax($options);
                    } else {
                         Utility.IsLoading("#loading","hide");
                    }
                });
            });
        }    
    };
});