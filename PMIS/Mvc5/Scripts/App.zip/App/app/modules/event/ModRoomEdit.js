
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function() {
            
            var appname = "Edit data Ruangan";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("manage-ruang-rapat");
            Utility.SelectedToogleItem("ruang-rapat"); // parent

            $("#h1-header").html(appname +" <small>Mengubah data sebelumnya</small>");
            $("#header-page").html(appname);
            
            var htm = "";
            htm += "<li class='nav-users'><a href='#/agenda/meeting-room/rooms/index' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";

            $("#navigasi").html(htm);


            Utility.IsLoading("#loading", "hide");
            
        }  
    };
});