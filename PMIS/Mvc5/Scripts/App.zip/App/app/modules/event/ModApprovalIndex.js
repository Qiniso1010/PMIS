define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min'),
        NProgress           = require('/Scripts/nprogress.js')

    return {
        Index: function (params) {
            // table
            this.Table();
            // caption form
            this.Caption();

            this.Nav();

            // this.init('ajax');
            this.Approve();
            // this.Reject();
        },
        Nav: function() {
            var IsDefault = $('input[name="IsDefault"]').val();
            var htm = "";
            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";

            if (IsDefault === "1") {
                htm += "<li class='nav-role-del'><a href='javascript:;' id='btnApprove' role='button'> <i class='icon ion-ios-checkmark-outline'></i> Approve? </a></li>";
                // htm += "<li class='nav-role-del'><a href='javascript:;' id='btnReject' role='button'> <i class='icon ion-ios-close-outline'></i> Reject / Unreject? </a></li>";

            }
            $("#navigasi").html(htm);

            // refresh
            $("#btnRefresh").on("click", function () {
                $('#listing-grid').bootstrapTable('refresh');
            });

            $('#btnApprove').hide();
            $('#btnReject').hide();
        },
        Caption: function() {
            // define title constant
            var appname = "Menunggu Persetujuan";

            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("menunggu-persetujuan");
            Utility.SelectedToogleItem("ruang-rapat"); // parent

            $("#h1-header").html(appname + "<small>Listing Agenda yang di pesan untuk digunakan</small>");
            $("#header-page").html(appname);

        },
        Table: function() {
            
            NProgress.start();
            // listing
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Books/',
                cache: false,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: false,
                showRefresh: true,
                cardView: false,
                showToggle: false,
                showExport: false,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [{
                    field: 'stat',
                    checkbox: true
                }, {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                },
                {
                    field: 'NameAndId',
                    title: 'Title',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'Tanggal',
                    title: 'Tanggal',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'CreatedBy',
                    title: 'Dibuat Oleh',
                    align: 'right',
                    valign: 'middle',
                    sortable: true
                }],
                onCheck: function (row) {
                    $("#btnApprove").show();
                    $("#btnReject").show();
                },
                onUncheck: function (row) {
                    $("#btnApprove").hide();
                    $("#btnReject").hide();
                },
                onCheckAll: function () {
                    $("#btnApprove").show();
                    $("#btnReject").show();
                },
                onUncheckAll: function () {
                    $("#btnApprove").hide();
                    $("#btnReject").hide();
                },
                onLoadSuccess: function() {
                    NProgress.done();
                }
            });
        },
        Reject: function() {
            $("#btnReject").on("click", function () {
                UnApprove();
            });

             // delete
            function UnApprove() {
                swal({
                    title: "Yakin ingin?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        // Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                UnApproveAction(param[i].Id);
                            }

                            $("#btnReject").hide();

                            Utility.prosesLoad("N");
                            // Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            // Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            var token = $('input[name="__RequestVerificationToken"]').val();

            // delete action
            function UnApproveAction(id) {
                var param = {
                    id: id,
                    __RequestVerificationToken: token,
                }
                var url = 'Schedules/Reject/';
                var $options = {};

                $options.url = url;
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    if (d.Attr == "Ok!") {
                        Utility.AlertV2("check", d.Message, "success");
                    } else {
                        Utility.AlertV2("remove", d.Message, "error");
                    }

                    $('#listing-grid').bootstrapTable('refresh');
                };
                $options.error = function(err) {
                   alert(err.responseText);
                };
                $.ajax($options);

            }
            // end action

        },
        Approve: function () {

            /// delete button action
            $("#btnApprove").on("click", function () {
                Approve();
            });

            // delete
            function Approve() {
                swal({
                    title: "Yakin ingin approve book agenda ini?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        // Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                ApproveAction(param[i].Id);
                            }

                            $("#btnDelete").hide();

                            Utility.prosesLoad("N");
                            // Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            // Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            var token = $('input[name="__RequestVerificationToken"]').val();

            // delete action
            function ApproveAction(id) {
                NProgress.start();
                Utility.IsLoading("#loading", "show");
                var param = {
                    id: id,
                    __RequestVerificationToken: token,
                }
                var url = 'Books/Approve/';
                var $options = {};

                $options.url = url;
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    NProgress.done();
                    if (d.Attr == "Ok!") {
                        Utility.IsLoading("#loading", "hide");
                        Utility.AlertV2("check", d.Message, "success");
                    } else {
                        Utility.AlertV2("remove", d.Message, "error");
                        Utility.IsLoading("#loading", "hide");
                    }

                    $('#listing-grid').bootstrapTable('refresh');
                };
                $options.error = function(err) {
                    alert(err.responseText);
                    Utility.IsLoading("#loading", "hide");
                };
                $.ajax($options);

            }
            // end action
        }


    };
});
