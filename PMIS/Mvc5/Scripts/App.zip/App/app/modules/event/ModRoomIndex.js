define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min'),
        NProgress           = require('/Scripts/nprogress.js')

    return {
        Index: function () {
            // Top Nav
            this.Nav();
            // table
            this.Table();
            // caption form
            this.Caption();
            
            this.Delete();
            
            // this.init('ajax');
        },
        Nav: function () {
            // action
            var htm = "";
            htm += "<li class='nav-role'><a href='#/agenda/meeting-room/rooms/add' id='btnAdd' role='button'> <i class='icon ion-ios-plus-outline'></i> Add New </a></li>";
         
            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnDelete' role='button'> <i class='icon ion-ios-close-outline'></i> Delete </a></li>";
            
            $("#navigasi").html(htm);
            // end nav top


        },
        Caption: function() {
            // define title constant
            var appname = "Manage Ruang Rapat / Gedung";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("manage-ruang-rapat");
            Utility.SelectedToogleItem("ruang-rapat"); // parent

            $("#h1-header").html(appname +  "<small>Mengelola data master Ruangan / Gedung</small>");
            $("#header-page").html(appname);

        },
        Table: function() {
            NProgress.start();
            // listing
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Rooms/',
                cache: false,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: false,
                showRefresh: true,
                cardView: false,
                showToggle: false,
                showExport: false,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [{
                    field: 'stat',
                    checkbox: true
                }, {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, 
                {
                    field: 'NameAndId',
                    title: 'Name',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'Address',
                    title: 'Alamat',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'UpdatedAt',
                    title: 'Date Modified',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'UpdBy',
                    title: 'Created by',
                    align: 'center',
                    valign: 'middle',
                    sortable: true
                }],
                onCheck: function (row) {
                    $("#btnDelete").show();
                },
                onUncheck: function (row) {
                    $("#btnDelete").hide();
                },
                onCheckAll: function () {
                    $("#btnDelete").show();
                },
                onUncheckAll: function () {
                    $("#btnDelete").hide();
                },
                onLoadError: function(err) {
                    alert(err);
                },
                onLoadSuccess: function() {
                    NProgress.done();
                }
            });
        },
        Delete: function () {

            /// delete button action
            $("#btnDelete").on("click", function () {
                Delete();
            });

            // delete
            function Delete() {
                swal({
                    title: "Yakin ingin menghapus data?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        // Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                DeleteAction(param[i].Id);
                            }

                            $("#btnDelete").hide();

                            Utility.prosesLoad("N");
                            // Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            // Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            var token = $('input[name="__RequestVerificationToken"]').val();

            // delete action
            function DeleteAction(id) {
                NProgress.start();
                var param = {
                    id: id,
                    __RequestVerificationToken: token,
                }
                var url = 'Rooms/Delete/';
                var $options = {};
                
                $options.url = url;
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    NProgress.done();
                    if (d.Attr == "Ok!") {
                        Utility.AlertV2("check", d.Message, "success");
                    } else {
                        Utility.AlertV2("remove", d.Message, "error");
                    }

                    $('#listing-grid').bootstrapTable('refresh');
                };
                $options.error = function(err) {
                   alert(err.responseText);
                };
                $.ajax($options);
               
            }
            // end action
        }
        

    };
});
