
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function(id,tanggal) {
            
            var appname = "Penambahan Agenda";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("agenda-view");
            Utility.SelectedToogleItem("ruang-rapat"); // parent

            $("#h1-header").html(appname + "<small>Membuat agenda, dengan mengisikan data - data di kolom bawah ini.</small>");
            $("#header-page").html(appname);
            
            var htm = "";
            htm += "<li class='nav-users'><a href='#/agenda/meeting-room/weekly/index/"+id+"/"+tanggal+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";

            $("#navigasi").html(htm);


            Utility.IsLoading("#loading", "hide");
            
        }  
    };
});