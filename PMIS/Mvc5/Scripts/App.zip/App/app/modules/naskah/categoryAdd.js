
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function() {
             
            Utility.SelectedMenuItem("manage");
            Utility.SelectedToogleItem("tata-naskah-dinas");

            $("#title-header").html("Membuat Kategori ");

            $("#h1-header").html("Membuat Kategori");
            $("#header-page").html("Membuat Kategori");

            // action
            var htm = "";
            htm += "<li class='nav-users'><a href='#/naskah/index' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";

            $("#navigasi").html(htm);


            Utility.IsLoading("#loading", "hide");
            
        }  
    };
});