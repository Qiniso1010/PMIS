define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min'),
        NProgress           = require('/Scripts/nprogress.js')

    return {
        Index: function () {

            // table
            this.Table();

        },
        Table: function() {
             // listing
             NProgress.start();
             $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Files/',
                cache: false,
                //height: 500,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: true,
                showRefresh: true,
                cardView: false,
                showToggle: true,
                showExport: true,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [{
                    field: 'stat',
                    checkbox: true
                }, {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, {
                    field: 'NameAndId',
                    title: 'Name',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'NameAndId',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Shared'
                },
                {
                    field: 'UpdatedAt',
                    title: 'Date Modified',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'UplBy',
                    title: 'Created by',
                    align: 'center',
                    valign: 'middle',
                    sortable: true
                }, {
                    field: 'FileSize',
                    title: 'Size',
                    align: 'right',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'TypeData',
                    visible: false
                }],
                onCheck: function (row) {
                    $("#btnDelete").show();
                },
                onUncheck: function (row) {
                    $("#btnDelete").hide();
                },
                onCheckAll: function () {
                    $("#btnDelete").show();
                },
                onUncheckAll: function () {
                    $("#btnDelete").hide();
                },
                onLoadError: function(err) {
                    alert(err);
                },
                onLoadSuccess: function() {
                    NProgress.done();
                }
            });
        },
        Move:function () {
            $("#btnMove").on("click", function () {
                Move();
            });
            
           function Move() {
                Utility.prosesLoad("Y");
                // Utility.IsLoading("#loading", "show");

                var param = Array();
                param = $('#listing-grid').bootstrapTable('getSelections');

                var i;
                if (param.length > 0) {
                    for (i = 0; i < param.length; i++) {
                        MoveAction(param[i].Id, param[i].TypeData);
                    }

                    $("#btnDelete").hide();

                    Utility.prosesLoad("N");
                    // Utility.IsLoading("#loading", "hide");
                } else {
                    Utility.AlertV2("remove", "Please select data first", "error");
                    Utility.IsLoading("#loading", "hide");
                }
            }
            
            // Move Action
            function MoveAction(id,tipe) {
                var $options = {};
                if (tipe == "B") {
                    swal("Pindahkan dokumen berhasil."); 
                    //  $.ajax({
                    //     url: url,
                    //     cache: false,
                    //     type: 'POST',
                    //     data: param,
                    //     dataType: 'json',
                    //     success: function (d) {
                    //         if (d.Attr == "Ok!") {
                    //             Utility.AlertV2("check", d.Message, "success");
                    //         } else {
                    //             Utility.AlertV2("remove", d.Message, "error");
                    //         }

                    //         $('#listing-grid').bootstrapTable('refresh');
                    //     },
                    //     error: function (err) {
                    //         alert(err.responseText);
                    //     }
                    // });
                }
                else 
                {
                    swal("Dokumen saja dapat dipindahkan.");    
                }
                
            }
        },
        Delete: function () {

            /// delete button action
            $("#btnDelete").on("click", function () {
                Delete();
            });

            // delete
            function Delete() {
                swal({
                    title: "Yakin ingin menghapus File?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                DeleteAction(param[i].Id, param[i].TypeData);
                            }

                            $("#btnDelete").hide();

                            Utility.prosesLoad("N");
                            Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            var token = $('input[name="__RequestVerificationToken"]').val();

            // delete action
            function DeleteAction(id, tipe) {
                if (tipe == 'B') {
                    var param = {
                        id: id,
                        __RequestVerificationToken: token
                    }

                    var url = 'Categories/DeleteLaporan/';
                } else {
                    var param = {
                        id: id,
                        __RequestVerificationToken: token,
                    }

                    var url = 'Categories/Delete/';
                }
                $.ajax({
                    url: url,
                    cache: false,
                    type: 'POST',
                    data: param,
                    dataType: 'json',
                    success: function (d) {
                        if (d.Attr == "Ok!") {
                            Utility.AlertV2("check", d.Message, "success");
                        } else {
                            Utility.AlertV2("remove", d.Message, "error");
                        }

                        $('#listing-grid').bootstrapTable('refresh');
                    },
                    error: function (err) {
                        alert(err.responseText);
                    }
                });
            }
            // end action
        }

    };
});
