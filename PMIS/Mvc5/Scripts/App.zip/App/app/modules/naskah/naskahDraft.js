
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function(sharedid,id,querystr) {
             
            // menu
            Utility.SelectedMenuItem("manage");
            Utility.SelectedToogleItem("tata-naskah-dinas");

            $("#title-header").html("Edit Draft Naskah");

            $("#h1-header").html("Draft Naskah <small>Edit</small>");
            $("#header-page").html("Edit Draft Naskah");
            
            var str =  querystr.ReturnUrl;
            // action
            var htm = "";
            htm += "<li class='nav-roles'><a href='"+str+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
            $("#navigasi").html(htm);
            // loading
            Utility.IsLoading("#loading", "hide");   
            
        }
       
    };
});