define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min'),
        NProgress           = require('/Scripts/nprogress.js')

    return {
        Index: function () {
            // Top Nav
            this.Nav();
            // table
            this.Table();
            // caption form
            this.Caption();
            
            // Delete 
            this.Delete();
        },
        Nav: function () {
            // action
            var htm = "";
            htm += "<li class='nav-role'><a href='#/naskah/master-template/new' id='btnUpload' role='button'> <i class='icon ion-ios-plus-outline'></i> Membuat Template Naskah Dinas </a></li>";

            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnDelete' role='button'> <i class='icon ion-ios-close-outline'></i> Delete </a></li>";
            $("#navigasi").html(htm);
            // end nav top
            $('#btnDelete').hide();

        },
        Caption: function() {
            // define title constant
            var appname = "Template Dokumen";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("master-template");
            Utility.SelectedToogleItem("tata-naskah-dinas"); // parent

            $("#h1-header").html("Template <small>Maste template dokumen </small>");
            $("#header-page").html("Template Dokumen");

            // refresh
            $("#btnRefresh").on("click", function () {
                $('#listing-grid').bootstrapTable('refresh');
            });
        },
        Table: function() {
            NProgress.start();
            // listing
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'TemplateDocs/',
                cache: false,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: true,
                showRefresh: true,
                cardView: false,
                showToggle: true,
                showExport: true,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [{
                    field: 'stat',
                    checkbox: true
                }, {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, {
                    field: 'NameAndId',
                    title: 'Name',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'NameAndId',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'IsActive'
                },
                {
                    field: 'CreatedAt',
                    title: 'Created At',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'Updby',
                    title: 'Created By',
                    align: 'center',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'TypeData',
                    visible: false
                }],
                onCheck: function (row) {
                    $("#btnDelete").show();
                },
                onUncheck: function (row) {
                    $("#btnDelete").hide();
                },
                onCheckAll: function () {
                    $("#btnDelete").show();
                },
                onUncheckAll: function () {
                    $("#btnDelete").hide();
                },
                onLoadSuccess: function() {
                    NProgress.done();
                }
            });
        },
        Delete: function () {

            /// delete button action
            $("#btnDelete").on("click", function () {
                Delete();
            });

            // delete
            function Delete() {
                swal({
                    title: "Yakin ingin menghapus File?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        // Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                DeleteAction(param[i].Id);
                            }

                            $("#btnDelete").hide();

                            Utility.prosesLoad("N");
                            // Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            var token = $('input[name="__RequestVerificationToken"]').val();

            // delete action
            function DeleteAction(id) {
                NProgress.start();
                var param = {
                    id: id,
                    __RequestVerificationToken: token,
                }
                var url = 'TemplateDocs/Delete/';
                $.ajax({
                    url: url,
                    cache: false,
                    type: 'POST',
                    data: param,
                    dataType: 'json',
                    success: function (d) {
                        NProgress.done();
                        if (d.Attr == "Ok!") {
                            Utility.AlertV2("check", d.Message, "success");
                        } else {
                            Utility.AlertV2("remove", d.Message, "error");
                        }

                        $('#listing-grid').bootstrapTable('refresh');
                    },
                    error: function (err) {
                        alert(err.responseText);
                    }
                });
            }
            // end action
        }

    };
});
