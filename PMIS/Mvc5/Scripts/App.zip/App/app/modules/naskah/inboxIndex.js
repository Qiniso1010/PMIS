define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min'),
        NProgress           = require('/Scripts/nprogress.js')

    return {
        Index: function () {
            // Top Nav
            this.Nav();
            // table
            this.Table();
            // caption form
            this.Caption();
        },
        Nav: function () {
            // action
            var htm = "";
            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
           
            $("#navigasi").html(htm);
            // end nav top


        },
        Caption: function() {
            // define title constant
            var appname = "Inbox";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("inbox");
            Utility.SelectedToogleItem("tata-naskah-dinas"); // parent

            $("#h1-header").html("Inbox <small>Dokumen yang telah diterima </small>");
            $("#header-page").html("Inbox");

            // refresh
            $("#btnRefresh").on("click", function () {
                $('#listing-grid').bootstrapTable('refresh');
            });
        },
        Table: function() {
            // listing
            NProgress.start();
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Inboxs/',
                cache: false,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: true,
                showRefresh: true,
                cardView: false,
                showToggle: true,
                showExport: true,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [
                {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, 
                {
                    field: 'Kode',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'Tanggal',
                    title: 'Tanggal',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'NameAndId',
                    title: 'Name',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'Perihal',
                    title: 'Judul / Perihal',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'NameAndId',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Shared'
                },
                {
                    field: 'UpdatedAt',
                    title: 'Date Modified',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'UplBy',
                    title: 'Created by',
                    align: 'center',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'TypeData',
                    visible: false
                }],
                onLoadError: function(err) {
                    alert(err);
                },
                onLoadSuccess: function() {
                    NProgress.done();
                }
            });
        }

    };
});
