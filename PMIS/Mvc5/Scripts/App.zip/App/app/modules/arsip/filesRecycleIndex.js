define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min'),
        NProgress           = require('/Scripts/nprogress.js')

    return {
        Index: function () {

            // Top Nav
            this.Nav();
            // table
            this.Table();
            // caption form
            this.Caption();
            // Delete 
            this.Restore();

            this.Delete();

            this.Empty();

        },
        Nav: function () {
          
            var htm = "";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnRestore' role='button'> <i class='icon ion-ios-undo-outline'></i> Restore </a></li>";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnDelete' role='button'> <i class='icon ion-ios-close-outline'></i> Delete! </a></li>";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnEmpty' role='button'> <i class='icon ion-ios-minus-outline'></i> Empty! </a></li>";

            htm += "<li class='nav-role-refresh'><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            $("#navigasi").html(htm);
            // end nav top

            // hide action buttonbtnRestore
            $("#btnRestore").hide();
            $("#btnDelete").hide();
        },
        Caption: function() {
            // define title constant
            $("#title-header").html("Recycle Bin");
            // menu
            Utility.SelectedMenuItem("recycle-bin");
            Utility.SelectedToogleItem("arsip"); // parent

            $("#h1-header").html("Recycle Bin");
            $("#header-page").html("Recycle Bin");

            // refresh
            $("#btnRefresh").on("click", function () {
                $('#listing-grid').bootstrapTable('refresh');
            });
        },
        Table: function() {
            
            NProgress.start();
            // listing
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Recycles/',
                cache: false,
                //height: 500,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: true,
                showRefresh: true,
                cardView: false,
                showToggle: true,
                showExport: true,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [{
                    field: 'stat',
                    checkbox: true
                }, {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, {
                    field: 'NameAndId',
                    title: 'Name',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'CreatedAt',
                    title: 'Date Modified',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                }, {
                    field: 'FileSize',
                    title: 'Size',
                    align: 'right',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'TypeData',
                    visible: false
                }],
                onCheck: function (row) {
                    $("#btnRestore").show();
                    $("#btnDelete").show();
                },
                onUncheck: function (row) {
                    $("#btnRestore").hide();
                    $("#btnDelete").hide();
                },
                onCheckAll: function () {
                    $("#btnRestore").show();
                    $("#btnDelete").show();
                },
                onUncheckAll: function () {
                    $("#btnRestore").hide();
                    $("#btnDelete").hide();
                },
                onLoadSuccess: function() {
                    NProgress.done();
                }
            });
        },
        Empty: function () {
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            $("#btnEmpty").on("click", function () {
                swal({
                    title: "Yakin ingin Mengosongkan Recycle bin?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Empty();
                    }
                });

                function Empty() {
                    var param = {
                        __RequestVerificationToken: token
                    };
                    var options = {};
                    options.url = 'Recycles/Empty/';
                    options.type = 'POST';
                    options.data = param;
                    options.dataType = 'json';
                    options.cache = false;
                    options.success = function (data) {
                        NProgress.done();
                        if (data.Attr == "Ok!") {
                            Utility.AlertV2("check", data.Message, "success");
                        } else {
                            Utility.AlertV2("remove", data.Message, "error");
                        }

                        $('#listing-grid').bootstrapTable('refresh');
                    };
                    options.error = function (err) {
                        alert(err.responseText);
                    };
                    $.ajax(options);
                }
                
            });

        },
        Restore: function () {

            /// delete button action
            $("#btnRestore").on("click", function () {
                Restore();
            });

            // delete
            function Restore() {
                swal({
                    title: "Yakin ingin Restore File ini?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        // Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                RestoreAction(param[i].Id);
                            }

                            $("#btnRestore").hide();

                            Utility.prosesLoad("N");
                            // Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            // Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            var token = $('input[name="__RequestVerificationToken"]').val();

            // delete action
            function RestoreAction(id) {
                NProgress.start();
                var param = {
                    id: id,
                    __RequestVerificationToken: token,
                }

                var url = 'Recycles/RestoreFile/';
                $.ajax({
                    url: url,
                    cache: false,
                    type: 'POST',
                    data: param,
                    dataType: 'json',
                    success: function (d) {
                        NProgress.done();
                        if (d.Attr == "Ok!") {
                            Utility.AlertV2("check", d.Message, "success");
                        } else {
                            Utility.AlertV2("remove", d.Message, "error");
                        }

                        $('#listing-grid').bootstrapTable('refresh');
                    },
                    error: function (err) {
                        alert(err.responseText);
                    }
                });
            }
            // end action
        },
        Delete: function () {
            
            /// delete button action
            $("#btnDelete").on("click", function () {
                Delete();
            });

            // delete
            function Delete() {
                swal({
                    title: "Yakin ingin Delete File ini?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        // Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                DeleteAction(param[i].Id);
                            }

                            $("#btnDelete").hide();

                            Utility.prosesLoad("N");
                            // Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            // Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            var token = $('input[name="__RequestVerificationToken"]').val();

            // delete action
            function DeleteAction(id) {
                NProgress.start();
                var param = {
                    id: id,
                    __RequestVerificationToken: token,
                }

                var url = 'Recycles/Delete/';
                $.ajax({
                    url: url,
                    cache: false,
                    type: 'POST',
                    data: param,
                    dataType: 'json',
                    success: function (d) {
                        NProgress.done();
                        if (d.Attr == "Ok!") {
                            Utility.AlertV2("check", d.Message, "success");
                        } else {
                            Utility.AlertV2("remove", d.Message, "error");
                        }

                        $('#listing-grid').bootstrapTable('refresh');
                    },
                    error: function (err) {
                        alert(err.responseText);
                    }
                });
            }
            // end action
        }

    };
});
