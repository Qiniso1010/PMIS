
define(function (require) {
    var Utility             = require('utility'),
        NProgress           = require('/Scripts/nprogress.js')

    return {
        Index : function(id) {
             
            Utility.SelectedMenuItem("files");
            Utility.SelectedToogleItem("arsip");

            this.GetNameFile(id);

            Utility.IsLoading("#loading", "hide");
            
        },
        GetNameFile: function (id) {
            NProgress.start();
            var token = $('input[name="__RequestVerificationToken"]').val();

            var param = {
                id: id,
                __RequestVerificationToken: token
            }

            var url = 'Files/GetFileData/';
            var options = {};
            options.url = url;
            options.cache = false;
            options.type = 'POST';
            options.data = param;
            options.success = function (d) {
                NProgress.done();
                if (d.length != 0) {
                    store.set('namefile', {
                        name: d.Name,
                        filetipe: d.FileTipe,
                        path: d.FilePath,
                        unitid: d.UnitId,
                        uplby: d.UplBy,
                        filesize: d.FileSize,
                        SharedId: d.SharedId,
                        UnitName: d.UnitName,
                        FileId: d.FileId
                    });

                    var data = store.get('namefile');
                    $("#title-header").html("Sharing : " + data.name);

                    $("#h1-header").html("Sharing  <small>" + data.name + "</small>");
                    $("#header-page").html("Sharing File : " + data.name);

                    var UrlReturn = store.get('cid');

                    if (UrlReturn != null) {
                        if (UrlReturn.ParentId == 0) {
                            var url = "#/arsip/files/index";
                        } else {
                            var url = "#/arsip/files/more/" + UrlReturn.ParentId;
                        }
                    } else {
                        var url = "#/arsip/files/index";
                    }

                   

                    // action
                    var htm = "";
                    htm += "<li class='nav-users'><a href='"+url+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
                    $("#navigasi").html(htm);

                    $('#filename').val(data.name);
                    $('#path').val(data.path);
                    $('#filetipe').val(data.filetipe);
                    $('#unitid').val(data.unitid);
                    $('#SharedId').val(data.SharedId);
                    $('#filesize').val(data.filesize);
                    $('#UnitName').val(data.UnitName);
                    $('#uplby').val(data.uplby);
                    $('#id').val(data.FileId);


                }

            };
            options.error = function (err) {
                alert(err.responseText);
            };
            $.ajax(options);
        }
       
    };
});