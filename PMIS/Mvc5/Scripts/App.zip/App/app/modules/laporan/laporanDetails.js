
define(function (require) {
    var $                   = require('jquery'),
        Utility             = require('utility'),
        viewmoddisposisi    = require('app/views/laporan/ModalDisposisi')

    return {
        Index : function(sharedid,id,querystr) {
            // menu
            Utility.SelectedMenuItem("laporan");
            Utility.SelectedToogleItem("menu-laporan");

            $("#title-header").html("Laporan Selengkapnya");

            $("#h1-header").html("Laporan <small>Detil</small>");
            $("#header-page").html("Laporan Selengkapnya");
            var current = store.get("Current")
            if (querystr.ReturnUrl != undefined) {
                var str =  querystr.ReturnUrl;
            } else {
                var str = "#/laporan/index";
            }
            // action
            var htm = "";
            htm += "<li class='nav-roles'><a href='"+str+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
            htm += "<li class='nav-roles'><a href='javascript:;' id='btnDisposisiUnit' role='button'> <i class='icon ion-ios-plus-outline'></i> Disposisikan kembali </a></li>";
            htm += "<li class='nav-roles'><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            $("#navigasi").html(htm);
            // loading
            Utility.IsLoading("#loading", "hide");   
            
            // alert(querystr.ReturUrl);
            
            // View modal disposisi
            $("#btnDisposisiUnit").click(function() {
               new viewmoddisposisi.ModalDisposisi().render();
            });
            
            $("#btnRefresh").click(function() {
                location.reload(); 
            });
            
            
        }
       
    };
});