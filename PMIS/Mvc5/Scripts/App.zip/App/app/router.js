define(function(require) {

  "use strict";

var $               = require('jquery'),
    Backbone        = require('backbone'),
    // Backbone_Modal  = require('/Scripts/backbone-modal.js'),
    Handlerbars     = require('handlebars'),
    Boostrap        = require('bootstrap.min'),
    Utility         = require('utility'),
    HandlerHelper   = require('handlebarshelper'),
    iCheck          = require('icheck'),
    Modernizr       = require('modernizr-2.8.3'),
    swal            = require('sweetalert.min'),
    // store           = require('/Scripts/store.min.js'),
    // moment          = require('moment'),
    // Backbone_query  = require('/Scripts/backbone.queryparams.js'),
    Idle            = require('/Scripts/idle.js'),
    NProgress       = require('/Scripts/nprogress.js'),
    autocomplete    = require('jquery-ui'),
    AdminLTE        = require('dist/js/app'),
    // tokeninput      = require('/Scripts/jquery.tokeninput.js'),


    $content        = $("#content"),
    $default_routes = $('#routes').val(),
    $headerAction   = $("#content-header");

  return Backbone.Router.extend({
    routes: {
      "": 'dashboardIndex',
      "dashboard/index": "dashboardIndex",
      "users/password/index": "GantiPassword",



      // Agenda Meeting Room And Agenda Pimpinan
      "agenda/meeting-room/monthly/index":"MeetingRoomMonthlyIndex",
      "agenda/meeting-room/monthly/index/?*params":"MeetingRoomMonthlyIndex",

      "agenda/meeting-room/weekly/index/:id/:tanggal":"MeetingRoomWeeklyIndex",
      "agenda/meeting-room/weekly/index/:id/:tanggal/?*params":"MeetingRoomWeeklyIndex",

      "agenda/meeting-room/rooms/index":"RoomIndex",
      "agenda/meeting-room/rooms/index/?*params":"RoomIndex",

      "agenda/meeting-room/rooms/add":"RoomAdd",
      "agenda/meeting-room/rooms/edit/:id":"RoomEdit",

      "agenda/meeting-room/weekly/add/:id/:tanggal/:time/:date":"AgendaAdd",
      "agenda/meeting-room/weekly/add/:id/:tanggal/:time/:date/?*params":"AgendaAdd",

      "agenda/meeting-room/weekly/view/:id/:tanggal/:eventid/?*params":"AgendaView",
      "agenda/meeting-room/weekly/view/:id/:tanggal/:eventid":"AgendaView",

      "agenda/meeting-room/weekly/edit/:id/:tanggal/:eventid/?*params":"AgendaEdit",
      "agenda/meeting-room/weekly/edit/:id/:tanggal/:eventid":"AgendaEdit",

      "agenda/meeting-room/invitation/?*params":"InvitationIndex",
      "agenda/meeting-room/invitation":"InvitationIndex",

      "agenda/meeting-room/rooms/approval/?*params":"ApprovalIndex",
      "agenda/meeting-room/rooms/approval":"ApprovalIndex",

      // Print
      "agenda/meeting-room/print/?*params":"AgendaPrint",
      "agenda/meeting-room/print":"AgendaPrint",


      "agenda/profile/index/?*params":"ProfileIndex",
      "agenda/profile/index":"ProfileIndex",

      "agenda/profile/add/?*params":"ProfileAdd",
      "agenda/profile/add":"ProfileAdd",

      "agenda/profile/edit/?*params":"ProfileEdit",
      "agenda/profile/edit/:id":"ProfileEdit",


      // tambah batih
      "agenda/profile/batih/new/:id/?*params":"BatihAdd",
      "agenda/profile/batih/new/:id":"BatihAdd",

      "agenda/profile/batih/edit/:id/?*params":"BatihEdit",
      "agenda/profile/batih/edit/:id":"BatihEdit",

      "agenda/index/?*params":"AgendaPimpinanIndex",
      "agenda/index":"AgendaPimpinanIndex",


      "agenda/weekly/:id/:tanggal?*params":"AgendaPimpinanWeeklyIndex",
      "agenda/weekly/:id/:tanggal":"AgendaPimpinanWeeklyIndex",

      "agenda/weekly/add/:id/:tanggal/:time/:date":"AgendaPimpinanAdd",
      "agenda/weekly/add/:id/:tanggal/:time/:date/?*params":"AgendaPimpinanAdd",

      "agenda/weekly/view/:id/:tanggal/:eventid/?*params":"AgendaPimpinanView",
      "agenda/weekly/view/:id/:tanggal/:eventid":"AgendaPimpinanView",

      "agenda/weekly/edit/:id/:tanggal/:eventid/?*params":"AgendaPimpinanEdit",
      "agenda/weekly/edit/:id/:tanggal/:eventid":"AgendaPimpinanEdit",

      // Agenda Pimpinan Print
      "agenda/print/?*params":"AgendaPimpinanPrint",
      "agenda/print":"AgendaPimpinanPrint",


      "agenda/approval/?*params":"AgendaPimpinanApprovalIndex",
      "agenda/approval":"AgendaPimpinanApprovalIndex",

      "agenda/pimpinan/manage/?*params":"AgendaPimpinanManageIndex",
      "agenda/pimpinan/manage":"AgendaPimpinanManageIndex",

      // Manage Agenda Permintaan
      "agenda/meeting-room/manage/?*params":"AgendaMeetingRoomManageIndex",
      "agenda/meeting-room/manage":"AgendaMeetingRoomManageIndex",



      // Laporan
      "laporan/index":"laporanIndex",
      "laporan/index?*params":"laporanIndex",

      "laporan/index/edit/:id":"laporanEdit",
      "laporan/index/new" : "laporanAdd",
      "laporan/index/open/:sharedid/:id":"laporanOpen",
      "laporan/index/open/:sharedid/:id/?*params":"laporanOpen",
      "laporan/category/add": "categoryLaporanAdd",
      "laporan/category/edit/:id": "categoryLaporanEdit",

      "laporan/index/sub/:id/:name":"laporanSubIndex",
      "laporan/index/sub/:id/:name*?params":"laporanSubIndex",
      "laporan/index/sub/new/:id/:name":"laporanSubAdd",
      "laporan/oncomment/index":"commentLaporanIndex",

      "laporan/inbox/index*?params":"inboxLaporanIndex",
      "laporan/inbox/index":"inboxLaporanIndex",


      // Naskah Dinas
      "naskah/index":"naskahIndex",
      "naskah/index?*params":"naskahIndex",

      "naskah/index/edit/:id":"naskahEdit",
      "naskah/index/new" : "naskahAdd",
      "naskah/index/open/:sharedid/:id":"naskahOpen",
      "naskah/index/open/:sharedid/:id/?*params":"naskahOpen",
      "naskah/category/add": "categoryNaskahAdd",
      "naskah/category/edit/:id": "categoryNaskahEdit",

      "naskah/index/draft/:sharedid/:id":"naskahDraft",
      "naskah/index/draft/:sharedid/:id/?*params":"naskahDraft",

      "naskah/index/sub/:id/:name":"naskahSubIndex",
      "naskah/index/sub/:id/:name*?params":"naskahSubIndex",
      "naskah/index/sub/new/:id/:name":"naskahSubAdd",
      "naskah/oncomment/index":"commentNaskahIndex",

      "naskah/inbox/index*?params":"inboxNaskahIndex",
      "naskah/inbox/index":"inboxNaskahIndex",

      "naskah/master-template/index":"templateIndex",
      "naskah/master-template/index/?*params":"templateIndex",
      "naskah/master-template/new":"templateAdd",
      "naskah/master-template/new/?*params":"templateAdd",
      "naskah/master-template/edit/:sharedid/:id":"templateEdit",

      // Master Rekening
      "naskah/master/rekening":"masterRekeningIndex",
      "naskah/master/rekening/?*params":"masterRekeningIndex",
      "naskah/master/rekening/new":"masterRekeningAdd",
      "naskah/master/rekening/new/?*params":"masterRekeningAdd",
      "naskah/master/rekening/edit/:id":"masterRekeningEdit",
      "naskah/master/rekening/edit/:id/?*params":"masterRekeningEdit",

      // SPPD
      "naskah/dinas/inbox/?*params":"InboxDinas",
      "naskah/dinas/inbox":"InboxDinas",
      "naskah/dinas/manage/index/?*params":"ManageDinas",
      "naskah/dinas/manage/index":"ManageDinas",


      "naskah/dinas/sppd/new/:sharedid/:id":"AddSPPD",
      "naskah/dinas/sppd/new/:sharedid/:id/?*params":"AddSPPD",

      "naskah/dinas/spt/new":"AddSPT",
      "naskah/dinas/spt/new/?*params":"AddSPT",


      "naskah/dinas/details/:sharedid/:id":"DetailsDinas",
      "naskah/dinas/details/:sharedid/:id/?*params":"DetailsDinas",

      "naskah/dinas/sppd/details/:sharedid/:id":"DetailsSppdDinas",
      "naskah/dinas/sppd/details/:sharedid/:id/?*params":"DetailsSppdDinas",


      // Arsip
      "arsip/files/index": "filesIndex",
      "arsip/files/add": "filesAdd",
      "arsip/files/edit/:id": "filesEdit",
      "arsip/files/more/:id": "filesMore",
      "arsip/files/more/add/:id": "filesMoreAdd",
      "arsip/files/upload": "filesUpload",
      "arsip/files/more/upload/:id": "filesMoreUpload",
      "arsip/shared/index": "filesShared",
      "arsip/files/shared/:id": "filesSharing",
      "arsip/files/download/:id": "downloadFiles",

      "arsip/recent/index": "recentIndex",
      "arsip/recycle/index": "recycleIndex"

    },
    initialize: function() {
      require(
        [
          "app/views/systems/MenuLeft",
          "jquery",
          "jquery.confirm",
          "hbtemplate",
          "bootstrap.min"
        ],
        function(views, $) {
            // $.noConflict();

            /*** Handle jQuery plugin naming conflict between jQuery UI and Bootstrap ***/
            $.widget.bridge('uibutton', $.ui.button);
            $.widget.bridge('uitooltip', $.ui.tooltip);
            
            console.log(moment.locale("id"));

            $("#navigasi").addClass("nav navbar-nav");
            $("#navigasi").html("<ul class='nav navbar-nav'></ul>");

            $("#del_users").hide();
            $("#reset_users").hide();

            // message
            $('#alert-success').hide();
            $('#alert-warning').hide();
            $('#alert-error').hide();

            // NProgress.start();
            //load menu
            $('.main-sidebar').html(new views.MenuLeft().render().el);



        });
    },

  });

});
