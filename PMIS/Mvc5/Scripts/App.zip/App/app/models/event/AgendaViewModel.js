define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        AgendaViewModel = Backbone.Model.extend({
            urlRoot:"Schedules/Details/",
            defaults: {
                status:null
            }

        }),

        AgendaViewModelColl = Backbone.Collection.extend({
            model: AgendaViewModel,
            url:"Schedules/Details/"
        });

    return {
        AgendaViewModel : AgendaViewModel,
        AgendaViewModelColl: AgendaViewModelColl
    };

});