define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        ListAccount = Backbone.Model.extend({
            urlRoot:"Profiles/ListAccount",
            defaults: {
                status:null
            }

        }),

        ListAccountColl = Backbone.Collection.extend({
            model: ListAccount,
        });

    return {
        ListAccount: ListAccount,
        ListAccountColl: ListAccountColl
    };

});