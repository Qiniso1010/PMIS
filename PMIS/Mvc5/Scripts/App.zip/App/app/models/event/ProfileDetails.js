define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        ProfileDetails = Backbone.Model.extend({
            urlRoot:"Profiles/Details/",
            defaults: {
                status:null
            }

        }),

        ProfileDetailsColl = Backbone.Collection.extend({
            model: ProfileDetails,
            url:"Profiles/Details/"
        });

    return {
        ProfileDetails: ProfileDetails,
        ProfileDetailsColl: ProfileDetailsColl
    };

});