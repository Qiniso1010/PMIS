define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        UsersList = Backbone.Model.extend({
            urlRoot:"Units/GetSuratToUnit/",
            defaults: {
                status:null
            }

        }),

        UsersListColl = Backbone.Collection.extend({
            model: UsersList,
            url:"Units/GetSuratToUnit/"
        });

    return {
        UsersList : UsersList,
        UsersListColl: UsersListColl
    };

});