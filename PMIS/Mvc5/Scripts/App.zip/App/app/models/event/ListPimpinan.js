define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        ListPimpinan = Backbone.Model.extend({
            urlRoot:"Profiles/Lists",
            defaults: {
                status:null
            }

        }),

        ListPimpinanColl = Backbone.Collection.extend({
            model: ListPimpinan,
            url:"Profiles/Lists"
        });

    return {
        ListPimpinan: ListPimpinan,
        ListPimpinanColl: ListPimpinanColl
    };

});