define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        FileDetailsModel = Backbone.Model.extend({

            urlRoot:"Files/Details/",
            initialize:function () {
                this.dat = new FileDetailsModelColl();
                this.dat.url = this.urlRoot + "/" + this.id;
            },
            defaults: {
                ModuleId: null,
                Name:null
            }

        }),

       FileDetailsModelColl = Backbone.Collection.extend({

            model: FileDetailsModel,

        });

    return {
        FileDetailsModel: FileDetailsModel,
        FileDetailsModelColl: FileDetailsModelColl
    };

});