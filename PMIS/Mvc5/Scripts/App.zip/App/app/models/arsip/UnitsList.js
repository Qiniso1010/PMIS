define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        UnitsList = Backbone.Model.extend({
            urlRoot:"Units/GetSuratToUnit/",
            defaults: {
                status:null
            }

        }),

        UnitsListCollection = Backbone.Collection.extend({
            model: UnitsList,
            url:"Units/GetSuratToUnit/"
        });

    return {
        UnitsList : UnitsList,
        UnitsListCollection: UnitsListCollection
    };

});