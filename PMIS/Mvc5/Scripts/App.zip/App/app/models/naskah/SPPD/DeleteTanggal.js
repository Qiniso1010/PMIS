define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        DeleteTanggal = Backbone.Model.extend({
            urlRoot:"Dinas/DeleteTanggal/"

        }),

        DeleteTanggalColl = Backbone.Collection.extend({
            model: DeleteTanggal
        });

    return {
        DeleteTanggal: DeleteTanggal,
        DeleteTanggalColl: DeleteTanggalColl
    };

});