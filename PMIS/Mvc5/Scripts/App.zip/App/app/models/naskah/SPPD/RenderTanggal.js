define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        RenderTanggal = Backbone.Model.extend({
            urlRoot:"Dinas/RenderTanggal/",
            defaults: {
                status:null
            }

        }),

        RenderTanggalColl = Backbone.Collection.extend({
            model: RenderTanggal
        });

    return {
        RenderTanggal: RenderTanggal,
        RenderTanggalColl: RenderTanggalColl
    };

});