define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        DinasDetailsModel = Backbone.Model.extend({
            urlRoot:"Dinas/Details/"

        }),

        DinasDetailsModelColl = Backbone.Collection.extend({
            model: DinasDetailsModel
        });

    return {
        DinasDetailsModel: DinasDetailsModel,
        DinasDetailsModelColl: DinasDetailsModelColl
    };

});