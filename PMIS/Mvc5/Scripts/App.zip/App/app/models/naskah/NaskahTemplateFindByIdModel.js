define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        NaskahTemplateFindByIdModel = Backbone.Model.extend({
            urlRoot:"TemplateDocs/FindById/",
            defaults: {
                status:null
            }

        }),

        NaskahTemplateFindByIdModelColl = Backbone.Collection.extend({
            model: NaskahTemplateFindByIdModel,
            url:"TemplateDocs/FindById/"
        });

    return {
        NaskahTemplateFindByIdModel: NaskahTemplateFindByIdModel,
        NaskahTemplateFindByIdModelColl: NaskahTemplateFindByIdModelColl
    };

});