define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        NaskahForPrint = Backbone.Model.extend({
            urlRoot:"LaporanDocs/RenderForPrint/",
            defaults: {
                status:null
            }

        }),

        NaskahForPrintColl = Backbone.Collection.extend({
            model: NaskahForPrint,
            url:"LaporanDocs/RenderForPrint/"
        });

    return {
        NaskahForPrint: NaskahForPrint,
        NaskahForPrintColl: NaskahForPrintColl
    };

});