define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        NaskahDraft = Backbone.Model.extend({
            urlRoot:"LaporanDocs/Details/",
            defaults: {
                status:null
            }

        }),

        NaskahDraftColl = Backbone.Collection.extend({
            model: NaskahDraft,
            url:"LaporanDocs/Details/"
        });

    return {
        NaskahDraft: NaskahDraft,
        NaskahDraftColl: NaskahDraftColl
    };

});