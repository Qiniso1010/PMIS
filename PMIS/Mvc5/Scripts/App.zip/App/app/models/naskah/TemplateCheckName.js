define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        TemplateCheckName = Backbone.Model.extend({
            urlRoot:"TemplateDocs/CheckName/",
            defaults: {
                status:null
            }

        }),

        TemplateCheckNameColl = Backbone.Collection.extend({
            model: TemplateCheckName,
            url:"TemplateDocs/CheckName/"
        });

    return {
        TemplateCheckName: TemplateCheckName,
        TemplateCheckNameColl: TemplateCheckNameColl
    };

});