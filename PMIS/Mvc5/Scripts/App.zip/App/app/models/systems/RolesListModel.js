define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        RolesListModel = Backbone.Model.extend({

            urlRoot: "Roles/ComboListing/",
            defaults: {
                term:""
            }

        }),

        RolesListCollection = Backbone.Collection.extend({

            model: RolesListModel,
            url: "Roles/ComboListing/"

        });

    return {
        RolesListModel: RolesListModel,
        RolesListCollection: RolesListCollection
    };

});