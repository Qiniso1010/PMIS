define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        ChangePasswordModel = Backbone.Model.extend({

            urlRoot:"users/GetToken/password-change",
            defaults: {
                token:"",
                userId: null
            }

            // initialize: function () {
            //     this.reports = new SiteMasterCollection();
            //     this.reports.url = this.urlRoot + "/" + this.id + "/reports";
            // }

        }),

        ChangePasswordCollection = Backbone.Collection.extend({

            model: ChangePasswordModel,
            url:"users/GetToken/password-change"

        });

    return {
        ChangePasswordModel: ChangePasswordModel,
        ChangePasswordCollection: ChangePasswordCollection
    };

});