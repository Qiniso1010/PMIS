define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        CommentModel = Backbone.Model.extend({
            urlRoot:"Comments/",
            defaults: {
                status:null
            }

        }),

        CommentModelCol = Backbone.Collection.extend({
            model: CommentModel,
            url:"Comments/"
        });

    return {
        CommentModel: CommentModel,
        CommentModelCol: CommentModelCol
    };

});