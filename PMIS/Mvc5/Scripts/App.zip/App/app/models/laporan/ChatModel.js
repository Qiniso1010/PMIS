define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        ChatModel = Backbone.Model.extend({
            urlRoot:"Comments/",
            defaults: {
                status:null
            }

        }),

        ChatModelColl = Backbone.Collection.extend({
            model: ChatModel,
            url:"Comments/"
        });

    return {
        ChatModel: ChatModel,
        ChatModelColl: ChatModelColl
    };

});