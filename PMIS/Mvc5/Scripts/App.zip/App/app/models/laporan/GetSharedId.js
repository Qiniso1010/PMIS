define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetSharedId = Backbone.Model.extend({
            urlRoot:"LaporanDocs/GetSharedId/",
            defaults: {
                status:null
            }

        }),

        GetSharedIdCol = Backbone.Collection.extend({
            model: GetSharedId,
            url:"LaporanDocs/GetSharedId/"
        });

    return {
        GetSharedId: GetSharedId,
        GetSharedIdCol: GetSharedIdCol
    };

});