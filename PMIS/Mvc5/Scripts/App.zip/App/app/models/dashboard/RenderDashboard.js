define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        RenderDashboard = Backbone.Model.extend({
            urlRoot:"Notif/RenderDashboard/",
            defaults: {
                status:null
            }

        }),

        RenderDashboardColl = Backbone.Collection.extend({
            model: RenderDashboard
        });

    return {
        RenderDashboard: RenderDashboard,
        RenderDashboardColl: RenderDashboardColl
    };

});