define(function (require) {

    "use strict";

    var $                   = require('jquery'),
        Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        ModalView           = require('backbone-modal'),
        filex               = require('app/models/laporan/GetFiles'),
        select2             = require('select2/select2'),
        models              = require('app/models/laporan/UnitsList'),
        summernote          = require('summernote/summernote'),
        view                = require('app/views/laporan/LaporanDetails'),
        
        ModalDisposisi = Backbone.ModalView.extend({
            title: "<h3>Pilih User / Unit</h3>",
            buttons: [{
                className: "btn-success btn-custom btn-flat ok",
                label: "Send"
            }],
            events: {
                "click .modal-footer a.ok": "onAction",
                "hidden.bs.modal": "onHidden",
                "click #btnMove": "onMove"
            },
            postRender: function() {
                this.onRender();
                return this;
            },
            onRender: function() {
                var templatex = hb.Tem('Laporan/_partial/UnitListingDetails');
                this.$body.html(templatex());
                this.$('#Unit').select2();
                
                this.$("#keterangan").summernote({
                    height: 200
                });
                
                var token = $('input[name="__RequestVerificationToken"]').val();
                var list = new models.UnitsList();

                list.fetch({
                    data: $.param({ __RequestVerificationToken: token }),
                    type: 'GET',
                    dataType: 'json',
                    cache:true,
                    success: function (data) {
                        $('#Unit').html(templatex(data.attributes));
                    }
                });
                
                return this;
            },
            onAction: function() {
                var $unit = $("#Unit").val();
                var $SharedId = $("#SharedId").val();
                var $Id = $("#id").val();
                var $Pesan = $("#keterangan").code();
                
                Utility.IsLoading("#loading","show");
                Utility.prosesLoad("Y");
                
                if ($unit != null) {
                     var token = $('input[name="__RequestVerificationToken"]').val();
                 
                    var param = {
                        LaporanDocId:$Id,
                        SharedId:$SharedId,
                        __RequestVerificationToken:token,
                        UserId:$unit.toString(),
                        Keterangan:$Pesan
                    };
                    
                    var $options = {};
                    $options.url = "LaporanDocs/SendDisposisi/";
                    $options.type = "POST";
                    $options.cache = false;
                    $options.data = param;
                    $options.dataType = "json";
                    $options.success = function(d) {
                        if (d.Attr == "Ok!") {
                            Utility.IsLoading("#loading","hide");
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check",d.Message,"success");
                            
                            var $v = new view.LaporanDetails();
                            $v.render();
                        } else {
                            Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        }
                    };
                    $options.error = function(err) {
                        alert(err.responseText);  
                        Utility.IsLoading("#loading","hide");
                    };
                    $.ajax($options);
                    
                } else {
                    swal("Still is empty!");
                    Utility.IsLoading("#loading","hide");
                }
                
                return this;
            },
            onHidden: function(e) {
                console.log("Modal hidden");
            },
            // onOk: function(e) {
            //     e.preventDefault();
            //     console.log("Ok clicked");
            // },
            // onCancel: function(e) {
            //     console.log("Cancel clicked");
            // },
        });

    return {
        ModalDisposisi: ModalDisposisi
    };
  

});


