define(function (require) {

    "use strict";

    var //Handlebars          = require('handlebars'),
        // _                   = require('underscore'),
        // Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        // HandlerHelper       = require('handlebarshelper'),
        summernote          = require('summernote/summernote'),
        typeahead           = require('typeahead.bundle.min'),
        tokenfield          = require('bootstrap-tokenfield'),
        select2             = require('select2/select2'),
        model               = require('app/models/naskah/GetSharedId'),
        check               = require('app/models/naskah/NaskahGetNomer'),
        filex               = require('app/models/naskah/GetFiles'),
        DelFile             = require('app/models/naskah/DeleteFile'),
        models              = require('app/models/naskah/UnitsList'),
        bootstrapTable      = require('bootstrap-table/dist/bootstrap-table.min'),
        mod                 = require('app/modules/naskah/getFilesArsip'),
        viewmod             = require('app/views/naskah/ModalRender'),
        datepicker          = require('/Scripts/bootstrap-datepicker.js'),
        modalTemplate       = require('app/views/naskah/ModalRenderTemplate'),
        ModalRoom           = require('app/views/naskah/ModalRenderRooms'),
        NProgress           = require('/Scripts/nprogress.js'),
        
        

    NaskahSubAdd = Backbone.View.extend({
        template : hb.Tem('naskah/NaskahAddView'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
            "focusout #nomer":"CheckName",
            "change #file":"Upload",
            "click #btnRemoveFile":"RemoveFile",
            "click #btnArsilFile":"ArsipFile",
            "click #btnArsip":"OpenedArsip",
            "click #btnDisposisi":"OpenModalDisposisi",
            "click #btnSaveDraft":"SaveAsDraft",
            "click #btnOpenTemplate":"ModalTemplateOpen"
        },
        render: function (id) {
            this.$el.html(this.template());
            
            NProgress.done();
            this.$("#btnSave").attr("disabled",false);
            
            this.$('#CategoryId').val(id);
            
            this.$('#UserId').select2();
            
            this.$('#tanggal').datepicker({
                format:'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true
            });

            // keterangan extended
            this.$("#keterangan").summernote({
                height: 500
            });
            
            // render email if exist
            this.RenderEmail();
            
            // render unit
            this.RenderUnit();
            
            // get shared id
            this.SharedId();
            
            return this;
        },
        RenderEmail:function() {
            // Render Email
            
            this.$("#email").tokenfield({
                autocomplete: {
                    source: function (request, response) {
                        $.getJSON("Sharing/EmailList/?term=" + request.term, function (data) {
                            response($.map(data, function (value, key) {
                                return {
                                    label: value.Email,
                                    value: key.Email
                                };
                            }));
                        });
                    },
                    delay: 100
                },
                showAutocompleteOnFocus: true
            });  
            
            return this;
        },
        ModalRoomx: function (tanggal,sharedid) {
          if(this.BeforeSend()) {
              new ModalRoom.ModalRenderRooms().render(tanggal,sharedid);
          }  
        },
        ModalTemplateOpen: function() {
            if(this.BeforeSend()) {
                new modalTemplate.ModalRenderTemplate().render();
            }
        },
        OpenedArsip:function() {
            if(this.BeforeSend()) {
                new viewmod.Mx().render();
            }
            return this;
        },
        ArsipFIle: function(e) {
            e.preventDefault();
            var id = $(e.currentTarget).data("id");
            
            alert(id);
        },
        RemoveFile: function(e) {
            e.preventDefault();
            NProgress.start();
            
            $('#progress-bar').hide();
            Utility.IsLoading("#loading","show");
            var m = new DelFile.DeleteFile();
            
            var id = $(e.currentTarget).data("id");
            
            m.save({id:id}, {
                type: 'POST',
                dataType: 'json',
                cache:false,
                success : function(d) {
                    NProgress.done();
                    if (d.get("Attr") == "Ok!") {
                        Utility.AlertV2("check", d.get("Message"), "success");
                        
                        var $s = new NaskahSubAdd();
                        // render file
                        $s.RenderFiles($("#SharedId").val());
                        Utility.IsLoading("#loading","hide");
                    } else {
                        Utility.AlertV2("exclamation-triangle", d.get("Message"), "error");
                        
                        Utility.IsLoading("#loading","hide");
                    }
                },
                error: function(err) {
                    alert(err.responseText);
                    
                    Utility.IsLoading("#loading","hide");
                }
            });
            
            return this;
        },
        SharedId:function () {
            NProgress.start();
            var list = new model.GetSharedId();

            list.fetch({
                data: $.param({ Id: 'GET' }),
                type: 'GET',
                cache:false,
                success: function (data) {
                    NProgress.done();
                    $('#SharedId').val(data.get("result"));
                    var $s = new NaskahSubAdd()
                    $s.RenderFiles(data.get("result"));
                }
            });
            
            return this;
        },
        RenderUnit: function () {
            var templatex = hb.Tem('Naskah/_partial/DisposisiUnitListing');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var list = new models.UnitsList();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token }),
                type: 'GET',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#UserId').html(templatex(data.attributes));
                }
            });
            return this;
        },
        RenderFiles: function(id) {
            var templatex = hb.Tem('Naskah/_partial/RenderFiles');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var list = new filex.GetFiles();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token,SharedId:id }),
                type: 'POST',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#file-list').html(templatex(data.attributes));
                }
            });
            return this;
        },
        Upload: function () {
            this.name = this.$("#nomer").val();
            
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            
            if (this.name == "") {
                $("#nomer-id").removeClass("has-success");
                $("#nomer-id").addClass("has-error");
                
                swal("Number is empty!");
                
                $("#nomer").focus();
                Utility.IsLoading("#loading","hide");
                false;
            } else {
                var percent = $('#progress-bar');

                var fileUpload = $('#FormUpload').get(0);

                if (fileUpload.files != '') {

                    var form = $('#FormUpload')[0];
                    var form_data = new FormData(form);
                    $.ajax({
                        xhr: function () {
                            var xhr = new window.XMLHttpRequest();
                            //Upload progress
                            xhr.upload.addEventListener("progress", function (evt) {
                                if (evt.lengthComputable) {
                                    var percentComplete = evt.loaded / evt.total * 100;
                                    percent.html(Math.round(percentComplete) + '%');
                                }
                            }, false);
                            //Download progress
                            xhr.addEventListener("progress", function (evt) {
                                if (evt.lengthComputable) {
                                    var percentComplete = evt.loaded / evt.total * 100;
                                    percent.html(Math.round(percentComplete) + '%');
                                }
                            }, false);
                            return xhr;
                        },
                        url: 'UploadLaporan/UploadFile/',
                        dataType: 'json',
                        cache: false,
                        contentType: false,
                        processData: false,
                        data: form_data,
                        type: 'post',
                        success: function (data) {

                            if (data.Attr == "Ok!") {
                                var percentValue = '100%';
                                percent.html(percentValue);
                                $("#file-list").append("<li><a href='/Uploads/"+data.Name+"' target='_blank'>" + data.Name + "</a></li>");
                                
                                Utility.IsLoading("#loading", "hide");
                                Utility.prosesLoad("N");
                                Utility.AlertV2("check", data.Message, "success");
                                
                                var $s = new NaskahSubAdd()
                                // render file
                                $s.RenderFiles($("#SharedId").val());
                            } else {
                                Utility.AlertV2("exclamation-triangle", data.Message, "error");
                            }

                        },
                        error: function (xhr, ajaxOptions, thrownError) {
                            console.log(xhr.responseText);
                            alert(xhr.responseText);

                            Utility.IsLoading("#loading", "hide");
                            Utility.prosesLoad("N");
                        }
                    });
                }
            }
            

           
            
            return this;
        },
        CheckName: function(e) {
            this.name = this.$("#nomer").val();

            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var CurrentName = new check.NaskahGetNomer({ name: this.name, __RequestVerificationToken: token });
            var self = this;
            
            
            if (this.name == "") {
                $("#nomer-id").removeClass("has-success");
                $("#nomer-id").addClass("has-error");
                Utility.AlertV2("check","Nomer is empty!","error");
                $("#nomer").focus();
                $("#btnSave").attr("disabled", false);
            } else {
                $("#btnSave").attr("disabled",false);
                CurrentName.fetch({
                    data: $.param({name:this.name,__RequestVerificationToken:token}),
                    type:'POST',
                    success: function(data) {
                        NProgress.done();
                        if (data.get("Attr") == "Ok!") {
                            $('#nomer').val(data.get("Message"));
                        }  
                    }
                
                }); 
            }
            
            return this;       
        },  
        BeforeSend:function() {
            var user = $("#UserId").val();
            var param = {
                Nomor:$("#nomer").val(),
                Perihal:$("#perihal").val(),
                UserId:user,
                Tanggal:$('#tanggal').val(),
                Email:$('#email').val()
             
            
            };
            
            if (param.Nomor == "") {
                $("#nomer-id").removeClass("has-success");
                $("#nomer-id").addClass("has-error");
                $("#nomer").focus();

                Utility.IsLoading("#loading","hide");
                return false;
            } else if(param.Perihal == "") {
                $("#perihal-id").removeClass("has-success");
                $("#perihal-id").addClass("has-error");
                $("#perihal").focus();

                Utility.IsLoading("#loading","hide");
                return false;
            } else if (param.Tanggal == "") {
                $("#tanggal-id").removeClass("has-success");
                $("#tanggal-id").addClass("has-error");
                $("#tanggal").focus();

                Utility.IsLoading("#loading","hide");
                return false;
            }
            
            return true;
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            var $options = {};
            var token = $('input[name="__RequestVerificationToken"]').val();
            var user = $("#UserId");
            var cat = $("#CategoryId");
            var email = $("#email");
            
            // Check Form Valid Or Not
            if(this.BeforeSend()) {
                if (user.val() == ""  &&  email.val() == "") {
                    $("#user-id").removeClass("has-success");
                    $("#user-id").addClass("has-error");
                    $("#UserId").focus();
                    
                    swal("Disposisi masih kosong! " + user.val() );
                    Utility.IsLoading("#loading","hide");
                    
                    return false;
                } else {
                    
                    if (user.val() == "" || user.val() == null) {
                        var userx = '';
                    } else {
                        var n = user.val();
                        var userx = n.toString();
                    }
                    var param = {
                        Nomor:$("#nomer").val(),
                        Perihal:$("#perihal").val(),
                        UserId:userx,
                        Keterangan:$("#keterangan").code(),
                        __RequestVerificationToken: token,
                        CategoryId:cat.val(),
                        SharedId:$("#SharedId").val(),
                        Tanggal:$('#tanggal').val(),
                        IsDraft:false,
                        ImageHeaderPath:$('#ImageHeaderPath').val(),
                        Email:email.val()
                    
                    };
                    $("#btnSave").attr("disabled",false);
                    
                    $options.url = "LaporanDocs/Create/";
                    $options.type = "POST";
                    $options.cache = false;
                    $options.data = param;
                    $options.dataType = "json";
                    $options.success = function(d) {
                        if (d.Attr == "Ok!") {
                            Utility.IsLoading("#loading","hide");
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check",d.Message,"success");
                            
                            swal({   
                                title: "Anda ingin melanjutkan pemesanan tempat Meeting Room?",   
                                text: "Jika Iya maka halaman ini akan otomatis mengarahkan anda.",   
                                type: "info",      
                                showCancelButton: true,   
                                confirmButtonColor: "#DD6B55",   
                                confirmButtonText: "Yes!",   
                                cancelButtonText: "No!",   
                                closeOnConfirm: true,   
                                closeOnCancel: true
                            }, 
                            function(isConfirm) {   
                                if (isConfirm) {     
                                    var $view = new NaskahSubAdd();
                                    $view.ModalRoomx(param.Tanggal,param.SharedId); 
                                    
                                    $view.CheckName(); 
                                } else {     
                                    
                                    var $view = new NaskahSubAdd();
                                    $view.SharedId();
                                    $view.CheckName();  
                                } 
                            });
                        } else {
                            Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        }
                        $("#nomer").focus();
                    };
                    $options.error = function(err) {
                        alert(err.responseText);  
                        Utility.prosesLoad("N");
                        Utility.IsLoading("#loading","hide");
                    };
                    $.ajax($options);
                }
                    
                    
                
            } else {
                swal("Oops...", "Kolom Masih ada yang kosong!", "error");
            }
            
            return this;

        },
        SaveAsDraft : function (event) {
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            var $options = {};
            var token = $('input[name="__RequestVerificationToken"]').val();
            var cat = $("#CategoryId");
            
            // Check Form Valid Or Not
            if(this.BeforeSend()) {
                var param = {
                    Nomor:$("#nomer").val(),
                    Perihal:$("#perihal").val(),
                    UserId:'',
                    Keterangan:$("#keterangan").code(),
                    __RequestVerificationToken: token,
                    CategoryId:cat.val(),
                    SharedId:$("#SharedId").val(),
                    Tanggal:$('#tanggal').val(),
                    IsDraft:true,
                    ImageHeaderPath:$('#ImageHeaderPath').val(),
                    Email:''
                
                };
                $("#btnSaveDraft").attr("disabled",false);
                $("#btnSave").attr("disabled",false);
                
                
                $options.url = "LaporanDocs/Create/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    if (d.Attr == "Ok!") {
                        Utility.IsLoading("#loading","hide");
                        Utility.prosesLoad("N");
                        Utility.AlertV2("check",d.Message,"success");
                        
                        swal({   
                            title: "Anda ingin melanjutkan pemesanan tempat Meeting Room?",   
                            text: "Jika Iya maka halaman ini akan otomatis mengarahkan anda.",   
                            type: "info",      
                            showCancelButton: true,   
                            confirmButtonColor: "#DD6B55",   
                            confirmButtonText: "Yes!",   
                            cancelButtonText: "No!",   
                            closeOnConfirm: true,   
                            closeOnCancel: true
                        }, 
                        function(isConfirm) {   
                            if (isConfirm) {     
                                var $view = new NaskahSubAdd();
                                $view.ModalRoomx(param.Tanggal,param.SharedId); 
                                
                                $view.CheckName(); 
                            } else {     
                                
                                var $view = new NaskahSubAdd();
                                $view.SharedId();
                                $view.CheckName();  
                            } 
                        });
                       
                        
                    } else {
                        Utility.AlertV2("exclamation-triangle",d.Message,"error");
                    }
                    $("#nomer").focus();
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
                    
            } else {
                swal("Oops...", "Kolom Masih ada yang kosong!", "error");
            }
            
            return this;

        }
      
    });

    return {
        NaskahSubAdd: NaskahSubAdd
    };
});


