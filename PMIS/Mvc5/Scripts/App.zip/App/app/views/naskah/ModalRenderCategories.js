define(function (require) {

    "use strict";

    var //Handlebars          = require('handlebars'),
        // _                   = require('underscore'),
        // Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        // HandlerHelper       = require('handlebarshelper'),
        ModalView           = require('backbone-modal'),
        filex               = require('app/models/naskah/GetFiles'),
        
        ModalCategories = Backbone.ModalView.extend({
            title: "<h3>Pilih Salah Satu Kategori </h3>",
            events: {
                // "click .modal-footer a.ok": "onOk",
                // "click .modal-footer a.cancel": "onCancel",
                "hidden.bs.modal": "onHidden",
                "click #btnMove": "onMove"
                
            },
            postRender: function() {
                this.onTable();
                this.onRender();
                return this;
            },
            onRender:function() {
                // get jumlah file yang diselect
                var $jml = store.get("HitungLaporan");
                this.$("#JumlahData").html($jml);
            },
            onMove:function(e) {
                e.preventDefault();
                var id = $(e.currentTarget).data("id");
                
                var param = Array();
                param = store.get("LaporanId");

                var i;
                if (param.length > 0) {
                    for (i = 0; i < param.length; i++) {
                       this.onAction(id,param[i].Id);
                    }
                } 
            },
            onAction: function(cat_id,id) {
                var token = $('input[name="__RequestVerificationToken"]').val();
                 
                var param = {
                  LaporanDocId:id,
                  CategoryId:cat_id,
                  __RequestVerificationToken:token
                };
                
                var $options = {};
                $options.url = "Categories/MoveLaporanToCategory/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    
                    Utility.IsLoading("#loading","hide");
                    if (d.Attr == "Ok!") {
                        Utility.prosesLoad("N");
                        Utility.AlertV2("check",d.Message,"success");
                        
                        store.remove("LaporanId");
                    } else {
                        Utility.AlertV2("exclamation-triangle",d.Message,"error");
                    }
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
                
                return this;
            },
            onTable:function() {
                var templatex = hb.Tem('Naskah/_partial/RenderCategory');
                this.$body.html(templatex());
                
                this.$('#btnBackIn').hide();
                
                this.$('#listing-category').bootstrapTable({
                    method: 'GET',
                    url: 'Categories/GetCategories/',
                    cache: false,
                    striped: false,
                    pagination: true,
                    sidePagination: "server",
                    pageSize: 20,
                    pageList: [10, 25, 50, 100, 200],
                    search: true,
                    showColumns: false,
                    showRefresh: true,
                    cardView: false,
                    showToggle: false,
                    showExport: false,
                    exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                    minimumCountColumns: 2,
                    clickToSelect: false,
                    columns: [
                    {
                        field: 'Id',
                        title: 'Item ID',
                        align: 'right',
                        valign: 'bottom',
                        sortable: true,
                        visible: false
                    }, {
                        field: 'NameAndId',
                        title: 'Name',
                        align: 'left',
                        valign: 'middle',
                        sortable: true,
                        formatter: 'Name'
                    },
                    {
                        field: 'NameAndId',
                        title: '',
                        align: 'left',
                        valign: 'middle',
                        sortable: true,
                        formatter: 'Shared'
                    }, 
                    {
                        field: 'TypeData',
                        visible: false
                    }]
                });
            },
            onHidden: function(e) {
                console.log("Modal hidden");
            },
        });

    return {
        ModalCategories: ModalCategories
    };
  

});


