define(function (require) {

    "use strict";

    var //Handlebars          = require('handlebars'),
        // _                   = require('underscore'),
        // Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        // HandlerHelper       = require('handlebarshelper'),
        ModalxView          = require('backbone-modalx'),
        filex               = require('app/models/naskah/GetFiles'),
        select2             = require('select2/select2'),
        summernote          = require('summernote/summernote'),
        models              = require('app/models/naskah/NaskahForPrint'),
        print               = require('/Scripts/jquery.print.js'),
        
        ModalPrintView = Backbone.ModalxView.extend({
            title: "<span class='icon ion-ios-printer-outline size-32'> Cetak Dokumen</span>",
            buttons: [{
                className: "btn-success btn-custom btn-flat ok",
                label: "Cetak!"
            }],
            events: {
                "click .modal-footer a.ok": "onAction",
                "hidden.bs.modal": "onHidden"
            },
            postRender: function() {
                this.onRender(this.id);
                return this;
            },
            onRender: function(id) {
                var templatex = hb.Tem('Naskah/_partial/RenderPrintTemplate');
                this.$body.html(templatex());
                
                var token = $('input[name="__RequestVerificationToken"]').val();
                var list = new models.NaskahForPrint();

                list.fetch({
                    data: $.param({ Id: id,__RequestVerificationToken:token }),
                    type: 'POST',
                    dataType: 'json',
                    cache:false,
                    success: function (data) {
                        $('#template').html(data.get("rows").Keterangan);
                        $('#Id').val(data.get("rows").Id);
                        $('#img-header').attr("src",data.get("rows").ImageHeaderPath);
                    }
                });
                return this;
            },
            onAction: function() {
                $("#print-template").print({
                    globalStyles: true,
                    mediaPrint: false,
                    stylesheet: null,
                    noPrintSelector: ".no-print",
                    iframe: true,
                    append: null,
                    prepend: null,
                    manuallyCopyFormValues: true,
                    deferred: $.Deferred(),
                    timeout: 250
                });
                
                return this;
            },
        });

    return {
        ModalPrintView: ModalPrintView
    };
  

});


