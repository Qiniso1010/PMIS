define(function (require) {

    "use strict";

    var $                   = require('jquery'),
        Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        inputmask           = require('/Scripts/masking/jquery.inputmask.bundle.js'),
        summernote          = require('summernote/summernote'),
        typeahead           = require('typeahead.bundle.min'),
        tokenfield          = require('bootstrap-tokenfield'),
        select2             = require('select2/select2'),
        datepicker          = require('/Scripts/bootstrap-datepicker.js'),
        
        model_getfiles      = require('app/models/naskah/GetFiles'),
        model_deletefiles   = require('app/models/naskah/DeleteFile'),
        
        model_profilelist   = require('app/models/naskah/sppd/GetProfiles'),
        model_checknomor    = require('app/models/naskah/sppd/CheckNomor'),
        model_deletepimpinan= require('app/models/naskah/sppd/DeletePimpinan'),
        model_profile       = require('app/models/naskah/SPPD/GetProfiles'),
        model_inserttanggal = require('app/models/naskah/SPPD/InsertTanggalToDinas'),
        model_rendertanggal = require('app/models/naskah/SPPD/RenderTanggal'),
        model_deletetanggal = require('app/models/naskah/SPPD/DeleteTanggal'),
        model_renderusers   = require('app/models/naskah/SPPD/RenderUsers'),
        
        modal_filesarsip    = require('app/modules/naskah/getFilesArsip'),
        modal_files         = require('app/views/naskah/ModalRender'),
        
        modal_pimpinan      = require('app/views/naskah/SPPD/modal/ModalRenderPemimpin'),
        modal_pegawai       = require('app/views/naskah/SPPD/modal/ModalRenderPegawai'),
        print               = require('/Scripts/jquery.print.js'),
        
        moment              = require('moment'),
        NProgress           = require('/Scripts/nprogress.js'),
        
        
    DinasDetails = Backbone.View.extend({
        template : hb.Tem('naskah/_sppd/DinasDetails'),
        initialize : function() {
            this.render;
        },
        events: {
            "change #file":"Upload",
            "click #btnRemoveFile":"RemoveFile",
            "click #btnArsilFile":"ArsipFile",
            "click #btnArsip":"OpenArsipModal",
            "click #btnPrint":"ShowToPrint",
            
            "click #btnTambahSppd":"TambahSppd",
            "click #btnLihatSppd":"LihatSppd"
        },
        render: function (sharedid,id,params) {
            this.$el.html(this.template(this.model.attributes));
            
            if (params.Type != undefined) {
                this.$('#tipe').val(params.Type);
            }
            
            // this.RenderFiles(sharedid);
            return this;
        },
        TambahSppd:function(e) {
            var id = $(e.currentTarget).data('id');
            var sharedid = $('#SharedId').val();
            var tipe = $('#tipe').val();
            
            var ReturnUrl = ""; //"#/naskah/dinas/details/"+sharedid+"/"+id+"/?Type="+tipe;
            
            window.location.href = "#/naskah/dinas/sppd/new/"+sharedid+"/"+id+"/?Type="+tipe+"&ReturnUrl="+ReturnUrl;
        },
        LihatSppd:function(e) {
            var id = $(e.currentTarget).data('id');
            var sharedid = $('#SharedId').val();
            var tipe = $('#tipe').val();
            
            var ReturnUrl = "";//"#/naskah/dinas/details/"+sharedid+"/"+id+"/?Type="+tipe;
            
            window.location.href = "#/naskah/dinas/sppd/details/"+sharedid+"/"+id+"/?Type="+tipe+"&ReturnUrl="+ReturnUrl;
        },
        ShowToPrint: function(e) {
             $("#Book1_20075").print({
                globalStyles: true,
                mediaPrint: false,
                stylesheet: null,
                noPrintSelector: ".no-print",
                iframe: true,
                append: null,
                prepend: null,
                manuallyCopyFormValues: true,
                deferred: $.Deferred(),
                timeout: 250
            });
            return this;
            // var $id = $(e.currentTarget).data("id");
            
            // new ModalPrint.ModalPrintView({id:$id}).render();
        },
        RenderFiles: function(id) {
            var templatex = hb.Tem('Naskah/_partial/RenderFiles');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var m = new model_getfiles.GetFiles();

            m.fetch({
                data: $.param({ __RequestVerificationToken: token,SharedId:id }),
                type: 'POST',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#file-list').html(templatex(data.attributes));
                }
            });
            return this;
        },
        OpenArsipModal:function() {
            new modal_files.Mx().render();
            return this;
        },
        RemoveFile: function(e) {
            e.preventDefault();
            NProgress.start();
            $('#progress-bar').hide();
            Utility.IsLoading("#loading","show");
            var m = new model_deletefiles.DeleteFile();
            
            var id = $(e.currentTarget).data("id");
            
            m.save({id:id}, {
                type: 'POST',
                dataType: 'json',
                cache:false,
                success : function(d) {
                    NProgress.done();
                    if (d.get("Attr") == "Ok!") {
                        Utility.AlertV2("check", d.get("Message"), "success");
                        
                        var $s = new DinasDetails();
                        $s.RenderFiles($("#SharedId").val());
                        
                        Utility.IsLoading("#loading","hide");
                    } else {
                        Utility.AlertV2("exclamation-triangle", d.get("Message"), "error");
                        
                        Utility.IsLoading("#loading","hide");
                    }
                },
                error: function(err) {
                    alert(err.responseText);
                    
                    Utility.IsLoading("#loading","hide");
                }
            });
            
            return this;
        },
        Upload: function () {
            this.name = this.$("#nomer").val();
            
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            
            var percent = $('#progress-bar');
            var fileUpload = $('#FormUpload').get(0);

            if (fileUpload.files != '') {
                var form = $('#FormUpload')[0];
                var form_data = new FormData(form);
                $.ajax({
                    xhr: function () {
                        var xhr = new window.XMLHttpRequest();
                        //Upload progress
                        xhr.upload.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total * 100;
                                percent.html(Math.round(percentComplete) + '%');
                            }
                        }, false);
                        //Download progress
                        xhr.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total * 100;
                                percent.html(Math.round(percentComplete) + '%');
                            }
                        }, false);
                        return xhr;
                    },
                    url: 'UploadLaporan/UploadFile/',
                    dataType: 'json',
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form_data,
                    type: 'post',
                    success: function (data) {
                        if (data.Attr == "Ok!") {
                            var percentValue = '100%';
                            percent.html(percentValue);
                            // $("#file-list").append("<li><a href='/Uploads/"+data.Name+"' target='_blank'>" + data.Name + "</a></li>");
                            
                            Utility.IsLoading("#loading", "hide");
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check", data.Message, "success");
                            
                            var $s = new DinasDetails();
                            $s.RenderFiles($("#SharedId").val());
                        } else {
                            Utility.AlertV2("exclamation-triangle", data.Message, "error");
                        }

                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        console.log(xhr.responseText);
                        alert(xhr.responseText);

                        Utility.IsLoading("#loading", "hide");
                        Utility.prosesLoad("N");
                    }
                });
            }
            return this;
        },
      
    });

    return {
        DinasDetails: DinasDetails
    };
});

