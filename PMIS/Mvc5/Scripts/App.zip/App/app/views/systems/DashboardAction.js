define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate')
        

    return Backbone.View.extend({
        template : hb.Tem('systems/DashboardActionView'),
        initialize : function() {
            
            this.render;
        },
        render: function () {
            this.$el.html(this.template({dashboard:"Dashboard",page:"Main"}));
            
            return this;
        }
      
    });

   

});


