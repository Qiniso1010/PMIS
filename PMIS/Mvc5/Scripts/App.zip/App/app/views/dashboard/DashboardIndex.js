define(function (require) {

    "use strict";

    var //Handlebars          = require('handlebars'),
        //_                   = require('underscore'),
        //Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        //HandlerHelper       = require('handlebarshelper'),
        daterangepicker     = require('/Scripts/daterangepicker.js'),
        NProgress           = require('/Scripts/nprogress.js'),
        model_renderdash    = require('app/models/dashboard/RenderDashboard'),
        

    DashboardIndex = Backbone.View.extend({
        template : hb.Tem('Dashboard/DashboardIndex'),
        initialize : function() {
            this.render;
        },
        events : {
            "click #btnToday":"RenderToday",
            "click #btnWeek":"RenderWeek",
            "click #btnMonth":"RenderMonth",
            "click #btnYear":"RenderYear"
        },
        render: function (time,date,params) {
            this.$el.html(this.template());
            NProgress.done();

            this.$('input[name="daterange"]').daterangepicker({
                "buttonClasses": "btn btn-sm btn-flat no-border"
            });

            this.$('input[name="daterange"]').on('apply.daterangepicker', function(ev, picker) {
                var tanggal_val = $('input[name="daterange"]').val();
                var StartDate = Utility.DateFormatB(tanggal_val.split("-")[0]);
                var EndDate = Utility.DateFormatB(tanggal_val.split("-")[1]);

                // alert(StartDate + "-" + EndDate);
                // window.location.href = "#/dashboard/index/?StartDate="+StartDate.trim()+"&EndDate="+EndDate.trim();

            });

            this.RenderDashboard("default");

            this.RenderChart("default");
            return this;
        },
        RenderDashboard:function(tipe) {
            var template = hb.Tem('Dashboard/_partial/RenderDashboard');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var m = new model_renderdash.RenderDashboard();
            $('#render-dashboard').html('<center><hr/><h1>Loading...</h1></center>');
            m.fetch({
                data: $.param({ __RequestVerificationToken: token,tipe:tipe }),
                type: 'GET',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#render-dashboard').html(template(data.attributes));
                }
            });
            return this;
        },
        RenderToday:function(e) {
            this.RenderChart("today");
            this.RenderDashboard("today");
            return this;
        },
        RenderWeek:function(e) {
            // alert('week');
            this.RenderChart("week");
            this.RenderDashboard("week");
            return this;
        },
        RenderMonth:function(e) {
            this.RenderChart("month");
            this.RenderDashboard("month");
            return this;
            // alert('month');
        },
        RenderYear:function(e) {
            // alert('year');
            this.RenderChart("year");
            this.RenderDashboard("year");
            return this;

        },
        RenderChart:function(tipe) {
            var options = {
                chart: {
                    renderTo: 'container',
                    type: 'line',
                    marginRight: 130,
                    marginBottom: 25
                },
                loading: {
                    labelStyle: {
                        backgroundImage: 'url("http://jsfiddle.net/img/logo.png")',
                        display: 'block',
                        width: '136px',
                        height: '26px',
                        backgroundColor: '#000'
                    }
                },
                title: {
                    text: '',
                    x: -20 //center
                },
                subtitle: {
                    text: '',
                    x: -20
                },
                xAxis: {
                    categories: [],
                    labels: {
                            align: 'right',
                    }
                },
                yAxis: {
                    title: {
                        text: 'Value'
                    },
                    plotLines: [{
                        value: 0,
                        width: 1,
                        color: '#808080'
                    }]
                },
                tooltip: {
                    headerFormat: '<b>{series.name}</b><br>',
                    // pointFormat: '{point.x:%e. %b}: {point.y:.2f} m',
                    shared: true,
                    crosshairs: true
                },
                legend: {
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'top',
                    x: -10,
                    y: 100,
                    borderWidth: 0
                },
                series: []
            };
            Utility.IsLoading("#loading","show");
            // NProgress.start();
            $.getJSON("Notif/RenderDate/?tipe="+tipe, function(json) {
                Utility.IsLoading("#loading","hide");
                
                // NProgress.done();
                
                options.xAxis.categories = json.days;
                // pimpinan
                options.series[0] = new Object();
                options.series[0].name = "Agenda Pimpinan";
                options.series[0].data = json.agenda;
                options.series[0].color = "#00a65a";
                // meeting_room

                options.series[1] = new Object();
                options.series[1].name = "Meeting Room";
                options.series[1].data = json.meeting_room;
                options.series[1].color = "#00c0ef";

                options.series[2] = new Object();
                options.series[2].name = "Naskah Dinas";
                options.series[2].data = json.naskah_dinas;
                options.series[2].color = "#f39c12";

                options.series[3] = new Object();
                options.series[3].name = "SPT";
                options.series[3].data = json.spt;
                options.series[3].color = "#dd4b39";

                options.series[4] = new Object();
                options.series[4].name = "SPPD";
                options.series[4].data = json.sppd;
                options.series[4].color = "#605ca8";

                options.series[5] = new Object();
                options.series[5].name = "Arsip";
                options.series[5].data = json.arsip;
                options.series[5].color = "#d81b60";

                // options.series[1] = json.agenda;
                chart = new Highcharts.Chart(options);
                
                // chart.showLoading();
                //  chart.showLoading("Loading....");
            });


            return this;


        }

    });

    return {
        DashboardIndex: DashboardIndex
    };
});
