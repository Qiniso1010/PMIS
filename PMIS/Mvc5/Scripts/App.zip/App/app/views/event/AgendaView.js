define(function (require) {

    "use strict";

    var //Handlebars          = require('handlebars'),
        //_                   = require('underscore'),
        // Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        // HandlerHelper       = require('handlebarshelper'),
        Modal               = require('app/views/event/modal/ModalNoAttending'),
        NProgress           = require('/Scripts/nprogress.js'),
        
    AgendaView = Backbone.View.extend({
        template : hb.Tem('event/AgendaView'),
        initialize : function() {
            this.render;
        },
        events : {
            "click #linkUser":"UpdatedNoAttending"
        },
        render: function (time,date) {
            this.$el.html(this.template(this.model.attributes));
            
            NProgress.done();
            
            return this;
        },
        UpdatedNoAttending: function(e) {
            var $id = $(e.currentTarget).data("id");
            
            new Modal.ModalNoAttending({id:$id}).render();
        },
      
    });

    return {
        AgendaView: AgendaView
    };

   
   

});


