define(function (require) {

    "use strict";

    var //Handlebars          = require('handlebars'),
        // _                   = require('underscore'),
        // Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        // HandlerHelper       = require('handlebarshelper'),
        Models              = require('app/models/event/ProfileCheckName'),
        summernote          = require('summernote/summernote'),
        NProgress           = require('/Scripts/nprogress.js'),

    ProfileEdit = Backbone.View.extend({
        template : hb.Tem('event/ProfileAdd'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
            "change #file":"Upload"
        },
        render: function () {
            this.$el.html(this.template(this.model.attributes));
            
            NProgress.done();
            
            return this;
        },
        Upload: function () {
            Utility.prosesLoad("Y");
            var $options = {};
            
            var percent = $('#progress-bar');
            var fileUpload = $('#FormUpload').get(0);
            
            var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
            
            if ($.inArray($("#file").val().split('.').pop().toLowerCase(), fileExtension) == -1) {
                swal("Warning!","Only '.jpeg','.jpg', '.png', '.gif', '.bmp' formats are allowed.","error");
            } else {
                Utility.IsLoading("#loading","show");
                
                if (fileUpload.files != '') {
                    var form = $('#FormUpload')[0];
                    var form_data = new FormData(form);
                    
                    $options.xhr = function() {
                        var xhr = new window.XMLHttpRequest();
                        //Upload progress
                        xhr.upload.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total * 100;
                                percent.html(Math.round(percentComplete) + '%');
                            }
                        }, false);
                        //Download progress
                        xhr.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total * 100;
                                percent.html(Math.round(percentComplete) + '%');
                            }
                        }, false);
                        return xhr;
                    };
                    $options.url = 'UploadEvent/UploadImages/';
                    $options.dataType = 'json';
                    $options.cache = false;
                    $options.contentType = false;
                    $options.processData = false;
                    $options.data = form_data;
                    $options.type = 'POST';
                    $options.success = function(data) {
                        if (data.Attr == "Ok!") {
                            var percentValue = '100%';
                            percent.html(percentValue);
                            
                            $("#edit-img").hide();
                            $("#profile-pic").html("<img src='"+data.Message+"' class='images-thumb'/>");
                            
                            Utility.IsLoading("#loading", "hide");
                            Utility.prosesLoad("N");
                            
                            // Utility.AlertV2("check", data.Message, "success");
                            
                        } else {
                            Utility.AlertV2("exclamation-triangle", data.Message, "error");
                        }
                    };
                    
                    $options.error = function(xhr, ajaxOptions, thrownError) {
                        console.log(xhr.responseText);
                        alert(xhr.responseText);

                        Utility.IsLoading("#loading", "hide");
                        Utility.prosesLoad("N");
                    };
                    
                    $.ajax($options);
                }
            }
            
            return this;
        },
        BeforeSend:function() {
            var param = {
                Name:$("#name").val(),
                Email:$("#email").val()
            
            };
            
             if (param.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                $("#name").focus();

                $("#btnSave").attr("disabled", true);
                Utility.IsLoading("#loading","hide");
                
                return false;
            } else if (!Utility.IsEmail(param.Email)) {
                $("#email-id").removeClass("has-success");
                $("#email-id").addClass("has-error");
                $("#email").focus();
                swal("Error!","Email Not Valid!","error");

                $("#btnSave").attr("disabled", true);
                Utility.IsLoading("#loading","hide");
                
                return false;
            }
            
            return true;
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            
            Utility.prosesLoad("Y");
            var $options = {};
            var token = $('input[name="__RequestVerificationToken"]').val();
            
            if(this.BeforeSend()) {
                 var param = {
                    FullName:$("#name").val(),
                    __RequestVerificationToken: token,
                    Nip:$("#nip").val(),
                    Email:$("#email").val(),
                    Address:$("#address").val(),
                    Telp:$("#telp").val(),
                    Role:$("#role").val(),
                    SharedId:$("#SharedId").val(),
                    ProfileId:$("#id").val(),
                    Gapok:$('#gapok').val(),
                    Pangkat:$('#pangkat').val(),
                    Golongan:$('#golongan').val()
                    
                };
            
                $("#btnSave").attr("disabled",false);
                
                $options.url = "Profiles/Edit/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                        if (d.Attr == "Ok!") {
                            Utility.IsLoading("#loading","hide");
                            Utility.prosesLoad("N");
                            swal("Success!",d.Message,"success");
                            // Utility.AlertV2("check",d.Message,"success");
                            
                        } else {
                            Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        }
                        $("#name").focus();
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
            }
            
            return this;

        }
      
    });

    return {
        ProfileEdit: ProfileEdit
    };

   
   

});


