define(function (require) {

    "use strict";

    var //Handlebars          = require('handlebars'),
        //_                   = require('underscore'),
        //Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        //HandlerHelper       = require('handlebarshelper'),
        select2             = require('select2/select2'),
        NProgress           = require('/Scripts/nprogress.js'),

        

    FilesEdit = Backbone.View.extend({
        template : hb.Tem('arsip/FilesAddView'),
        initialize : function() {
            
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
            "focusout #name":"CheckName"
        },
        render: function () {
            this.$el.html(this.template(this.model.attributes));
            this.$("#btnSave").attr("disabled",false);
            NProgress.done();
            
            return this;
        },
        CheckName : function() {
            this.name = this.$("#name").val();
            this.token = this.$("#token").val();
            
           
            if (this.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                Utility.AlertV2("check","Name is empty!","error");
                $("#name").focus();
                $("#btnSave").attr("disabled",true);
            } else {
               $("#name-id").removeClass("has-error");
               $("#name-id").addClass("has-success"); 
               $("#btnSave").attr("disabled",false);
            }
            
            return this;  
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");

            var token = $('input[name="__RequestVerificationToken"]').val();
                        
            var param = {
                Name:$("#name").val(),
                __RequestVerificationToken:token,
                CategoryId:$("#id").val()
            
            };
            
            if (param.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                $("#btnSave").attr("disabled",true);
                $("#name").focus();
                Utility.IsLoading("#loading","hide");
            } else {
                $("#btnSave").attr("disabled",false);
                $.ajax({
                    url:"Files/Edit/",
                    type:"POST",
                    cache:false,
                    data:param,
                    dataType:"json",
                    success:function(d) {
                        Utility.IsLoading("#loading","hide");
                        if (d.Attr == "Ok!") {
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check",d.Message,"success");
                        } else {
                            Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        }
                        $("#name").focus();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        console.log(xhr.responseText);
                        alert(xhr.responseText);
                        Utility.prosesLoad("N");
                        Utility.IsLoading("#loading","hide");
                    }
                });
            }
            
            
            
            return this;

        }
      
    });

    return {
        FilesEdit: FilesEdit
    };

   
   

});


