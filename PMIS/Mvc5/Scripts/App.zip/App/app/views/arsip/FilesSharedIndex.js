define(function(require) {

  "use strict";

    var //Handlebars      = require('handlebars'),
        //_               = require('underscore'),
        //Backbone        = require('backbone'),
        hb              = require('hbtemplate'),
        Utility         = require('utility'),
        NProgress       = require('/Scripts/nprogress.js'),


    FilesSharedIndexView = Backbone.View.extend({
        template: hb.Tem('Arsip/FilesSharedIndexView'),
        initialize: function() {
            this.render;
        },
        render: function() {
            this.$el.html(this.template());
            NProgress.done();
            return this;
        }

    });

    return {
        FilesSharedIndexView: FilesSharedIndexView
    }



});
