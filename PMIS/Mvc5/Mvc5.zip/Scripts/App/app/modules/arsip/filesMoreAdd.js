
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function(id) {
             
            Utility.SelectedMenuItem("files");
            Utility.SelectedToogleItem("arsip");

            $("#title-header").html("Add");

            $("#h1-header").html("Folder");
            $("#header-page").html("Add Folder");

            // action
            var htm = "";
            htm += "<li class='nav-users'><a href='#/arsip/files/more/"+id+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";

            $("#navigasi").html(htm);


            Utility.IsLoading("#loading", "hide");
            
        }
       
    };
});