define(function (require) {
    var $ = require('jquery'),
      Utility = require('utility'),
      table = require('bootstrap-table/dist/bootstrap-table.min')

    return {
        Index: function () {
            // Top Nav
            this.Nav();
            // table
            this.Table();
            // caption form
            this.Caption();
        },
        Nav: function () {
            // action
            var htm = "";
            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
           
            $("#navigasi").html(htm);
            // end nav top


        },
        Caption: function() {
            // define title constant
            var appname = "Inbox";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("inbox");
            Utility.SelectedToogleItem("menu-laporan"); // parent

            $("#h1-header").html("Inbox <small>Laporan yang diterima.</small>");
            $("#header-page").html("Inbox");

            // refresh
            $("#btnRefresh").on("click", function () {
                $('#listing-grid').bootstrapTable('refresh');
            });
        },
        Table: function() {
            // listing
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Inboxs/',
                cache: false,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: true,
                showRefresh: true,
                cardView: false,
                showToggle: true,
                showExport: true,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [{
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, 
                {
                    field: 'Kode',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'NameAndId',
                    title: 'Nomor',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'Perihal',
                    title: 'Perihal',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'NameAndId',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Shared'
                },
                {
                    field: 'UpdatedAt',
                    title: 'Tanggal Kirim',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'UplBy',
                    title: 'Dikirim Oleh',
                    align: 'center',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'TypeData',
                    visible: false
                }]
            });
        }

    };
});
