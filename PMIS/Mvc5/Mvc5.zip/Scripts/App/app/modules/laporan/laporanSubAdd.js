
define(function (require) {
    var $           = require('jquery'),
        Utility     = require('utility')

    return {
        Index : function(id,name) {
             
            Utility.SelectedMenuItem("laporan");
            Utility.SelectedToogleItem("menu-laporan");

            $("#title-header").html("Membuat Laporan - " + name);

            $("#h1-header").html("Membuat Laporan - "+ name);
            $("#header-page").html("Membuat Laporan - "+ name);

            // action
            var htm = "";
            htm += "<li class='nav-users'><a href='#/laporan/index/sub/"+id+"/"+name+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";

            $("#navigasi").html(htm);


            Utility.IsLoading("#loading", "hide");
            
        }  
    };
});