define(function (require) {
    var $ = require('jquery'),
      Utility = require('utility'),
      table = require('bootstrap-table/dist/bootstrap-table.min'),
      ModalCategory = require('app/views/laporan/ModalRenderCategories')

    return {
        Index: function () {

            // Top Nav
            this.Nav();
            // table
            this.Table();
            // caption form
            this.Caption();
            // Delete 
            this.Delete();
            
            $('#ModalConfirm').modal({show:true});
            // move
            this.Move();

        },
        Nav: function () {
            // action
            var htm = "";
            htm += "<li class='nav-role'><a href='#/laporan/category/add' id='btnAdd' role='button'> <i class='icon ion-ios-plus-outline'></i> New Category </a></li>";
            htm += "<li class='nav-role'><a href='#/laporan/index/new' id='btnUpload' role='button'> <i class='icon ion-ios-copy-outline'></i> Membuat Laporan </a></li>";

            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnDelete' role='button'> <i class='icon ion-ios-close-outline'></i> Delete </a></li>";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnMove' role='button'> <i class='icon ion-log-in'></i> Move </a></li>";
            
            $("#navigasi").html(htm);
            // end nav top


            // hide action button
            $("#btnDelete").hide();
            $("#btnMove").hide();
        },
        Caption: function() {
            // define title constant
            var appname = "Laporan";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("laporan");
            Utility.SelectedToogleItem("menu-laporan"); // parent

            $("#h1-header").html("Laporan");
            $("#header-page").html("Laporan");

            // refresh
            $("#btnRefresh").on("click", function () {
                $('#listing-grid').bootstrapTable('refresh');
            });
        },
        Table: function() {
            // listing
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Categories/',
                cache: false,
                //height: 500,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: true,
                showRefresh: true,
                cardView: false,
                showToggle: true,
                showExport: true,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [{
                    field: 'stat',
                    checkbox: true
                }, {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, 
                {
                    field: 'Kode',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'NameAndId',
                    title: 'Kategori / Nomor',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'Perihal',
                    title: 'Perihal',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'NameAndId',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Shared'
                },
                {
                    field: 'UpdatedAt',
                    title: 'Tanggal Kirim',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'UplBy',
                    title: 'Dikirim Oleh',
                    align: 'center',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'TypeData',
                    visible: false
                }],
                onCheck: function (row) {
                    $("#btnDelete").show();
                    $("#btnMove").show();
                },
                onUncheck: function (row) {
                    $("#btnDelete").hide();
                    $("#btnMove").hide();
                },
                onCheckAll: function () {
                    $("#btnDelete").show();
                    $("#btnMove").show();
                },
                onUncheckAll: function () {
                    $("#btnDelete").hide();
                    $("#btnMove").hide();
                }
            });
        },
        Move:function () {
            $("#btnMove").on("click", function () {
                Move();
            });
            
           function Move() {
                Utility.prosesLoad("Y");
                Utility.IsLoading("#loading", "show");

                var param = Array();
                param = $('#listing-grid').bootstrapTable('getSelections');
                var i;
                if (param.length > 0) {

                    $('#btnMove').hide();
                    store.set('LaporanId',param);
                    store.set('HitungLaporan',param.length);
                    
                    new ModalCategory.ModalCategories().render();
                    
                    
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading", "hide");
                } else {
                    Utility.AlertV2("remove", "Please select data first", "error");
                    Utility.IsLoading("#loading", "hide");
                    store.remove("LaporanId");
                    store.remove("HitungLaporan");
                }
            }
            
        },
        Delete: function () {

            /// delete button action
            $("#btnDelete").on("click", function () {
                Delete();
            });

            // delete
            function Delete() {
                swal({
                    title: "Yakin ingin menghapus File?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                DeleteAction(param[i].Id, param[i].TypeData);
                            }

                            $("#btnDelete").hide();

                            Utility.prosesLoad("N");
                            Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            var token = $('input[name="__RequestVerificationToken"]').val();

            // delete action
            function DeleteAction(id, tipe) {
                if (tipe == 'B') {
                    var param = {
                        id: id,
                        __RequestVerificationToken: token
                    }
                    var url = 'Categories/DeleteLaporan/';
                } else {
                    var param = {
                        id: id,
                        __RequestVerificationToken: token,
                    }
                    var url = 'Categories/Delete/';
                }
                $.ajax({
                    url: url,
                    cache: false,
                    type: 'POST',
                    data: param,
                    dataType: 'json',
                    success: function (d) {
                        if (d.Attr == "Ok!") {
                            Utility.AlertV2("check", d.Message, "success");
                        } else {
                            Utility.AlertV2("remove", d.Message, "error");
                        }

                        $('#listing-grid').bootstrapTable('refresh');
                    },
                    error: function (err) {
                        alert(err.responseText);
                    }
                });
            }
            // end action
        }

    };
});
