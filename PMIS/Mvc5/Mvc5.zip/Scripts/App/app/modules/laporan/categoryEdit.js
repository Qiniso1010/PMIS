
define(function (require) {
    var $           = require('jquery'),
        Utility     = require('utility')

    return {
        Index : function() {
             
            // menu
            Utility.SelectedMenuItem("Edit Kategori");
            Utility.SelectedToogleItem("menu-laporan");

            $("#title-header").html("Edit Kategori");

            $("#h1-header").html("Kategori <small>Edit</small>");
            $("#header-page").html("Edit Kategori");
            
            // action
            var htm = "";
            htm += "<li class='nav-roles'><a href='#/laporan/index' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
            $("#navigasi").html(htm);
            // loading
            Utility.IsLoading("#loading", "hide");   
            
        }
       
    };
});