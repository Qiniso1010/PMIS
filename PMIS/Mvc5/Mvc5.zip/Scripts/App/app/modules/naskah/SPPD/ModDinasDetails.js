
define(function (require) {
    var Utility             = require('utility'),
        modal_disposisi     = require('app/views/Naskah/SPPD/Modal/ModalDisposisi')

    return {
        Index : function(sharedid,id,querystr) {
            // menu
            Utility.SelectedMenuItem("manage-perjalanan-dinas");
            Utility.SelectedToogleItem("perjalanan-dinas");
            
            var appname = "Surat Perintah Tugas Selengkapnya";

            $("#title-header").html(appname);

            $("#h1-header").html(appname + " <small>Selengkapnya</small>");
            $("#header-page").html(appname);
            
            if (querystr.ReturnUrl != undefined) {
                var str =  querystr.ReturnUrl;
            } else {
                var str = "#/naskah/dinas/manage/index";
            }
            // action
            var htm = "";
            htm += "<li class='nav-roles'><a href='"+str+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
            htm += "<li class='nav-roles'><a href='javascript:;' id='btnDisposisiUnit' role='button'> <i class='icon ion-ios-plus-outline'></i> Disposisikan kembali </a></li>";
            htm += "<li class='nav-roles'><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            $("#navigasi").html(htm);
            // loading
            Utility.IsLoading("#loading", "hide");   
            
            // alert(querystr.ReturUrl);
            
            // View modal disposisi
            $("#btnDisposisiUnit").click(function() {
               new modal_disposisi.ModalDisposisi().render();
            });
            
            $("#btnRefresh").click(function() {
                location.reload(); 
            });
            
            
        }
       
    };
});