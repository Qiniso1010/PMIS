
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function() {
             
            Utility.SelectedMenuItem("master-template");
            Utility.SelectedToogleItem("tata-naskah-dinas");

            $("#title-header").html("Membuat Template Dokumen ");

            $("#h1-header").html("Membuat Template Dokumen <small>Membuat template berdasarkan jenis dokumen.</small>");
            $("#header-page").html("Membuat Template Dokumen");

            // action
            var htm = "";
            htm += "<li class='nav-users'><a href='#/naskah/master-template/index' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";

            $("#navigasi").html(htm);
            Utility.IsLoading("#loading", "hide");
            
        }  
    };
});