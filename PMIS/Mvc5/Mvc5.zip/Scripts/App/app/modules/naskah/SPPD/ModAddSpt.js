
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function(id,params) {
             
            Utility.SelectedMenuItem("manage-perjalanan-dinas");
            Utility.SelectedToogleItem("perjalanan-dinas");
            
            var appname = "Membuat SPT";

            $("#title-header").html(appname);

            $("#h1-header").html(appname + "<small>Isikan kolom dibawah ini secara lengkap.</small>");
            $("#header-page").html(appname);

            // action
            var htm = "";
            htm += "<li class='nav-users'><a href='#/naskah/dinas/manage/index' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";

            $("#navigasi").html(htm);


            Utility.IsLoading("#loading", "hide");
            
        }  
    };
});