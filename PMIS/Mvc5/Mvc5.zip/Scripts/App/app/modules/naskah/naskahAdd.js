
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function() {
             
            Utility.SelectedMenuItem("manage");
            Utility.SelectedToogleItem("tata-naskah-dinas");

            $("#title-header").html("Membuat Naskah ");

            $("#h1-header").html("Membuat Naskah <small>Isikan dengan lengkap kolom dibawah ini.</small>");
            $("#header-page").html("Membuat Naskah");

            // action
            var htm = "";
            htm += "<li class='nav-users'><a href='#/naskah/index' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";

            $("#navigasi").html(htm);


            Utility.IsLoading("#loading", "hide");
            
        }  
    };
});