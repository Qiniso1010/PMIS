define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min'),
        ModalCategory       = require('app/views/naskah/ModalRenderCategories'),
        NProgress           = require('/Scripts/nprogress.js')

    return {
        Index: function (id,name) {

            // Top Nav
            this.Nav(id,name);
            // table
            this.Table(id);
            // caption form
            this.Caption(name);
            // Delete 
            this.Delete();
            
            this.Move();

        },
        Nav: function (id,name) {
            // action
            var htm = "";
            htm += "<li class='nav-users'><a href='#/naskah/index' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
            htm += "<li class='nav-role'><a href='#/naskah/index/sub/new/"+id+"/"+name+"' id='btnAdd' role='button'> <i class='icon ion-ios-copy-outline'></i> Membuat Naskah Dinas </a></li>";

            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnDelete' role='button'> <i class='icon ion-ios-close-outline'></i> Delete </a></li>";
            htm += "<li class='nav-role-del'><a href='javascript:;' id='btnMove' role='button'> <i class='icon ion-log-in'></i> Move </a></li>";
            
            $("#navigasi").html(htm);
            // end nav top

            // hide action button
            $("#btnDelete").hide();
            $("#btnMove").hide();
        },
        Caption: function(name) {
            // define title constant
            var appname = "Tata Naskah Dinas - " + name;
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("manage");
            Utility.SelectedToogleItem("tata-naskah-dinas"); // parent

            $("#h1-header").html("Tata Naskah Dinas <small>"+name+"</small>");
            $("#header-page").html("Tata Naskah Dinas - " +name);

            // refresh
            $("#btnRefresh").on("click", function () {
                $('#listing-grid').bootstrapTable('refresh');
            });
            
             Utility.IsLoading("#loading", "hide");
        },
        Table: function(id) {
            // listing
            NProgress.start();
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Categories/IndexMore?CategoryId='+id,
                cache: false,
                //height: 500,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: true,
                showRefresh: true,
                cardView: false,
                showToggle: true,
                showExport: true,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: true,
                columns: [{
                    field: 'stat',
                    checkbox: true
                }, {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, 
                {
                    field: 'Kode',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'Tanggal',
                    title: 'Tanggal',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'NameAndId',
                    title: 'Name',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'Perihal',
                    title: 'Judul / Perihal',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'NameAndId',
                    title: '',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Shared'
                },
                {
                    field: 'UpdatedAt',
                    title: 'Date Modified',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'UplBy',
                    title: 'Created by',
                    align: 'center',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'TypeData',
                    visible: false
                }],
                onCheck: function (row) {
                    $("#btnDelete").show();
                    $("#btnMove").show();
                },
                onUncheck: function (row) {
                    $("#btnDelete").hide();
                    $("#btnMove").hide();
                },
                onCheckAll: function () {
                    $("#btnDelete").show();
                    $("#btnMove").show();
                },
                onUncheckAll: function () {
                    $("#btnDelete").hide();
                    $("#btnMove").hide();
                },
                onLoadError: function(err) {
                    alert(err);
                },
                onLoadSuccess: function() {
                    NProgress.done();
                }
            });
        },
        Move:function () {
            $("#btnMove").on("click", function () {
                Move();
            });
            
           function Move() {
                Utility.prosesLoad("Y");
                Utility.IsLoading("#loading", "show");

                var param = Array();
                param = $('#listing-grid').bootstrapTable('getSelections');
                var i;
                if (param.length > 0) {

                    $('#btnMove').hide();
                    store.set('LaporanId',param);
                    store.set('HitungLaporan',param.length);
                    
                    new ModalCategory.ModalCategories().render();
                    
                    
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading", "hide");
                } else {
                    Utility.AlertV2("remove", "Please select data first", "error");
                    Utility.IsLoading("#loading", "hide");
                    store.remove("LaporanId");
                    store.remove("HitungLaporan");
                }
            }
            
        },
        Delete: function () {

            /// delete button action
            $("#btnDelete").on("click", function () {
                Delete();
            });

            // delete
            function Delete() {
                swal({
                    title: "Yakin ingin menghapus File?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
                function (isConfirm) {
                    if (isConfirm) {
                        Utility.prosesLoad("Y");
                        // Utility.IsLoading("#loading", "show");

                        var param = Array();
                        param = $('#listing-grid').bootstrapTable('getSelections');

                        var i;
                        if (param.length > 0) {
                            for (i = 0; i < param.length; i++) {
                                DeleteAction(param[i].Id, param[i].TypeData);
                            }

                            $("#btnDelete").hide();

                            Utility.prosesLoad("N");
                            // Utility.IsLoading("#loading", "hide");
                        } else {
                            Utility.AlertV2("remove", "Please select data first", "error");
                            // Utility.IsLoading("#loading", "hide");
                        }
                    }

                });


            }
            var token = $('input[name="__RequestVerificationToken"]').val();

            // delete action
            function DeleteAction(id, tipe) {
                NProgress.start();
                 var param = {
                    id: id,
                    __RequestVerificationToken: token
                }

                var url = 'Categories/DeleteLaporan/';
                $.ajax({
                    url: url,
                    cache: false,
                    type: 'POST',
                    data: param,
                    dataType: 'json',
                    success: function (d) {
                        NProgress.done();
                        if (d.Attr == "Ok!") {
                            Utility.AlertV2("check", d.Message, "success");
                        } else {
                            Utility.AlertV2("remove", d.Message, "error");
                        }

                        $('#listing-grid').bootstrapTable('refresh');
                    },
                    error: function (err) {
                        alert(err.responseText);
                    }
                });
            }
            // end action
        }

    };
});
