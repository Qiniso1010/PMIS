
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function(id,querystr) {
             
            // menu
            Utility.SelectedMenuItem("master-template");
            Utility.SelectedToogleItem("tata-naskah-dinas");

            $("#title-header").html("Edit Template Dokumen");

            $("#h1-header").html("Template Dokumen <small>Edit</small>");
            $("#header-page").html("Edit Template Dokumen");
            
            var str =  querystr.ReturnUrl;
            // action
            var htm = "";
            htm += "<li class='nav-roles'><a href='"+str+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
            $("#navigasi").html(htm);
            // loading
            Utility.IsLoading("#loading", "hide");   
            
        }
       
    };
});