define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min'),
        easycal             = require('/Scripts/calendar/easycal.js'),
        moment              = require('moment'),
        NProgress           = require('/Scripts/nprogress.js')

    return {
        Index: function (id,tanggal) {
            // Top Nav
            this.Nav(id);
            // table
            this.Table(id,tanggal);
            // caption form
            this.Caption();
        },
        Nav: function (id) {
            // action
            var htm = "";
            htm += "<li class='nav-users'><a href='#/agenda/index/?Id="+id+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
           
            $("#navigasi").html(htm);
            // end nav top


        },
        Caption: function() {
            // define title constant
            var appname = "Weekly View Agenda Pimpinan";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("agenda-index");
            Utility.SelectedToogleItem("agenda-pimpinan"); // parent

            $("#h1-header").html(appname + "<small>Menampilkan agenda pimpinan secara mingguan</small>");
            $("#header-page").html(appname);

        },
        Table: function(id,tanggal) {
            NProgress.start();
            var $options = {};
            var param = {
              Tanggal:moment(tanggal,'DD-MM-YYYY').format('YYYY-MM-DD'),
              ProfileId:id
            };
            $options.url = "AgendaPimpinan/";
            $options.type = "GET";
            $options.cache = false;
            $options.data = param;
            $options.dataType = "json";
            $options.success = function(d) {
                NProgress.done();
                
                $('#mycal').easycal({
                    startDate : tanggal, // OR 31/10/2104
                    timeFormat : 'HH:mm',
                    columnDateFormat : 'dddd, DD MMM',
                    minTime : '07:00:00',
                    maxTime : '24:00:00',
                    slotDuration : 30,
                    timeGranularity : 15,
                    
                    dateClick:function(el,startDate,startTime) {
                        window.location.href = "#/agenda/weekly/add/"+id+"/"+tanggal+"/"+startTime+"/"+startDate;
                    },
                    eventClick : function(eventId){
                        window.location.href = "#/agenda/weekly/view/"+id+"/"+tanggal+"/"+eventId;
                    },
                    events : d,
                    
                    overlapColor : '#FF0',
                    overlapTextColor : '#000',
                    overlapTitle : 'Multiple'
                });  
            };
            $options.error = function(err) {
                alert(err.responseText);  
            };
            $.ajax($options);  
            
           
            
        }
       
        

    };
});
