
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function(id,tanggal,eventid,querystr) {
            
            var appname = "Edit Agenda";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("agenda-view");
            Utility.SelectedToogleItem("meeting-room"); // parent

            $("#h1-header").html("Edit Agenda <small>Update data agenda.</small>");
            $("#header-page").html("Edit Agenda");
            
            var htm = "";
            htm += "<li class='nav-users'><a href='#/agenda/meeting-room/weekly/view/"+id+"/"+tanggal+"/"+eventid+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
            
            $("#navigasi").html(htm);


            Utility.IsLoading("#loading", "hide");
            
        }  
    };
});