
define(function (require) {
    var Utility     = require('utility')

    return {
        Index : function(id,tanggal,eventid,querystr) {
            
            var appname = "Edit Agenda Pimpinan";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("agenda-index");
            Utility.SelectedToogleItem("agenda-pimpinan"); // parent

            $("#h1-header").html(appname + "<small>Update data agenda.</small>");
            $("#header-page").html(appname);
            
            var htm = "";
            htm += "<li class='nav-users'><a href='#/agenda/weekly/view/"+id+"/"+tanggal+"/"+eventid+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
            
            $("#navigasi").html(htm);


            Utility.IsLoading("#loading", "hide");
            
        }  
    };
});