define(function (require) {
    var Utility         = require('utility'),
        table           = require('bootstrap-table/dist/bootstrap-table.min')

    return {
        Index: function (params) {
            // Top Nav
            this.Nav(params);
            // table
            this.Table();
            // caption form
            this.Caption(params);
            
            // this.init('ajax');
        },
        Nav: function (params) {
            // action
            var htm = "";
            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnPrint' role='button'> <i class='icon ion-ios-printer-outline'></i> Print </a></li>";

            $("#navigasi").html(htm);
            
            $("#btnRefresh").on("click", function () {
               location.reload();
            });
            
            $('#btnPrint').on('click',function() {
                if (params.Name != undefined) {
                    var Name = params.Name;
                } else {
                    var Name = '';
                }
                
                if (params.Id != undefined) {
                    var Id = params.Id;
                } else {
                    var Id = 0;
                }
                
                window.location.href = "#/agenda/meeting-room/print/?Id="+Id+"&Name="+Name+"&ReturnUrl=#/agenda/meeting-room/monthly/index";
            });
            // end nav top


        },
        Caption: function(params) {
            // define title constant
            var appname = "Monthly View";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("agenda-view");
            Utility.SelectedToogleItem("meeting-room"); // parent
            
            if (params.Name != undefined) {
              $("#h1-header").html("Monthly View ("+params.Name+") <small>Menampilkan penggunaan gedung / ruangan secara satu bulan</small>");  
            } else {
              $("#h1-header").html("Monthly View <small>Menampilkan penggunaan gedung / ruangan secara satu bulan</small>");  

            }
            
            $("#header-page").html("Monthly View");

        },
        Table: function() {
            // listing
            
        }
        

    };
});
