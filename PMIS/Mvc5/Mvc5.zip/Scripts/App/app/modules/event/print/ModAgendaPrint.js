
define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min'),
        print               = require('/Scripts/jquery.print.js'),
        daterangepicker     = require('/Scripts/daterangepicker.js'),
        iCheck              = require('/Scripts/icheck.js'),
        NProgress           = require('/Scripts/nprogress.js')
        

    return {
        Index : function(params) {
            // Header
            this.Header(params);
            
            // Navigation
            this.Nav(params);
            
            // Table 
            this.Table(params);
            
            
        },
        Header : function(params) {
            if (params.Name != undefined) {
                var Name = ": " + params.Name;
            } else {
                var Name = "";
            }
            
            if (params.Id != undefined) {
                var Id = params.Id;
                // Set Id 
                if (Id != 0) {
                    store.set('profileId', Id);
                }
            } else {
                var Id = 0;
            }
            
          
            var check = '<input type="checkbox" id="all" name="all" style="margin-top:-6px !important"/> Semua data.';
            var appname = "Rekap / Cetak Agenda " + Name;
            
            if (params.CheckIt != undefined) {
                if (params.CheckIt == 0) {
                    var check = '<input type="checkbox" id="all" name="all" style="margin-top:-6px !important" /> Semua data.';
                    var appname = "Rekap / Cetak Agenda " + Name;
                } else {
                    var check = '<input type="checkbox" id="all" name="all" style="margin-top:-6px !important" checked/> Semua data.';
                    var appname = "Rekap / Cetak Agenda";
                }
            } 
            
            
            $("#title-header").html(appname);
            $("#Header").html("<h1>"+appname+"</h1>");
            
            
            // menu
            Utility.SelectedMenuItem("manage-meeting-rooms");
            Utility.SelectedToogleItem("meeting-room"); // parent
            
            var tanggal = "<input type='text' name='daterange' class='daterange'/>";
            
            var link = "<div class='pull-left parent-daterange'>"+tanggal+" &nbsp; "+check+" &nbsp; <a href='javascript:;' id='btnPrint'><i class='icon ion-ios-printer-outline'></i></a> &nbsp; </div>"
            
            $("#h1-header").html(link);
            $("#header-page").html(appname);
            
            
            $('input[name="daterange"]').daterangepicker({
                "buttonClasses": "btn btn-sm btn-flat no-border"
            });
            
            $('input[name="daterange"]').on('apply.daterangepicker', function(ev, picker) {
                var tanggal_val = $('input[name="daterange"]').val();
                var StartDate = Utility.DateFormatB(tanggal_val.split("-")[0]);
                var EndDate = Utility.DateFormatB(tanggal_val.split("-")[1]);
               
                
                window.location.href = "#/agenda/meeting-room/print/?Id="+params.Id+"&Name="+params.Name+"&StartDate="+StartDate.trim()+"&EndDate="+EndDate.trim()+"&ReturnUrl="+params.ReturnUrl;

            });
            
            
        },
        Nav : function(params) {
            
            if (params.ReturnUrl != undefined) {
                var returnUrl = "#/agenda/meeting-room/monthly/index/?Id="+params.Id+"&Name="+params.Name;
            } else {
                var returnUrl = "#/agenda/meeting-room/monthly/index";
            }
            
            var htm = "";
            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            htm += "<li class='nav-users'><a href='"+returnUrl+"' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
           
            $("#navigasi").html(htm);
            
             // refresh
            $("#btnRefresh").on("click", function () {
                $('#listing-grid').bootstrapTable('refresh');
            });
            
            

            Utility.IsLoading("#loading", "hide");
        },
        Table: function(params) {
            
            if (params.StartDate != undefined) {
                var StartDate = Utility.DateFormatB(params.StartDate);
            } else {
                var StartDate = '';
            }
            
            if (params.EndDate != undefined) {
                var EndDate = Utility.DateFormatB(params.EndDate);
            } else {
                var EndDate = '';
            }
            
            if (params.Id != undefined) {
                var Id = params.Id;
            } else {
                var Id = 0;
            }
            
              // Icheck
            $('#all').iCheck({
                checkboxClass: 'icheckbox_square-red',
                radioClass: 'iradio_square-red',
                increaseArea: '20%' // optional
            });
            
            $('#all').on('ifChecked', function(event){
                window.location.href = "#/agenda/meeting-room/print/?Id=0&Name="+params.Name+"&StartDate="+StartDate.trim()+"&EndDate="+EndDate.trim()+"&CheckIt=1&ReturnUrl="+params.ReturnUrl;

            });
            
            $('#all').on('ifUnchecked', function(event){
                
                // alert(event.type + ' callback');
                var Idx = store.get('profileId');
                window.location.href = "#/agenda/meeting-room/print/?Id="+Idx+"&Name="+params.Name+"&StartDate="+StartDate.trim()+"&EndDate="+EndDate.trim()+"&CheckIt=0&ReturnUrl="+params.ReturnUrl;

            });
            // define
            if (params.StartDate != undefined || params.EndDate != undefined) {
                $('input[name="daterange"]').val(Utility.DateFormatDefault(params.StartDate) + " - " + Utility.DateFormatDefault(params.EndDate));
            }
            
            
            $('#btnPrint').on("click",function(e) {
               
                $("#cetak").print({
                    globalStyles: true,
                    mediaPrint: false,
                    stylesheet: null,
                    noPrintSelector: ".no-print",
                    iframe: true,
                    append: null,
                    prepend: null,
                    manuallyCopyFormValues: true,
                    deferred: $.Deferred(),
                    timeout: 250
                }); 
            });
            NProgress.start();
             // listing
            $('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Prints/?RoomId='+Id+'&StartDate='+StartDate+'&EndDate='+EndDate,
                cache: false,
                striped: false,
                pagination: false,
                sidePagination: "server",
                // pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: false,
                showColumns: false,
                showRefresh: false,
                cardView: false,
                showToggle: false,
                showExport: false,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: false,
                columns: [ 
                {
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, 
                {
                    field: 'Tanggal',
                    title: 'Tanggal',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'RoomName',
                    title: 'Meeting Room',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'Title',
                    title: 'Agenda',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                }],
                onLoadSuccess: function() {
                    NProgress.done();
                }
            });
        }
    };
});