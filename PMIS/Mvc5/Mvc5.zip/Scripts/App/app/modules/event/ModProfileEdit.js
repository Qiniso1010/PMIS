
define(function (require) {
    var Utility         = require('utility'),
        modal_account   = require('app/views/event/modal/ModalAccount')

    return {
        Index : function(id) {
            
            var appname = "Edit Profile";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("manage-profile");
            Utility.SelectedToogleItem("agenda-pimpinan"); // parent

            $("#h1-header").html("Edit Profile <small>Mengubah data sebelumnya</small>");
            $("#header-page").html("Edit Profile");
            
            var htm = "";
            htm += "<li class='nav-users'><a href='#/agenda/profile/index' id='back' role='button'> <i class='icon ion-ios-arrow-thin-left'></i> Back </a></li>";
            htm += "<li class='nav-users'><a href='javascript:;' id='btnConnect' data-id='"+id+"' role='button'> <i class='icon ion-android-open'></i> Connect Account </a></li>";
   
            $("#navigasi").html(htm);
            
            // Connect
            this.Connect(id);
            


            Utility.IsLoading("#loading", "hide");
            
        },
        Connect: function(id) {
            $('#btnConnect').click(function(e) {
               var idx = $(e.currentTarget).data('id');
               
               new modal_account.ModalAccount({id:idx}).render();
               
            });
        }  
    };
});