define(function (require) {
    var Utility             = require('utility'),
        table               = require('bootstrap-table/dist/bootstrap-table.min')

    return {
        Index: function (params) {
            // Top Nav
            this.Nav(params);
            // table
            this.Table();
            // caption form
            this.Caption(params);
            
            // this.init('ajax');
        },
        Nav: function (params) {
            // action
            var htm = "";
            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnRefresh' role='button'> <i class='icon ion-ios-reload'></i> Refresh </a></li>";
            htm += "<li class='nav-role-refresh '><a href='javascript:;' id='btnPrint' role='button'> <i class='icon ion-ios-printer-outline'></i> Print </a></li>";

            $("#navigasi").html(htm);
            
            $("#btnRefresh").on("click", function () {
               location.reload();
            });
            
            $('#btnPrint').on('click',function() {
                if (params.Name != undefined) {
                    var Name = params.Name;
                } else {
                    var Name = '';
                }
                
                if (params.Id != undefined) {
                    var Id = params.Id;
                } else {
                    var Id = 0;
                }
                
                window.location.href = "#/agenda/print/?Id="+Id+"&Name="+Name+"&ReturnUrl=#/agenda/index";
            });
            // end nav top


        },
        Caption: function(params) {
            // define title constant
            var appname = "Agenda Pimpinan View";
            
            $("#title-header").html(appname);
            // menu
            Utility.SelectedMenuItem("agenda-index");
            Utility.SelectedToogleItem("agenda-pimpinan"); // parent
            if (params.Name != undefined) {
              $("#h1-header").html("Agenda Pimpinan ("+params.Name+") <small>Menampilkan jadwal agenda pada bulang yang dipilih</small>");  
            } else {
              $("#h1-header").html("Agenda Pimpinan <small>Menampilkan jadwal agenda pada bulang yang dipilih</small>");  

            }
            
            $("#header-page").html(appname);

        },
        Table: function() {
            // listing
            
        }
        

    };
});
