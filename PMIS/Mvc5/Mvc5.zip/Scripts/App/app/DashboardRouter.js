define(function(require) {

  "use strict";

  var   Backbone        = require('backbone'),
        Handlerbars     = require('handlebars'),
        Boostrap        = require('bootstrap.min'),
        AdminLTE        = require('dist/js/app'),
        Utility         = require('utility'),
        hbhelper        = require('handlebarshelper'),
        iCheck          = require('icheck'),
        Modernizr       = require('modernizr-2.8.3'),
        swal            = require('sweetalert.min'),
        NProgress       = require('/Scripts/nprogress.js'),
        $content        = $("#content"),
        $default_routes = $('#routes').val(),
        $headerAction   = $("#content-header");
   
    return {
        Init:function(router) {
            
            // Default Index
            router.on("route:dashboardIndex",function() {
                require(
                [
                    "app/views/dashboard/DashboardIndex",
                    "app/modules/dashboard/ModDashboardIndex",
                    "app/views/systems/DashboardAction",
                    "hbtemplate",
                    "jquery"
                ],
                function(Views, Modules, DashboardAction, hb, $) {
                    // Utility.IsLoading("#loading", "show");
                    NProgress.start();
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new Views.DashboardIndex().render().el);
                    // load content module
                    Modules.Index();
                    
                    // Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();


                });
            });
            
            
        } // End Init
    } // End Return
    
});