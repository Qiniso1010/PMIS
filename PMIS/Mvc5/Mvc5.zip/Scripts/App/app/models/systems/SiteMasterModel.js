define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        SiteMasterMod = Backbone.Model.extend({

            urlRoot: "users/GetUserData",
            defaults: {
                token:"",
                id: null,
                title:null,
                bahasa:"",
                IsMenu:"",
                posisi_menu:"",
                konten:"dasfadf"
            }

            // initialize: function () {
            //     this.reports = new SiteMasterCollection();
            //     this.reports.url = this.urlRoot + "/" + this.id + "/reports";
            // }

        }),

        SiteMasterCollection = Backbone.Collection.extend({

            model: SiteMasterMod,
            url: "users/GetUserData"

        });

    return {
        SiteMasterMod: SiteMasterMod,
        SiteMasterCollection: SiteMasterCollection
    };

});