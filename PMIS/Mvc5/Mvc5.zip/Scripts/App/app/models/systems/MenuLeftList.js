define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        MenuLeftListModel = Backbone.Model.extend({

            urlRoot: "CMenu/ListingMenuAdmin/",
            defaults: {
                term:""
            }

        }),

        MenuLeftListCollection = Backbone.Collection.extend({

            model: MenuLeftListModel,
            url: "CMenu/ListingMenuAdmin/"

        });

    return {
        MenuLeftListModel: MenuLeftListModel,
        MenuLeftListCollection: MenuLeftListCollection
    };

});