define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        MainSideBarMod = Backbone.Model.extend({

            urlRoot: "users/GetUserData",
            defaults: {
                token:"",
                id: null,
                title:null,
                bahasa:"",
                IsMenu:"",
                posisi_menu:"",
                konten:"dasfadf"
            }

        }),

        MainSideBarCollection = Backbone.Collection.extend({

            model: MainSideBarMod,
            url: "users/GetUserData"

        });

    return {
        MainSideBarMod: MainSideBarMod,
        MainSideBarCollection: MainSideBarCollection
    };

});