define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetExistName = Backbone.Model.extend({
            urlRoot:"Roles/Check/"

        }),

        GetExistNameCollection = Backbone.Collection.extend({
            model: GetExistName,
            url:"Roles/Check/"
        });

    return {
        GetExistName: GetExistName,
        GetExistNameCollection: GetExistNameCollection
    };

});