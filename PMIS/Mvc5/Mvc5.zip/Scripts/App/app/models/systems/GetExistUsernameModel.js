define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetExistUsername = Backbone.Model.extend({
            urlRoot:"Users/CheckUsernameExist/",
            defaults: {
                status:null
            }

        }),

        GetExistUsernameCollection = Backbone.Collection.extend({
            model: GetExistUsername,
            url:"Users/CheckUsernameExist/"
        });

    return {
        GetExistUsername: GetExistUsername,
        GetExistUsernameCollection: GetExistUsernameCollection
    };

});