define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetNaskahDetails = Backbone.Model.extend({
            urlRoot:"LaporanDocs/DetailsBySharedId/",
            defaults: {
                status:null
            }

        }),

        GetNaskahDetailsColl = Backbone.Collection.extend({
            model: GetNaskahDetails,
        });

    return {
        GetNaskahDetails : GetNaskahDetails,
        GetNaskahDetailsColl: GetNaskahDetailsColl
    };

});