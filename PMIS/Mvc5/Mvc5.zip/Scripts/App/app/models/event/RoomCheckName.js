define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        RoomCheckName = Backbone.Model.extend({
            urlRoot:"Rooms/CheckName/",
            defaults: {
                status:null
            }

        }),

        RoomCheckNameColl = Backbone.Collection.extend({
            model: RoomCheckName,
            url:"Rooms/CheckName/"
        });

    return {
        RoomCheckName: RoomCheckName,
        RoomCheckNameColl: RoomCheckNameColl
    };

});