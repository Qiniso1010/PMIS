define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetSharedId = Backbone.Model.extend({
            urlRoot:"Rooms/GetSharedId/",
            defaults: {
                status:null
            }

        }),

        GetSharedIdCol = Backbone.Collection.extend({
            model: GetSharedId,
            url:"Rooms/GetSharedId/"
        });

    return {
        GetSharedId: GetSharedId,
        GetSharedIdCol: GetSharedIdCol
    };

});