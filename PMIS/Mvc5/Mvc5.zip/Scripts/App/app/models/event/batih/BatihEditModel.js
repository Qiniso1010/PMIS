define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        BatihEditModel = Backbone.Model.extend({
            urlRoot:"Batihs/Details/",
            defaults: {
                status:null
            }

        }),

        BatihEditModelColl = Backbone.Collection.extend({
            model: BatihEditModel,
        });

    return {
        BatihEditModel : BatihEditModel,
        BatihEditModelColl: BatihEditModelColl
    };

});