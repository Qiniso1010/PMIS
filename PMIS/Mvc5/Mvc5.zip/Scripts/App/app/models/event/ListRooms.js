define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        ListRooms = Backbone.Model.extend({
            urlRoot:"Rooms/Lists",
            defaults: {
                status:null
            }

        }),

        ListRoomsColl = Backbone.Collection.extend({
            model: ListRooms,
            url:"Rooms/Lists"
        });

    return {
        ListRooms: ListRooms,
        ListRoomsColl: ListRoomsColl
    };

});