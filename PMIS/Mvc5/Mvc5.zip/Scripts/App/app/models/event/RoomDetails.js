define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        RoomDetails = Backbone.Model.extend({
            urlRoot:"Rooms/Details/",
            defaults: {
                status:null
            }

        }),

        RoomDetailsColl = Backbone.Collection.extend({
            model: RoomDetails,
            url:"Rooms/Details/"
        });

    return {
        RoomDetails: RoomDetails,
        RoomDetailsColl: RoomDetailsColl
    };

});