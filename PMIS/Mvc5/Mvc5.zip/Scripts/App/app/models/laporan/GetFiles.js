define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetFiles = Backbone.Model.extend({
            urlRoot:"UploadLaporan/GetFiles/",
            defaults: {
                status:null
            }

        }),

        GetFilesColl = Backbone.Collection.extend({
            model: GetFiles,
            url:"UploadLaporan/GetFiles/"
        });

    return {
        GetFiles: GetFiles,
        GetFilesColl: GetFilesColl
    };

});