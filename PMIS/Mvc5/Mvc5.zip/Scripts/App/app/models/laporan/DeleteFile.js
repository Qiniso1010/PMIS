define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        DeleteFile = Backbone.Model.extend({
            urlRoot:"UploadLaporan/DeleteFile/"

        }),

        DeleteFileColl = Backbone.Collection.extend({
            model: DeleteFile,
            url:"UploadLaporan/DeleteFile/"
        });

    return {
        DeleteFile : DeleteFile,
        DeleteFileColl: DeleteFileColl
    };

});