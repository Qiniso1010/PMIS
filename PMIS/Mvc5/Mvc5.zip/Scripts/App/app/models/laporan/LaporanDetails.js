define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        LaporanDetails = Backbone.Model.extend({
            urlRoot:"LaporanDocs/Details/",
            defaults: {
                status:null
            }

        }),

        LaporanDetailsColl = Backbone.Collection.extend({
            model: LaporanDetails,
            url:"LaporanDocs/Details/"
        });

    return {
        LaporanDetails: LaporanDetails,
        LaporanDetailsColl: LaporanDetailsColl
    };

});