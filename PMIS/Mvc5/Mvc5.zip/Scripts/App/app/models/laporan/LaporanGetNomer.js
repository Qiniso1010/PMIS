define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        LaporanGetNomer = Backbone.Model.extend({
            urlRoot:"LaporanDocs/CheckName/",
            defaults: {
                status:null
            }

        }),

        LaporanGetNomerColl = Backbone.Collection.extend({
            model: LaporanGetNomer,
            url:"LaporanDocs/CheckName/"
        });

    return {
        LaporanGetNomer: LaporanGetNomer,
        LaporanGetNomerColl: LaporanGetNomerColl
    };

});