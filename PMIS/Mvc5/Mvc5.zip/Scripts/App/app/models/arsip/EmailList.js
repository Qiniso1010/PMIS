define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        EmailList = Backbone.Model.extend({
            urlRoot:"Sharing/EmailList/",
            defaults: {
                status:null
            }

        }),

        EmailListColl = Backbone.Collection.extend({
            model: EmailList,
        });

    return {
        EmailList : EmailList,
        EmailListColl: EmailListColl
    };

});