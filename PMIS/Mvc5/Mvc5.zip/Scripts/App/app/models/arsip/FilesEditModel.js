define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        FilesEditModel = Backbone.Model.extend({

            urlRoot:"Files/Edit/",
            initialize:function () {
                this.dat = new FilesEditCollection();
                this.dat.url = this.urlRoot + "/" + this.id;
            },
            defaults: {
                ModuleId: null,
                Name:null
            }

        }),

       FilesEditCollection = Backbone.Collection.extend({

            model: FilesEditModel,
            url: "Files/Edit/",

        });

    return {
        FilesEditModel: FilesEditModel,
        FilesEditCollection: FilesEditCollection
    };

});