define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        NaskahGetNomer = Backbone.Model.extend({
            urlRoot:"LaporanDocs/CheckName/",
            defaults: {
                status:null
            }

        }),

        NaskahGetNomerColl = Backbone.Collection.extend({
            model: NaskahGetNomer,
            url:"LaporanDocs/CheckName/"
        });

    return {
        NaskahGetNomer: NaskahGetNomer,
        NaskahGetNomerColl: NaskahGetNomerColl
    };

});