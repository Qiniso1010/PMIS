define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        GetLogs = Backbone.Model.extend({
            urlRoot:"LaporanDocLogs/",
            defaults: {
                status:null
            }

        }),

        GetLogsColl = Backbone.Collection.extend({
            model: GetLogs,
            url:"LaporanDocLogs/"
        });

    return {
        GetLogs: GetLogs,
        GetLogsColl: GetLogsColl
    };

});