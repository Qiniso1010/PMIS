define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        MasterRekeningEditModel = Backbone.Model.extend({
            urlRoot:"Rekenings/Details/",
            defaults: {
                status:null
            }

        }),

        MasterRekeningEditModelColl = Backbone.Collection.extend({
            model: MasterRekeningEditModel,
        });

    return {
        MasterRekeningEditModel: MasterRekeningEditModel,
        MasterRekeningEditModelColl: MasterRekeningEditModelColl
    };

});