define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        NaskahTemplateEditModel = Backbone.Model.extend({
            urlRoot:"TemplateDocs/Edit/",
            defaults: {
                status:null
            }

        }),

        NaskahTemplateEditModelColl = Backbone.Collection.extend({
            model: NaskahTemplateEditModel,
            url:"TemplateDocs/Edit/"
        });

    return {
        NaskahTemplateEditModel: NaskahTemplateEditModel,
        NaskahTemplateEditModelColl: NaskahTemplateEditModelColl
    };

});