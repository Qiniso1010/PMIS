define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        AddSppdModel = Backbone.Model.extend({
            urlRoot:"Dinas/Details/"

        }),

        AddSppdModelColl = Backbone.Collection.extend({
            model: AddSppdModel
        });

    return {
        AddSppdModel: AddSppdModel,
        AddSppdModelColl: AddSppdModelColl
    };

});