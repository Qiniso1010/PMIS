define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        NaskahDetails = Backbone.Model.extend({
            urlRoot:"LaporanDocs/Details/",
            defaults: {
                status:null
            }

        }),

        NaskahDetailsColl = Backbone.Collection.extend({
            model: NaskahDetails,
            url:"LaporanDocs/Details/"
        });

    return {
        NaskahDetails: NaskahDetails,
        NaskahDetailsColl: NaskahDetailsColl
    };

});