define(function (require) {

    "use strict";

    var $           = require('jquery'),
        Backbone    = require('backbone'),

        DeletePimpinan = Backbone.Model.extend({
            urlRoot:"Dinas/DeletePimpinan/"

        }),

        DeletePimpinanColl = Backbone.Collection.extend({
            model: DeletePimpinan
        });

    return {
        DeletePimpinan: DeletePimpinan,
        DeletePimpinanColl: DeletePimpinanColl
    };

});