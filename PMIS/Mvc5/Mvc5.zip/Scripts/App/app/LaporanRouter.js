define(function(require) {

  "use strict";

  var   Backbone        = require('backbone'),
        Handlerbars     = require('handlebars'),
        Boostrap        = require('bootstrap.min'),
        AdminLTE        = require('dist/js/app'),
        Utility         = require('utility'),
        hbhelper        = require('handlebarshelper'),
        iCheck          = require('icheck'),
        Modernizr       = require('modernizr-2.8.3'),
        swal            = require('sweetalert.min'),

        $content        = $("#content"),
        $default_routes = $('#routes').val(),
        $headerAction   = $("#content-header");
   
    return {
        Init:function(router) {
            
            router.on("route:commentLaporanIndex", function() {
                require(
                [
                    "app/views/laporan/CommentIndex",
                    "app/modules/laporan/commentIndex",
                    "app/views/systems/DashboardAction",
                    "hbtemplate",
                    "jquery"
                ],
                function(Views, Modules, DashboardAction, hb, $) {
                    Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new Views.CommentIndexView().render().el);
                    // load content module
                    Modules.Index();
                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();


                });

            });
    
            router.on("route:laporanIndex", function(params) {
                require(
                [
                    "app/views/laporan/LaporanIndex",
                    "app/modules/laporan/laporanIndex",
                    "app/views/systems/DashboardAction",
                    "hbtemplate",
                    "jquery"
                ],
                function(Views, Modules, DashboardAction, hb, $) {
                    var querystr = Utility.parseQueryString(params);
                    Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new Views.LaporanIndexView().render().el);
                    // load content module
                    Modules.Index();
                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();


                });

            });
    
            router.on("route:laporanAdd", function () {
                require(
                [
                    "app/views/laporan/LaporanAdd",
                    "app/modules/laporan/laporanAdd",
                    "app/views/systems/DashboardAction",
                    "hbtemplate",
                    "jquery"
                ],
                function (views, Modules, DashboardAction, hb, $) {

                    Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.LaporanAdd().render().el);
                    
                    // Load Modules
                    Modules.Index();

                    // define logout
                    Utility.Logout();

                });


            });
            
            router.on("route:laporanSubAdd", function (id,name) {
                require(
                [
                    "app/views/laporan/LaporanSubAdd",
                    "app/modules/laporan/laporanSubAdd",
                    "app/views/systems/DashboardAction",
                    "hbtemplate",
                    "jquery"
                ],
                function (views, Modules, DashboardAction, hb, $) {

                    Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.LaporanAdd().render(id).el);
                    
                    // Load Modules
                    Modules.Index(id,name);

                    // define logout
                    Utility.Logout();

                });


            });
            
            router.on("route:laporanOpen", function (sharedid,id,params) {
                require(
                [
                    "app/views/laporan/LaporanDetails",
                    "app/modules/laporan/laporanDetails",
                    "app/models/laporan/LaporanDetails",
                    "app/views/systems/DashboardAction",
                    "hbtemplate",
                    "jquery"
                ],
                function (views, Modules,models, DashboardAction, hb, $) {
                    var querystr = Utility.parseQueryString(params);
                        // // window.q = queryString;
                        // if(x.foo){
                        //     // foo parameters was passed
                        //     alert('foo=' + x.foo);
                        // }
                    if (querystr.Current != "" || querystr.Current != undefined) {
                            store.set('Current',sharedid);
                    }
                    if (querystr.Type != undefined || querystr.Type != "") {
                        var tipe = querystr.Type;
                    }
                    console.log(querystr);
                    var token = $('input[name="__RequestVerificationToken"]').val();
                    Utility.IsLoading("#loading", "show");
                    // call data from model
                    var fect = new models.LaporanDetails();
                    // loading
                    Utility.IsLoading("#loading", "show");
                    // retrive data
                    fect.fetch({
                        data: $.param({ __RequestVerificationToken: token,id:id,SharedId:sharedid,tipe:tipe }),
                        type: 'POST',
                        dataType: 'json',
                        success: function (data) {
                            $headerAction.html(new DashboardAction().render().el);
                            
                            $content.html(new views.LaporanDetails({
                                model: data
                            }).render().el);

                            // load modules
                            Modules.Index(sharedid,id,querystr);

                        }
                    });
                    

                    // define logout
                    Utility.Logout();

                });


            });
            
            router.on("route:laporanSubIndex", function (id,name) {
                require(
                [
                    "app/views/laporan/LaporanSubIndex",
                    "app/modules/laporan/laporanSubIndex",
                    "app/views/systems/DashboardAction",
                    "hbtemplate",
                    "jquery"
                ],
                function (views, Modules, DashboardAction, hb, $) {

                    Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.LaporanSubIndexView().render().el);

                    // Load Modules
                    Modules.Index(id,name);

                    // define logout
                    Utility.Logout();

                });
            });
    
            router.on("route:categoryLaporanAdd", function () {
                require(
                [
                    "app/views/laporan/CategoryAdd",
                    "app/modules/laporan/categoryAdd",
                    "app/views/systems/DashboardAction",
                    "hbtemplate",
                    "jquery"
                ],
                function (views, Modules, DashboardAction, hb, $) {

                    Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new views.CategoryAdd().render().el);

                    // Load Modules
                    Modules.Index();

                    // define logout
                    Utility.Logout();

                });


            });
    
            router.on("route:categoryLaporanEdit", function (id) {
                require(
                [
                    "app/views/laporan/CategoryEdit",
                    "app/modules/laporan/categoryEdit",
                    "app/models/laporan/CategoryEditModel",
                    "app/views/systems/DashboardAction",
                    "hbtemplate",
                    "jquery"
                ],
                function (views, Modules,models, DashboardAction, hb, $) {

                    Utility.IsLoading("#loading", "show");
                    // call data from model
                    var fect = new models.CategoryEditModel({
                        id: id
                    });
                    // loading
                    Utility.IsLoading("#loading", "show");
                    // retrive data
                    fect.fetch({
                        success: function (data) {
                            $headerAction.html(new DashboardAction().render().el);
                            
                            $content.html(new views.CategoryEdit({
                                model: data
                            }).render().el);

                            // load modules
                            Modules.Index();

                        }
                    });

                    // define logout
                    Utility.Logout();

                });


            });
            
            router.on("route:inboxLaporanIndex", function(params) {
                require(
                [
                    "app/views/laporan/InboxIndex",
                    "app/modules/laporan/inboxIndex",
                    "app/views/systems/DashboardAction",
                    "hbtemplate",
                    "jquery"
                ],
                function(Views, Modules, DashboardAction, hb, $) {
                    var querystr = Utility.parseQueryString(params);
                    Utility.IsLoading("#loading", "show");
                    // header render
                    $headerAction.html(new DashboardAction().render().el);
                    // body render
                    $content.html(new Views.InboxIndexView().render().el);
                    // load content module
                    Modules.Index();
                    Utility.IsLoading("#loading", "hide");

                    // define logout
                    Utility.Logout();


                });

            });
         
        } // End Init
    } // End Return
    
});