define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        typeahead           = require('typeahead.bundle.min'),
        tokenfield          = require('bootstrap-tokenfield'),
        ModalView           = require('backbone-modal'),
        summernote          = require('summernote/summernote'),
        
        ModalNoAttending = Backbone.ModalView.extend({
            title: "<h3>Tidak dapat menghadiri agenda ini?</h3>",
            buttons: [{
                className: "btn-success btn-custom btn-flat ok",
                label: "Send"
            }],
            events: {
                "click .modal-footer a.ok": "onAction",
                "hidden.bs.modal": "onHidden",
            },
            postRender: function() {
                this.onRender();
                // alert(this.id);
                
                this.$('#UserIdx').val(this.id);
                return this;
            },
            onRender: function() {
                var templatex = hb.Tem('Event/_partial/ModalNoAttending');
                this.$body.html(templatex());
                
                this.$("#keterangan").summernote({
                    height: 200
                });
                
                
                return this;
            },
            onAction: function() {
                
                var $Id = $("#UserIdx").val();
                var $Pesan = $("#keterangan").code();
                var token = $('input[name="__RequestVerificationToken"]').val();
                
                Utility.IsLoading("#loading","show");
                Utility.prosesLoad("Y");
                
                var param = {
                    id:$Id,
                    __RequestVerificationToken:token,
                    Keterangan:$Pesan
                };
                
                var $options = {};
                $options.url = "Schedules/NoAttending/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    if (d.Attr == "Ok!") {
                        Utility.IsLoading("#loading","hide");
                        Utility.prosesLoad("N");
                        // Utility.AlertV2("check",d.Message,"success");
                        swal({
                            title: "Notice!",
                            text:d.Message,
                            type: "info",   
                            showCancelButton: false,    
                            confirmButtonText: "OK!",   
                            closeOnConfirm: false
                        },function() {
                            location.reload();
                        });
                        
                        // location.reload();
                    } else {
                        Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        Utility.IsLoading("#loading","hide");
                    }
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
                
                return this;
            },
            onHidden: function(e) {
                console.log("Modal hidden");
            },
        });

    return {
        ModalNoAttending: ModalNoAttending
    };
  

});


