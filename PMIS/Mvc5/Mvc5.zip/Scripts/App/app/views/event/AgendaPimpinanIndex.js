define(function(require) {

  "use strict";

 
    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        easycal             = require('/Scripts/calendar/easycal.js'),
        slimscroll          = require('jquery.slimscroll.min'),
        models              = require('app/models/event/ListPimpinan'),
        NProgress           = require('/Scripts/nprogress.js'),

    AgendaPimpinanIndex = Backbone.View.extend({
      template: hb.Tem('Event/AgendaPimpinanIndex'),
      initialize: function() {
        this.render;
      },
      render: function(param) {
        this.$el.html(this.template());
        
        NProgress.done();
        
        this.InitCalendar('ajax',param.Id);
        
        this.$("#box-profile").slimscroll({
            height: "450px",
            alwaysVisible: false,
            size: "3px"
        }).css("width", "100%");
        
        
        this.RenderPimpinan('');
       
        return this;
      },
      events : {
          "keyup input#search_pimpinan": "search"
      },
      search: function () {
            var src = $('#search_pimpinan');

            this.RenderPimpinan(src.val());
            src.focus();
            return this;
      },
      RenderPimpinan: function (key) {
            var templatex = hb.Tem('Event/_partial/RenderPimpinan');
            var token = $('input[name="__RequestVerificationToken"]').val();

            var list = new models.ListPimpinan();
            NProgress.start();
            list.fetch({
                data: $.param({ __RequestVerificationToken: token,key:key }),
                type: 'GET',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#list-pimpinan').html(templatex(data.attributes));
                }
            });
            
            return this;
      },
      InitCalendar: function(ajax,id) {
          if (ajax) {
              NProgress.start();
              
            //   Utility.IsLoading("#loading","show");
              var d = new Date();
              var yearNumber = (new Date).getFullYear();
              
              var monthNumber = d.getMonth() + 1;
              var param = {
                ProfileId:id,
                Bulan:monthNumber,
                Tahun:yearNumber
              };
              
            $.ajax({
                url: 'Schedules/IndexCalendarPimpinan/',
                type: 'GET',
                data:param
            }).done(function(data) {
                var events = data.events;
                
                NProgress.done();
                // Utility.IsLoading("#loading","hide");
                // loop json & append to dom
                for (var i = 0; i < events.length; i++) {
                    $('.list').append('<div class="day-event" date-day="'+ events[i].day +'" date-month="' + events[i].month +'" date-year="'+ events[i].year +'"  data-title="'+events[i].title+'" data-number="'+ i +'">');
                }

                // start calendar
                var $s = new AgendaPimpinanIndex();
                $s.startCalendar(id);

            }).fail(function(data) {
                Utility.IsLoading("#loading","hide");
                console.log(data);
            });
        } 
        else 
        {
            // if not using ajax start calendar
            this.startCalendar(id);
        }
      },
      GetEvents:function(month,year,id) {
            // Utility.IsLoading("#loading","show");
            
            NProgress.start();
            if (year != '') {
                var param = {
                    Bulan:month,
                    Tahun:year,
                    ProfileId:id
                }; 
            } else {
                var d = new Date();
                var yearNumber = (new Date).getFullYear();
                var param = {
                    Bulan:month,
                    Tahun:yearNumber,
                    ProfileId:id
                };
            }
            
            $.ajax({
                url: 'Schedules/IndexCalendarPimpinan/',
                type: 'GET',
                data:param
            }).done(function(data) {
                NProgress.done();
                
                var events = data.events;
                // Utility.IsLoading("#loading","hide");
                // loop json & append to dom
                for (var i = 0; i < events.length; i++) {
                    $('.list').append('<div class="day-event" date-day="'+ events[i].day +'" date-month="' + events[i].month +'" date-year="'+ events[i].year +'" data-title="'+events[i].title+'" data-number="'+ i +'">');
                }


            }).fail(function(data) {
                console.log(data);
                Utility.IsLoading("#loading","hide");
            });
      },
      startCalendar: function (id) {
            var mon = 'Senin';
            var tue = 'Selasa';
            var wed = 'Rabu';
            var thur = 'Kamis';
            var fri = 'Jumat';
            var sat = 'Sabtu';
            var sund = 'Minggu';
            
            var Id = id;
            // console.log(id);
            /**
             * Get current date
             */
            var d = new Date();
            var strDate = yearNumber + "/" + (d.getMonth() + 1) + "/" + d.getDate();
            var yearNumber = (new Date).getFullYear();
            /**
             * Get current month and set as '.current-month' in title
             */
            var monthNumber = d.getMonth() + 1;

            function GetMonthName(monthNumber) {
                var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                return months[monthNumber - 1];
            }

            setMonth(monthNumber, mon, tue, wed, thur, fri, sat, sund);

            function setMonth(monthNumber, mon, tue, wed, thur, fri, sat, sund) {
                $('.month').text(GetMonthName(monthNumber) + ' ' + yearNumber);
                $('.month').attr('data-month', monthNumber);
                printDateNumber(monthNumber, mon, tue, wed, thur, fri, sat, sund);
            }

            $('.btn-next').on('click', function(e) {
                var monthNumber = $('.month').attr('data-month');
                if (monthNumber > 11) {
                    $('.month').attr('data-month', '0');
                    var monthNumber = $('.month').attr('data-month');
                    yearNumber = yearNumber + 1;
                    setMonth(parseInt(monthNumber) + 1, mon, tue, wed, thur, fri, sat, sund);
                    
                    var next = parseInt(monthNumber) + 1;
                    var $v = new AgendaPimpinanIndex();
                    $v.GetEvents(next,yearNumber,Id);
                } else {
                    setMonth(parseInt(monthNumber) + 1, mon, tue, wed, thur, fri, sat, sund);
                    var next = parseInt(monthNumber) + 1;
                    var $v = new AgendaPimpinanIndex();
                    $v.GetEvents(next,'',Id);
                };
                
               
                
            });

            $('.btn-prev').on('click', function(e) {
                var monthNumber = $('.month').attr('data-month');
                if (monthNumber < 2) {
                    $('.month').attr('data-month', '13');
                    var monthNumber = $('.month').attr('data-month');
                    yearNumber = yearNumber - 1;
                    setMonth(parseInt(monthNumber) - 1, mon, tue, wed, thur, fri, sat, sund);
                    
                    var prev = parseInt(monthNumber) - 1;
                    var $v = new AgendaPimpinanIndex();
                    $v.GetEvents(prev,yearNumber,Id);
                } else {
                    setMonth(parseInt(monthNumber) - 1, mon, tue, wed, thur, fri, sat, sund);
                    var prev = parseInt(monthNumber) - 1;
                    var $v = new AgendaPimpinanIndex();
                    $v.GetEvents(prev,'',Id);
                };
                
               
            });

            /**
             * Get all dates for current month
             */

            function printDateNumber(monthNumber, mon, tue, wed, thur, fri, sat, sund) {

                $($('tbody.event-calendar_view tr')).each(function(index) {
                    $(this).empty();
                });

                $($('thead.event-days tr')).each(function(index) {
                    $(this).empty();
                });

                function getDaysInMonth(month, year) {
                    // Since no month has fewer than 28 days
                    var date = new Date(year, month, 1);
                    var days = [];
                    while (date.getMonth() === month) {
                        days.push(new Date(date));
                        date.setDate(date.getDate() + 1);
                    }
                    return days;
                }

                var i = 0;

                setDaysInOrder(mon, tue, wed, thur, fri, sat, sund);

                function setDaysInOrder(mon, tue, wed, thur, fri, sat, sund) {
                    var monthDay = getDaysInMonth(monthNumber - 1, yearNumber)[0].toString().substring(0, 3);
                    if (monthDay === 'Mon') {
                        $('thead.event-days tr').append('<td>' + mon + '</td><td>' + tue + '</td><td>' + wed + '</td><td>' + thur + '</td><td>' + fri + '</td><td>' + sat + '</td><td>' + sund + '</td>');
                    } else if (monthDay === 'Tue') {
                        $('thead.event-days tr').append('<td>' + tue + '</td><td>' + wed + '</td><td>' + thur + '</td><td>' + fri + '</td><td>' + sat + '</td><td>' + sund + '</td><td>' + mon + '</td>');
                    } else if (monthDay === 'Wed') {
                        $('thead.event-days tr').append('<td>' + wed + '</td><td>' + thur + '</td><td>' + fri + '</td><td>' + sat + '</td><td>' + sund + '</td><td>' + mon + '</td><td>' + tue + '</td>');
                    } else if (monthDay === 'Thu') {
                        $('thead.event-days tr').append('<td>' + thur + '</td><td>' + fri + '</td><td>' + sat + '</td><td>' + sund + '</td><td>' + mon + '</td><td>' + tue + '</td><td>' + wed + '</td>');
                    } else if (monthDay === 'Fri') {
                        $('thead.event-days tr').append('<td>' + fri + '</td><td>' + sat + '</td><td>' + sund + '</td><td>' + mon + '</td><td>' + tue + '</td><td>' + wed + '</td><td>' + thur + '</td>');
                    } else if (monthDay === 'Sat') {
                        $('thead.event-days tr').append('<td>' + sat + '</td><td>' + sund + '</td><td>' + mon + '</td><td>' + tue + '</td><td>' + wed + '</td><td>' + thur + '</td><td>' + fri + '</td>');
                    } else if (monthDay === 'Sun') {
                        $('thead.event-days tr').append('<td>' + sund + '</td><td>' + mon + '</td><td>' + tue + '</td><td>' + wed + '</td><td>' + thur + '</td><td>' + fri + '</td><td>' + sat + '</td>');
                    }
                };
                $(getDaysInMonth(monthNumber - 1, yearNumber)).each(function(index) {
                    var index = index + 1;
                    if (index < 8) {
                        $('tbody.event-calendar_view tr.1').append('<td data-toggle="tooltip" title="Menambahkan Agenda?" data-placement="top" date-month="' + monthNumber + '" date-day="' + index + '" date-year="' + yearNumber + '">' + index + '</td>');
                    } else if (index < 15) {
                        $('tbody.event-calendar_view tr.2').append('<td data-toggle="tooltip" title="Menambahkan Agenda?" data-placement="top" date-month="' + monthNumber + '" date-day="' + index + '" date-year="' + yearNumber + '">' + index + '</td>');
                    } else if (index < 22) {
                        $('tbody.event-calendar_view tr.3').append('<td data-toggle="tooltip" title="Menambahkan Agenda?" data-placement="top" date-month="' + monthNumber + '" date-day="' + index + '" date-year="' + yearNumber + '">' + index + '</td>');
                    } else if (index < 29) {
                        $('tbody.event-calendar_view tr.4').append('<td data-toggle="tooltip" title="Menambahkan Agenda?" data-placement="top" date-month="' + monthNumber + '" date-day="' + index + '" date-year="' + yearNumber + '">' + index + '</td>');
                    } else if (index < 32) {
                        $('tbody.event-calendar_view tr.5').append('<td data-toggle="tooltip" title="Menambahkan Agenda?" data-placement="top" date-month="' + monthNumber + '" date-day="' + index + '" date-year="' + yearNumber + '">' + index + '</td>');
                    }
                    i++;
                });
                var date = new Date();
                var month = date.getMonth() + 1;
                var thisyear = new Date().getFullYear();
                setCurrentDay(month, thisyear);
                setEvent();
                displayEvent();
            }

            /**
             * Get current day and set as '.current-day'
             */
            function setCurrentDay(month, year) {
                var viewMonth = $('.month').attr('data-month');
                var eventYear = $('.event-days').attr('date-year');
                if (parseInt(year) === yearNumber) {
                    if (parseInt(month) === parseInt(viewMonth)) {
                        $('tbody.event-calendar_view td[date-day="' + d.getDate() + '"]').addClass('current-day');
                    }
                }
            };

            /**
             * Add class '.active' on calendar date
             */
            $('tbody td').on('click', function(e) {
                if ($(this).hasClass('event')) {
                    $('tbody.event-calendar_view td').removeClass('active');
                    $(this).addClass('active');
                } else {
                    $('tbody.event-calendar_view td').removeClass('active');
                    $(this).addClass('active');
                };
            });

            /**
             * Add '.event' class to all days that has an event
             */
            function setEvent() {
                
                $('.day-event').each(function(i) {
                    var eventMonth = $(this).attr('date-month');
                    var eventDay = $(this).attr('date-day');
                    var eventYear = $(this).attr('date-year');
                    var eventClass = $(this).attr('event-class');
                    var eventTitle = $(this).attr('data-title');
                   
                    if (eventClass === undefined) eventClass = 'event';
                        else eventClass = 'event ' + eventClass;

                    if (parseInt(eventYear) === yearNumber) {
                        
                        var $id =  $('tbody.event-calendar_view tr td[date-month="' + eventMonth + '"][date-day="' + eventDay + '"]');
                        
                        $id.attr("data-toogle","tooltip");
                        $id.attr("title",eventTitle);
                        $id.attr("data-placement","top");
                        $id.attr("data-html",true);
                        // data-toggle="tooltip" title="Menambahkan Agenda" data-placement="top"
                        $id.addClass(eventClass);
                    }
                });
            };

            /**
             * Get current day on click in calendar
             * and find day-event to display
             */
            function displayEvent() {
                $('tbody.event-calendar_view td').on('click', function(e) {
                    var monthEvent = $(this).attr('date-month');
                    var yearEvent = $(this).attr('date-year');
                    var dayEvent = $(this).text();
                    
                    if (dayEvent.length == 1) {
                        var day = '0'+dayEvent;
                    } else {
                        var day = dayEvent;
                    }
                    
                    if (monthEvent.length == 1) {
                        var month = '0'+monthEvent;
                    } else {
                        var month = monthEvent;
                    }
                    var tanggal = day + '-' + month + '-' + yearEvent;
                    window.location.href = '#/agenda/weekly/'+ id + "/"+ tanggal;
                });
            };

        }

    });

  return {
    AgendaPimpinanIndex: AgendaPimpinanIndex
  }



});
