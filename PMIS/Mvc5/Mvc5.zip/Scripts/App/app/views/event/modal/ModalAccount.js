define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        // autocomplete        = require('jquery-ui'),
        typeahead           = require('typeahead.bundle.min'),
        tokenfield          = require('bootstrap-tokenfield'),
        ModalView           = require('backbone-modal'),
        
        select2             = require('select2/select2'),
        model_account       = require('app/models/event/profile/ListAccount'),
        
        ModalAccount = Backbone.ModalView.extend({
            title: "<h3>Pilih User untuk integrasi dengan Profile ini.</h3>",
            buttons: [{
                className: "btn-success btn-custom btn-flat ok",
                label: "Connect"
            }],
            events: {
                "click .modal-footer a.ok": "onAction",
                "hidden.bs.modal": "onHidden",
                "click #btnMove": "onMove"
            },
            postRender: function() {
                
                this.onRender(this.id);
                return this;
            },
            onRender: function(id) {
                var template = hb.Tem('Event/_modal/ModalAccount');
                this.$body.html(template());
                
                // this.$('#ListAccount').select2();
                
                
                var token = $('input[name="__RequestVerificationToken"]').val();
                var m = new model_account.ListAccount();

                m.fetch({
                    data: $.param({ __RequestVerificationToken: token,ProfileId:id }),
                    type: 'POST',
                    dataType: 'json',
                    cache:true,
                    success: function (data) {
                        $('#ListAccount').html(template(data.attributes));
                    }
                });
                
                return this;
            },
            onAction: function() {
                var $account = $("#ListAccount").val();
                var $Id = $("#id").val();
                
                Utility.IsLoading("#loading","show");
                Utility.prosesLoad("Y");
                
                if ($account != "") {
                    var token = $('input[name="__RequestVerificationToken"]').val();
                    
                    var param = {
                        ProfileId:$Id,
                        __RequestVerificationToken:token,
                        UserId:$account
                    };
                    
                    var $options = {};
                    $options.url = "Profiles/ConnectWithAccount/";
                    $options.type = "POST";
                    $options.cache = false;
                    $options.data = param;
                    $options.dataType = "json";
                    $options.success = function(d) {
                        if (d.Attr == "Ok!") {
                            Utility.IsLoading("#loading","hide");
                            Utility.prosesLoad("N");
                            swal("Ok!",d.Message,"success");
                            // Utility.AlertV2("check",d.Message,"success");
                            // swal({
                            //     title: "Notice!",
                            //     text:d.Message,
                            //     type: "info",   
                            //     showCancelButton: false,    
                            //     confirmButtonText: "OK!",   
                            //     closeOnConfirm: false
                            // },function() {
                            //     // location.reload();
                            // });
                            
                            // location.reload();
                        } else {
                            Utility.AlertV2("exclamation-triangle",d.Message,"error");
                            Utility.IsLoading("#loading","hide");
                        }
                    };
                    $options.error = function(err) {
                        alert(err.responseText);  
                        Utility.IsLoading("#loading","hide");
                    };
                    $.ajax($options);
                    
                } else {
                    swal("Account Selected is empty!");
                    Utility.IsLoading("#loading","hide");
                }
                
                return this;
            },
            onHidden: function(e) {
                console.log("Modal hidden");
            },
        });

    return {
        ModalAccount: ModalAccount
    };
  

});


