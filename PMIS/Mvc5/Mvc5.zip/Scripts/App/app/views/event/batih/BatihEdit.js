define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        inputmask           = require('/Scripts/masking/jquery.inputmask.bundle.js'),
        datepicker          = require('/Scripts/bootstrap-datepicker.js'),
        delete_model        = require('app/models/event/batih/BatihDeleteModel'),
        NProgress           = require('/Scripts/nprogress.js'),

    BatihEdit = Backbone.View.extend({
        template : hb.Tem('event/_batih/BatihAdd'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
            "click #btnDelete": "DeleteData"
        },
        render: function (id,params) {
            this.$el.html(this.template(this.model.attributes));
            NProgress.done();
            
            this.$("#btnSave").attr("disabled",false);
            this.$('#tanggal_lahir').inputmask("9999-99-99");
            
            
            this.$('#tanggal_lahir').datepicker({
                format:'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true
            });
            
            if (params.Id != undefined) {
                var Id = params.Id;
            } else {
                var Id = 0;
            }
            
            this.TableList(Id);
            
            return this;
        },
        DeleteData:function(e) {
            var id = $(e.currentTarget).data('id');
            
            var token = $('input[name="__RequestVerificationToken"]').val();
            var model_delete = new delete_model.BatihDeleteModel();
            
            swal({
                    title: "Yakin ingin menghapus data ini?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#DD6B55",
                    confirmButtonText: "Ok!",
                    closeOnConfirm: true
                },
            function (isConfirm) {
                if (isConfirm) {
                    model_delete.fetch({
                        data:$.param({id:id,__RequestVerificationToken:token}),
                        type:'POST',
                        success:function(data) {
                            if (data.get("Attr") == "Ok!") {
                                swal("Ok!",data.get("Message"),"success");
                                $('#listing-grid').bootstrapTable('refresh');
                            } else {
                                swal("Error!",data.get("Message"),"error");
                            }
                        }
                    });
                }
            });
        },
        TableList:function(id) {
            this.$("#btnDelete").hide();
            
            this.$('#listing-grid').bootstrapTable({
                method: 'GET',
                url: 'Batihs/?ProfileId='+id,
                cache: false,
                striped: false,
                pagination: true,
                sidePagination: "server",
                pageSize: 20,
                pageList: [10, 25, 50, 100, 200],
                search: true,
                showColumns: false,
                showRefresh: true,
                cardView: false,
                showToggle: false,
                showExport: false,
                exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                minimumCountColumns: 2,
                clickToSelect: false,
                columns: [{
                    field: 'Id',
                    title: 'Item ID',
                    align: 'right',
                    valign: 'bottom',
                    sortable: true,
                    visible: false
                }, 
                {
                    field: 'NamaAndId',
                    title: 'Name',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter: 'Name'
                },
                {
                    field: 'Status',
                    title: 'Status',
                    align: 'left',
                    valign: 'middle',
                    sortable: true
                },
                {
                    field: 'TanggalLahir',
                    title: 'Umur',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter:"Umur"
                },
                {
                    field: 'Id',
                    title: '#',
                    align: 'left',
                    valign: 'middle',
                    sortable: true,
                    formatter:"btnDelete"
                }],
                onCheck: function (row) {
                    this.$("#btnDelete").show();
                },
                onUncheck: function (row) {
                    this.$("#btnDelete").hide();
                },
                onCheckAll: function () {
                    this.$("#btnDelete").show();
                },
                onUncheckAll: function () {
                    this.$("#btnDelete").hide();
                },
                onLoadError: function(err) {
                    alert(err);
                }
            });
            
            return this;
        },
        BeforeSend:function() {
            var param = {
                Name:$("#name").val(),
                Status:$('#status').val()
            
            };
            
             if (param.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                $("#name").focus();

                Utility.IsLoading("#loading","hide");
                
                return false;
            } else if (param.Status == "") {
                $("#status-id").removeClass("has-success");
                $("#status-id").addClass("has-error");
                $("#status").focus();

                Utility.IsLoading("#loading","hide");
                
                return false;
            }
            
            return true;
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            
            Utility.prosesLoad("Y");
            var $options = {};
            var token = $('input[name="__RequestVerificationToken"]').val();
            
            if(this.BeforeSend()) {
                 var param = {
                    Nama:$("#name").val(),
                    __RequestVerificationToken: token,
                    Status:$("#status").val(),
                    TanggalLahir:$("#tanggal_lahir").val(),
                    ProfileId:$('#profile_id').val(),
                    BatihId:$('#id').val()
                    
                };
            
                $("#btnSave").attr("disabled",false);
                
                $options.url = "Batihs/Edit/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    if (d.Attr == "Ok!") {
                        Utility.IsLoading("#loading","hide");
                        Utility.prosesLoad("N");
                        // Utility.AlertV2("check",d.Message,"success");
                        swal("Ok!",d.Message,"success");
                        $('#listing-grid').bootstrapTable('refresh');
                    } else {
                        // Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        swal("Error!",d.Message,"error");
                    }
                    $("#name").focus();
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
            }
            
            return this;

        }
      
    });

    return {
        BatihEdit: BatihEdit
    };

   
   

});


