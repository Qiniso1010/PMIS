define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        // autocomplete        = require('jquery-ui'),
        typeahead           = require('typeahead.bundle.min'),
        tokenfield          = require('bootstrap-tokenfield'),
        ModalView           = require('backbone-modal'),
        filex               = require('app/models/naskah/GetFiles'),
        select2             = require('select2/select2'),
        models              = require('app/models/naskah/UnitsList'),
        summernote          = require('summernote/summernote'),
        view                = require('app/views/naskah/NaskahDetails'),
        
        ModalInvite = Backbone.ModalView.extend({
            title: "<h3>Pilih User / Unit</h3>",
            buttons: [{
                className: "btn-success btn-custom btn-flat ok",
                label: "Send"
            }],
            events: {
                "click .modal-footer a.ok": "onAction",
                "hidden.bs.modal": "onHidden",
                "click #btnMove": "onMove"
            },
            postRender: function() {
                this.onRender();
                return this;
            },
            onRender: function() {
                var templatex = hb.Tem('Event/_partial/ModalInvite');
                this.$body.html(templatex());
                this.$('#Unit').select2();
                
                this.$("#keterangan").summernote({
                    height: 200
                });
                
                // render email
                this.RenderEmail();
                
                var token = $('input[name="__RequestVerificationToken"]').val();
                var list = new models.UnitsList();

                list.fetch({
                    data: $.param({ __RequestVerificationToken: token }),
                    type: 'GET',
                    dataType: 'json',
                    cache:true,
                    success: function (data) {
                        $('#Unit').html(templatex(data.attributes));
                    }
                });
                
                return this;
            },
            RenderEmail:function() {
                // Render Email
                
                this.$("#email").tokenfield({
                    autocomplete: {
                        source: function (request, response) {
                            $.getJSON("Sharing/EmailList/?term=" + request.term, function (data) {
                                response($.map(data, function (value, key) {
                                    return {
                                        label: value.Email,
                                        value: key.Email
                                    };
                                }));
                            });
                        },
                        delay: 100
                    },
                    showAutocompleteOnFocus: true
                });  
                
                return this;
            },
            onAction: function() {
                var $unit = $("#Unit").val();
                
                var $Id = $("#id").val();
                var $Pesan = $("#keterangan").code();
                
                var $Email = this.$('#email');
                
                Utility.IsLoading("#loading","show");
                Utility.prosesLoad("Y");
                
                if ($unit != "" || $Email.val() != "") {
                    var token = $('input[name="__RequestVerificationToken"]').val();
                    
                    if ($unit == "" || $unit == null) {
                        var unitx = '';
                    } else {
                        var unitx = $unit.toString();
                    }
                    
                    // alert($Email.val());
                    var param = {
                        id:$Id,
                        __RequestVerificationToken:token,
                        UserId:unitx,
                        Email:$Email.val(),
                        Keterangan:''
                    };
                    
                    var $options = {};
                    $options.url = "Schedules/SendInvitation/";
                    $options.type = "POST";
                    $options.cache = false;
                    $options.data = param;
                    $options.dataType = "json";
                    $options.success = function(d) {
                        if (d.Attr == "Ok!") {
                            Utility.IsLoading("#loading","hide");
                            Utility.prosesLoad("N");
                            // Utility.AlertV2("check",d.Message,"success");
                            swal({
                                title: "Notice!",
                                text:d.Message,
                                type: "info",   
                                showCancelButton: false,    
                                confirmButtonText: "OK!",   
                                closeOnConfirm: false
                            },function() {
                                location.reload();
                            });
                            
                            // location.reload();
                        } else {
                            Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        }
                    };
                    $options.error = function(err) {
                        alert(err.responseText);  
                        Utility.IsLoading("#loading","hide");
                    };
                    $.ajax($options);
                    
                } else {
                    swal("Email or Disposisi is empty!");
                    Utility.IsLoading("#loading","hide");
                }
                
                return this;
            },
            onHidden: function(e) {
                console.log("Modal hidden");
            },
        });

    return {
        ModalInvite: ModalInvite
    };
  

});


