define(function(require) {

  "use strict";


    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        NProgress           = require('/Scripts/nprogress.js'),

    AgendaPimpinanManageIndex = Backbone.View.extend({
        template: hb.Tem('Event/_pimpinan/AgendaPimpinanManageIndex'),
        initialize: function() {
            this.render;
        },
        render: function() {
            this.$el.html(this.template());
        
            NProgress.done();
        
            return this;
        }

    });

    return {
        AgendaPimpinanManageIndex: AgendaPimpinanManageIndex
    }

});
