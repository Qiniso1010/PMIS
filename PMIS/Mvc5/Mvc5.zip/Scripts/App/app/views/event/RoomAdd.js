define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        Models              = require('app/models/event/RoomCheckName'),
        summernote          = require('summernote/summernote'),
        ModSharedId         = require('app/models/event/GetSharedId'),
        NProgress           = require('/Scripts/nprogress.js'),

    RoomAdd = Backbone.View.extend({
        template : hb.Tem('event/RoomAddView'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
            "focusout #name":"CheckName",
            "change #file":"Upload"
        },
        render: function () {
            this.$el.html(this.template());
            
            NProgress.done();
            
            this.$("#btnSave").attr("disabled",true);
            this.$('#edit-img').hide();
            this.SharedId();
            
            return this;
        },
        SharedId:function () {
            var list = new ModSharedId.GetSharedId();
            NProgress.start();
            list.fetch({
                data: $.param({ Id: 'GET' }),
                type: 'GET',
                cache:false,
                success: function (data) {
                    NProgress.done();
                    $('#SharedId').val(data.get("result"));
                }
            });
            
            return this;
        },
        CheckName: function(e) {
            this.name = this.$("#name").val();

            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var CurrentName = new Models.RoomCheckName({ name: this.name, __RequestVerificationToken: token });
            var self = this;
            
            if (this.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                Utility.AlertV2("check","Name is empty!","error");
                $("#name").focus();
                $("#btnSave").attr("disabled", false);
            } else {
                $("#btnSave").attr("disabled",false);
                CurrentName.fetch({
                    data: $.param({name:this.name,__RequestVerificationToken:token}),
                    type:'POST',
                    success: function(data) {
                        NProgress.done();
                        if (data.get("Attr") == "Ok!") {
                            $('#name').val(data.get("Message"));
                        }  
                    }
                
                }); 
            }
            
            return this;       
        }, 
        Upload: function () {
            Utility.prosesLoad("Y");
            var $options = {};
            
            var percent = $('#progress-bar');
            var fileUpload = $('#FormUpload').get(0);
            
            var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
            
            if ($.inArray($("#file").val().split('.').pop().toLowerCase(), fileExtension) == -1) {
                swal("Warning!","Only '.jpeg','.jpg', '.png', '.gif', '.bmp' formats are allowed.","error");
            } else {
                Utility.IsLoading("#loading","show");
                
                if (fileUpload.files != '') {
                    var form = $('#FormUpload')[0];
                    var form_data = new FormData(form);
                    
                    $options.xhr = function() {
                        var xhr = new window.XMLHttpRequest();
                        //Upload progress
                        xhr.upload.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total * 100;
                                percent.html(Math.round(percentComplete) + '%');
                            }
                        }, false);
                        //Download progress
                        xhr.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total * 100;
                                percent.html(Math.round(percentComplete) + '%');
                            }
                        }, false);
                        return xhr;
                    };
                    $options.url = 'UploadEvent/UploadImages/';
                    $options.dataType = 'json';
                    $options.cache = false;
                    $options.contentType = false;
                    $options.processData = false;
                    $options.data = form_data;
                    $options.type = 'POST';
                    $options.success = function(data) {
                        if (data.Attr == "Ok!") {
                            var percentValue = '100%';
                            percent.html(percentValue);
                            
                            $("#profile-pic").html("<img src='"+data.Message+"' class='images-thumb'/>");
                            
                            Utility.IsLoading("#loading", "hide");
                            Utility.prosesLoad("N");
                            
                            // Utility.AlertV2("check", data.Message, "success");
                            
                        } else {
                            Utility.AlertV2("exclamation-triangle", data.Message, "error");
                        }
                    };
                    
                    $options.error = function(xhr, ajaxOptions, thrownError) {
                        console.log(xhr.responseText);
                        alert(xhr.responseText);

                        Utility.IsLoading("#loading", "hide");
                        Utility.prosesLoad("N");
                    };
                    
                    $.ajax($options);
                }
            }
            
            return this;
        },
        BeforeSend:function() {
            var param = {
                Name:$("#name").val()
            
            };
            
             if (param.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                $("#name").focus();

                $("#btnSave").attr("disabled", true);
                Utility.IsLoading("#loading","hide");
                
                return false;
            } else {
                
            }
            
            return true;
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            
            Utility.prosesLoad("Y");
            var $options = {};
            var token = $('input[name="__RequestVerificationToken"]').val();
            
            if(this.BeforeSend()) {
                 var param = {
                    Name:$("#name").val(),
                    __RequestVerificationToken: token,
                    Capacity:$("#capacity").val(),
                    Location:$("#location").val(),
                    Address:$("#address").val(),
                    Coordinate:$("#coordinate").val(),
                    Owner:$("#owner").val(),
                    SharedId:$("#SharedId").val()
                    
                };
            
                $("#btnSave").attr("disabled",false);
                
                $options.url = "Rooms/Create/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                        if (d.Attr == "Ok!") {
                            Utility.IsLoading("#loading","hide");
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check",d.Message,"success");
                            
                            var $v = new RoomAdd();
                            $v.SharedId();
                        } else {
                            Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        }
                        $("#name").focus();
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
            }
            
            return this;

        }
      
    });

    return {
        RoomAdd: RoomAdd
    };

   
   

});


