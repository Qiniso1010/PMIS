define(function(require) {

  "use strict";

 
    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        WeeksView           = require('app/views/event/WeekView'),
        easycal             = require('/Scripts/calendar/easycal.js'),
        slimscroll          = require('jquery.slimscroll.min'),
        models              = require('app/models/event/ListRooms'),
        NProgress           = require('/Scripts/nprogress.js'),

    MeetingRoomIndex = Backbone.View.extend({
      template: hb.Tem('Event/MeetingRoomIndex'),
      initialize: function() {
        this.render;
      },
      render: function(param) {
        this.$el.html(this.template());
        // console.log(param.Id);
        
        NProgress.done();
        
        this.InitCalendar('ajax',param.Id);
        this.RenderRoom();
        
        this.$(".box-body").slimscroll({
            height: "450px",
            alwaysVisible: false,
            size: "3px"
        }).css("width", "100%");
       
        return this;
      },
      RenderRoom: function () {
            var templatex = hb.Tem('Event/_partial/RenderRooms');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var list = new models.ListRooms();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token }),
                type: 'GET',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#list-rooms').html(templatex(data.attributes));
                }
            });
            
            return this;
      },
      InitCalendar: function(ajax,id) {
          if (ajax) {
              NProgress.start();
            //   Utility.IsLoading("#loading","show");
              var d = new Date();
              var yearNumber = (new Date).getFullYear();
              
              var monthNumber = d.getMonth() + 1;
              var param = {
                RoomId:id,
                Bulan:monthNumber,
                Tahun:yearNumber
              };
              
            $.ajax({
                // url: '/Data/events.json',
                url: 'Schedules/IndexCalendar/',
                type: 'GET',
                data:param
            }).done(function(data) {
                var events = data.events;
                NProgress.done();
                // Utility.IsLoading("#loading","hide");
                // loop json & append to dom
                for (var i = 0; i < events.length; i++) {
                    $('.list').append('<div class="day-event" date-day="'+ events[i].day +'" date-month="' + events[i].month +'" date-year="'+ events[i].year +'" data-title="'+events[i].title+'" data-number="'+ i +'"><a href="#" class="close fontawesome-remove"></a><h2 class="title">'+ events[i].title +'</h2><p>'+ events[i].description +'</p><label class="check-btn"><input type="checkbox" class="save" id="save" name="" value=""/><span>Save to personal list!</span></label></div>');
                }

                // start calendar
                var $s = new MeetingRoomIndex();
                $s.startCalendar(id);

            }).fail(function(data) {
                Utility.IsLoading("#loading","hide");
                console.log(data);
            });
        } 
        else 
        {
            // if not using ajax start calendar
            this.startCalendar(id);
        }
      },
      GetEvents:function(month,year,id) {
            // Utility.IsLoading("#loading","show");
            NProgress.start();
            if (year != '') {
                var param = {
                    Bulan:month,
                    Tahun:year,
                    RoomId:id
                }; 
            } else {
                var d = new Date();
                var yearNumber = (new Date).getFullYear();
                var param = {
                    Bulan:month,
                    Tahun:yearNumber,
                    RoomId:id
                };
            }
            
            $.ajax({
                url: 'Schedules/IndexCalendar/',
                type: 'GET',
                data:param
            }).done(function(data) {
                var events = data.events;
                // Utility.IsLoading("#loading","hide");
                NProgress.done();
                // loop json & append to dom
                for (var i = 0; i < events.length; i++) {
                    $('.list').append('<div class="day-event" date-day="'+ events[i].day +'" date-month="' + events[i].month +'" date-year="'+ events[i].year +'" data-title="'+events[i].title+'" data-number="'+ i +'"><a href="#" class="close fontawesome-remove"></a><h2 class="title">'+ events[i].title +'</h2><p>'+ events[i].description +'</p><label class="check-btn"><input type="checkbox" class="save" id="save" name="" value=""/><span>Save to personal list!</span></label></div>');
                }


            }).fail(function(data) {
                console.log(data);
                Utility.IsLoading("#loading","hide");
            });
      },
      startCalendar: function (id) {
            var mon = 'Senin';
            var tue = 'Selasa';
            var wed = 'Rabu';
            var thur = 'Kamis';
            var fri = 'Jumat';
            var sat = 'Sabtu';
            var sund = 'Minggu';
            
            var Id = id;
            // console.log(id);
            /**
             * Get current date
             */
            var d = new Date();
            var strDate = yearNumber + "/" + (d.getMonth() + 1) + "/" + d.getDate();
            var yearNumber = (new Date).getFullYear();
            /**
             * Get current month and set as '.current-month' in title
             */
            var monthNumber = d.getMonth() + 1;

            function GetMonthName(monthNumber) {
                var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                return months[monthNumber - 1];
            }

            setMonth(monthNumber, mon, tue, wed, thur, fri, sat, sund);

            function setMonth(monthNumber, mon, tue, wed, thur, fri, sat, sund) {
                $('.month').text(GetMonthName(monthNumber) + ' ' + yearNumber);
                $('.month').attr('data-month', monthNumber);
                printDateNumber(monthNumber, mon, tue, wed, thur, fri, sat, sund);
            }

            $('.btn-next').on('click', function(e) {
                var monthNumber = $('.month').attr('data-month');
                if (monthNumber > 11) {
                    $('.month').attr('data-month', '0');
                    var monthNumber = $('.month').attr('data-month');
                    yearNumber = yearNumber + 1;
                    setMonth(parseInt(monthNumber) + 1, mon, tue, wed, thur, fri, sat, sund);
                    
                    var next = parseInt(monthNumber) + 1;
                    var $v = new MeetingRoomIndex();
                    $v.GetEvents(next,yearNumber,Id);
                } else {
                    setMonth(parseInt(monthNumber) + 1, mon, tue, wed, thur, fri, sat, sund);
                    var next = parseInt(monthNumber) + 1;
                    var $v = new MeetingRoomIndex();
                    $v.GetEvents(next,'',Id);
                };
                
               
                
            });

            $('.btn-prev').on('click', function(e) {
                var monthNumber = $('.month').attr('data-month');
                if (monthNumber < 2) {
                    $('.month').attr('data-month', '13');
                    var monthNumber = $('.month').attr('data-month');
                    yearNumber = yearNumber - 1;
                    setMonth(parseInt(monthNumber) - 1, mon, tue, wed, thur, fri, sat, sund);
                    
                    var prev = parseInt(monthNumber) - 1;
                    var $v = new MeetingRoomIndex();
                    $v.GetEvents(prev,yearNumber,Id);
                } else {
                    setMonth(parseInt(monthNumber) - 1, mon, tue, wed, thur, fri, sat, sund);
                    var prev = parseInt(monthNumber) - 1;
                    var $v = new MeetingRoomIndex();
                    $v.GetEvents(prev,'',Id);
                };
                
               
            });

            /**
             * Get all dates for current month
             */

            function printDateNumber(monthNumber, mon, tue, wed, thur, fri, sat, sund) {

                $($('tbody.event-calendar_view tr')).each(function(index) {
                    $(this).empty();
                });

                $($('thead.event-days tr')).each(function(index) {
                    $(this).empty();
                });

                function getDaysInMonth(month, year) {
                    // Since no month has fewer than 28 days
                    var date = new Date(year, month, 1);
                    var days = [];
                    while (date.getMonth() === month) {
                        days.push(new Date(date));
                        date.setDate(date.getDate() + 1);
                    }
                    return days;
                }

                var i = 0;

                setDaysInOrder(mon, tue, wed, thur, fri, sat, sund);

                function setDaysInOrder(mon, tue, wed, thur, fri, sat, sund) {
                    var monthDay = getDaysInMonth(monthNumber - 1, yearNumber)[0].toString().substring(0, 3);
                    if (monthDay === 'Mon') {
                        $('thead.event-days tr').append('<td>' + mon + '</td><td>' + tue + '</td><td>' + wed + '</td><td>' + thur + '</td><td>' + fri + '</td><td>' + sat + '</td><td>' + sund + '</td>');
                    } else if (monthDay === 'Tue') {
                        $('thead.event-days tr').append('<td>' + tue + '</td><td>' + wed + '</td><td>' + thur + '</td><td>' + fri + '</td><td>' + sat + '</td><td>' + sund + '</td><td>' + mon + '</td>');
                    } else if (monthDay === 'Wed') {
                        $('thead.event-days tr').append('<td>' + wed + '</td><td>' + thur + '</td><td>' + fri + '</td><td>' + sat + '</td><td>' + sund + '</td><td>' + mon + '</td><td>' + tue + '</td>');
                    } else if (monthDay === 'Thu') {
                        $('thead.event-days tr').append('<td>' + thur + '</td><td>' + fri + '</td><td>' + sat + '</td><td>' + sund + '</td><td>' + mon + '</td><td>' + tue + '</td><td>' + wed + '</td>');
                    } else if (monthDay === 'Fri') {
                        $('thead.event-days tr').append('<td>' + fri + '</td><td>' + sat + '</td><td>' + sund + '</td><td>' + mon + '</td><td>' + tue + '</td><td>' + wed + '</td><td>' + thur + '</td>');
                    } else if (monthDay === 'Sat') {
                        $('thead.event-days tr').append('<td>' + sat + '</td><td>' + sund + '</td><td>' + mon + '</td><td>' + tue + '</td><td>' + wed + '</td><td>' + thur + '</td><td>' + fri + '</td>');
                    } else if (monthDay === 'Sun') {
                        $('thead.event-days tr').append('<td>' + sund + '</td><td>' + mon + '</td><td>' + tue + '</td><td>' + wed + '</td><td>' + thur + '</td><td>' + fri + '</td><td>' + sat + '</td>');
                    }
                };
                $(getDaysInMonth(monthNumber - 1, yearNumber)).each(function(index) {
                    var index = index + 1;
                    if (index < 8) {
                        $('tbody.event-calendar_view tr.1').append('<td  data-toggle="tooltip" title="Klik Selengkapnya / Menambahkan Agenda" data-placement="top"  date-month="' + monthNumber + '" date-day="' + index + '" date-year="' + yearNumber + '">' + index + '</td>');
                    } else if (index < 15) {
                        $('tbody.event-calendar_view tr.2').append('<td  data-toggle="tooltip" title="Klik Selengkapnya / Menambahkan Agenda" data-placement="top"  date-month="' + monthNumber + '" date-day="' + index + '" date-year="' + yearNumber + '">' + index + '</td>');
                    } else if (index < 22) {
                        $('tbody.event-calendar_view tr.3').append('<td  data-toggle="tooltip" title="Klik Selengkapnya / Menambahkan Agenda" data-placement="top"  date-month="' + monthNumber + '" date-day="' + index + '" date-year="' + yearNumber + '">' + index + '</td>');
                    } else if (index < 29) {
                        $('tbody.event-calendar_view tr.4').append('<td  data-toggle="tooltip" title="Klik Selengkapnya / Menambahkan Agenda " data-placement="top"  date-month="' + monthNumber + '" date-day="' + index + '" date-year="' + yearNumber + '">' + index + '</td>');
                    } else if (index < 32) {
                        $('tbody.event-calendar_view tr.5').append('<td  data-toggle="tooltip" title="Klik Selengkapnya / Menambahkan Agenda" data-placement="top"  date-month="' + monthNumber + '" date-day="' + index + '" date-year="' + yearNumber + '">' + index + '</td>');
                    }
                    i++;
                });
                var date = new Date();
                var month = date.getMonth() + 1;
                var thisyear = new Date().getFullYear();
                setCurrentDay(month, thisyear);
                setEvent();
                displayEvent();
            }

            /**
             * Get current day and set as '.current-day'
             */
            function setCurrentDay(month, year) {
                var viewMonth = $('.month').attr('data-month');
                var eventYear = $('.event-days').attr('date-year');
                if (parseInt(year) === yearNumber) {
                    if (parseInt(month) === parseInt(viewMonth)) {
                        $('tbody.event-calendar_view td[date-day="' + d.getDate() + '"]').addClass('current-day');
                    }
                }
            };

            /**
             * Add class '.active' on calendar date
             */
            $('tbody td').on('click', function(e) {
                if ($(this).hasClass('event')) {
                    $('tbody.event-calendar_view td').removeClass('active');
                    $(this).addClass('active');
                } else {
                    $('tbody.event-calendar_view td').removeClass('active');
                    $(this).addClass('active');
                };
            });

            /**
             * Add '.event' class to all days that has an event
             */
            function setEvent() {
                
                $('.day-event').each(function(i) {
                   var eventMonth = $(this).attr('date-month');
                    var eventDay = $(this).attr('date-day');
                    var eventYear = $(this).attr('date-year');
                    var eventClass = $(this).attr('event-class');
                    var eventTitle = $(this).attr('data-title');
                   
                    if (eventClass === undefined) eventClass = 'event';
                        else eventClass = 'event ' + eventClass;

                    if (parseInt(eventYear) === yearNumber) {
                        
                        var $id =  $('tbody.event-calendar_view tr td[date-month="' + eventMonth + '"][date-day="' + eventDay + '"]');
                        
                        $id.attr("data-toogle","tooltip");
                        $id.attr("title",eventTitle);
                        $id.attr("data-placement","top");
                        $id.attr("data-html",true);
                        $id.addClass(eventClass);
                    }
                });
            };

            /**
             * Get current day on click in calendar
             * and find day-event to display
             */
            function displayEvent() {
                $('tbody.event-calendar_view td').on('click', function(e) {
                    //$('.day-event').slideUp('fast');
                    var monthEvent = $(this).attr('date-month');
                    var yearEvent = $(this).attr('date-year');
                    var dayEvent = $(this).text();
                    
                    if (dayEvent.length == 1) {
                        var day = '0'+dayEvent;
                    } else {
                        var day = dayEvent;
                    }
                    
                    if (monthEvent.length == 1) {
                        var month = '0'+monthEvent;
                    } else {
                        var month = monthEvent;
                    }
                    var tanggal = day + '-' + month + '-' + yearEvent;
                    window.location.href = '#/agenda/meeting-room/weekly/index/'+ id + "/"+ tanggal;
                    // // $('.mycal1').slideUp('fast');
                    // var $view = new MeetingRoomIndex();
                    // $view.WeekCal(tanggal);
                    // console.log($view.render());
                    // $('.mycal1').html($view.render().el);
                    // alert(dayEvent);
                    // $('.day-event').focus();
                    // $('.day-event[date-month="' + monthEvent + '"][date-day="' + dayEvent + '"]').slideDown('fast');
                });
            };

            /**
             * Close day-event
             */
            $('.close').on('click', function(e) {
                $(this).parent().slideUp('fast');
            });

            /**
             * Save & Remove to/from personal list
             */
            $('.save').click(function() {
                if (this.checked) {
                    $(this).next().text('Remove from personal list');
                    var eventHtml = $(this).closest('.day-event').html();
                    var eventMonth = $(this).closest('.day-event').attr('date-month');
                    var eventDay = $(this).closest('.day-event').attr('date-day');
                    var eventNumber = $(this).closest('.day-event').attr('data-number');
                    $('.person-list').append('<div class="day" date-month="' + eventMonth + '" date-day="' + eventDay + '" data-number="' + eventNumber + '" style="display:none;">' + eventHtml + '</div>');
                    $('.day[date-month="' + eventMonth + '"][date-day="' + eventDay + '"]').slideDown('fast');
                    $('.day').find('.close').remove();
                    $('.day').find('.save').removeClass('save').addClass('remove');
                    $('.day').find('.remove').next().addClass('hidden-print');
                    remove();
                    sortlist();
                } else {
                    $(this).next().text('Save to personal list');
                    var eventMonth = $(this).closest('.day-event').attr('date-month');
                    var eventDay = $(this).closest('.day-event').attr('date-day');
                    var eventNumber = $(this).closest('.day-event').attr('data-number');
                    $('.day[date-month="' + eventMonth + '"][date-day="' + eventDay + '"][data-number="' + eventNumber + '"]').slideUp('slow');
                    setTimeout(function() {
                        $('.day[date-month="' + eventMonth + '"][date-day="' + eventDay + '"][data-number="' + eventNumber + '"]').remove();
                    }, 1500);
                }
            });

            function remove() {
                $('.remove').click(function() {
                    if (this.checked) {
                        $(this).next().text('Remove from personal list');
                        var eventMonth = $(this).closest('.day').attr('date-month');
                        var eventDay = $(this).closest('.day').attr('date-day');
                        var eventNumber = $(this).closest('.day').attr('data-number');
                        $('.day[date-month="' + eventMonth + '"][date-day="' + eventDay + '"][data-number="' + eventNumber + '"]').slideUp('slow');
                        $('.day-event[date-month="' + eventMonth + '"][date-day="' + eventDay + '"][data-number="' + eventNumber + '"]').find('.save').attr('checked', false);
                        $('.day-event[date-month="' + eventMonth + '"][date-day="' + eventDay + '"][data-number="' + eventNumber + '"]').find('span').text('Save to personal list');
                        setTimeout(function() {
                            $('.day[date-month="' + eventMonth + '"][date-day="' + eventDay + '"][data-number="' + eventNumber + '"]').remove();
                        }, 1500);
                    }
                });
            }

            /**
             * Sort personal list
             */
            function sortlist() {
                var personList = $('.person-list');

                personList.find('.day').sort(function(a, b) {
                    return +a.getAttribute('date-day') - +b.getAttribute('date-day');
                }).appendTo(personList);
            }

            /**
             * Print button
             */
            $('.print-btn').click(function() {
                window.print();
            });
        }

    });

  return {
    MeetingRoomIndex: MeetingRoomIndex
  }



});
