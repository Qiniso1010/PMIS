define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        select2             = require('select2/select2'),
        NProgress           = require('/Scripts/nprogress.js'),

        

    FilesUpload = Backbone.View.extend({
        template : hb.Tem('arsip/FilesUploadView'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
            "change #file":"saveData"
        },
        render: function () {
            this.$el.html(this.template());
            NProgress.done();
            
            this.$("#btnSave").attr("disabled",true);

            return this;
        },
        saveData : function () {
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");

            var token = $('input[name="__RequestVerificationToken"]').val();
            var name = $('#name');

            var percent = $('#progress-bar');
            var fUpload = $('#file');


            var fileUpload = $('#FormUpload').get(0);
            var SharedId = $('#SharedId');

            if (fileUpload.files != '') {

                var form = $('#FormUpload')[0];
                var form_data = new FormData(form);
                //form_data.append("name",name.val());

                //var files = fileUpload.files;
                //var form_data = new FormData();

                //for (var i = 0; i < files.length; i++) {
                //    form_data.append(files[i].name, files[i]);
                //}
                //form_data.append('__RequestVerificationToken', token);
                //form_data.append('sharedId', SharedId.val());
                $.ajax({
                    xhr: function () {
                        var xhr = new window.XMLHttpRequest();
                        //Upload progress
                        xhr.upload.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total * 100;
                                percent.html(Math.round(percentComplete) + '%');
                            }
                        }, false);
                        //Download progress
                        xhr.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total * 100;
                                percent.html(Math.round(percentComplete) + '%');
                            }
                        }, false);
                        return xhr;
                    },
                    url: 'Uploads/UploadFile/',
                    dataType: 'json',
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form_data,
                    type: 'post',
                    success: function (data) {

                        if (data.Attr == "Ok!") {

                            var percentValue = '100%';
                            percent.html(percentValue);

                            Utility.IsLoading("#loading", "hide");
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check", data.Message, "success");
                        } else {
                            Utility.AlertV2("exclamation-triangle", data.Message, "error");
                        }

                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        console.log(xhr.responseText);
                        alert(xhr.responseText);

                        Utility.IsLoading("#loading", "hide");
                        Utility.prosesLoad("N");
                    }
                });
            }

            //e.preventDefault();
            
            return this;

        }
      
    });

    return {
        FilesUpload: FilesUpload
    };

   
   

});


