
define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        // autocomplete        = require('jquery-ui'),
        select2             = require('select2/select2'),
        models              = require('app/models/arsip/UnitsList'),
        modelEmail          = require('app/models/arsip/EmailList'),
        summernote          = require('summernote/summernote'),
        tokenfield          = require('bootstrap-tokenfield'),
        NProgress           = require('/Scripts/nprogress.js'),

        

    FilesSharingView = Backbone.View.extend({
        template : hb.Tem('arsip/FilesSharingView'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave": "saveData",
            "click #btnShareEmail": "SendingEmail"
        },
        render: function (id) {
            this.$el.html(this.template(this.model.attributes));

            this.$('#id').val(id);

            this.$('#Unit').select2();

            // information extended
            this.$("#information").summernote({
                height: 200
            });
            
            // Render Email
            this.$("#email").tokenfield({
                autocomplete: {
                    source: function (request, response) {
                        $.getJSON("Sharing/EmailList/?term=" + request.term, function (data) {
                            response($.map(data, function (value, key) {
                                return {
                                    label: value.Email,
                                    value: key.Email
                                };
                            }));
                        });
                    },
                    delay: 100
                },
                showAutocompleteOnFocus: true
            });

            // render unit
            this.RenderUnit();

            return this;
        },
        RenderUnit: function () {
            var templatex = hb.Tem('Arsip/_partial/UnitListing');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var list = new models.UnitsList();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token }),
                type: 'GET',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#Unit').html(templatex(data.attributes));
                }
            });
            return this;
        },
        saveData: function (event) {
            Utility.IsLoading("#loading", "show");
            Utility.prosesLoad("Y");

            var token = $('input[name="__RequestVerificationToken"]').val();

            var SharedId = $('#SharedId');
            var unit = $('#Unit');
            var id = $('#id');

            //alert(unit.val());

            var un = unit.val();

            var param = {
                __RequestVerificationToken: token,
                SharedId: SharedId.val(),
                UnitId: un.toString(),
                FileId:id.val()

            };

            var options = {};
            options.url = "Sharing/SendToStation/";
            options.type = "POST";
            options.cache = false;
            options.data = param;
            options.dataType = "json";
            options.success = function (d) {
                if (d.Attr == "Ok!") {
                    Utility.IsLoading("#loading", "hide");
                    Utility.prosesLoad("N");
                    Utility.AlertV2("check", d.Message, "success");
                } else {
                    Utility.AlertV2("exclamation-triangle", d.Message, "error");
                }
            };
            options.error = function (xhr, ajaxOptions, thrownError) {
                console.log(xhr.responseText);
                alert(xhr.responseText);
                Utility.prosesLoad("N");
                Utility.IsLoading("#loading", "hide");
            };

            $.ajax(options);

            return this;

        },
        SendingEmail: function (event) {

            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");

            var token = $('input[name="__RequestVerificationToken"]').val();
            var email = $('#email');
            var subject = $('#subject');
            var information = $('#information');
            var filesize = $('#filesize');
            var filename = $('#filename');
            var SharedId = $('#SharedId');
            var UnitName = $('#UnitName');
            var uplby = $('#upldby');
            var path = $('#path');

            var param = {
                email: email.val(),
                __RequestVerificationToken: token,
                subject: subject.val(),
                information: information.code(),
                filesize:filesize.val(),
                filename:filename.val(),
                SharedId:SharedId.val(),
                UnitName:UnitName.val(),
                uplby: uplby.val(),
                path:path.val()

            };

            var options = {};
            options.url = "Sharing/";
            options.type = "POST";
            options.cache = false;
            options.data = param;
            options.dataType = "json";
            options.success = function (d) {
                if (d.Attr == "Ok!") {
                    Utility.IsLoading("#loading", "hide");
                    Utility.prosesLoad("N");
                    Utility.AlertV2("check", d.Message, "success");
                } else {
                    Utility.AlertV2("exclamation-triangle", d.Message, "error");
                }
                $("#name").focus();
            };
            options.error = function (xhr, ajaxOptions, thrownError) {
                console.log(xhr.responseText);
                alert(xhr.responseText);
                Utility.prosesLoad("N");
                Utility.IsLoading("#loading", "hide");
            };
            
            $.ajax(options);

            return this;
        }
      
    });

    return {
        FilesSharingView: FilesSharingView
    };

   
   

});


