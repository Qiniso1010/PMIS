define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        Models              = require('app/models/arsip/FolderCheckName'),
        HandlerHelper       = require('handlebarshelper'),
        select2             = require('select2/select2'),
        NProgress           = require('/Scripts/nprogress.js'),

        

    FilesMoreAdd = Backbone.View.extend({
        template : hb.Tem('arsip/FilesAddView'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
            "focusout #name":"CheckName"
        },
        render: function (id) {
            this.$el.html(this.template());
            NProgress.done();
            
            this.$("#btnSave").attr("disabled", true);

            this.$('#ParentId').val(id);

            return this;
        },
        CheckName : function() {
            this.name = this.$("#name").val();
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var CurrentName = new Models.FolderCheckName({ name: this.name, __RequestVerificationToken: token });
            var self = this;
            
            
            if (this.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                Utility.AlertV2("check","Name is empty!","error");
                $("#name").focus();
                $("#btnSave").attr("disabled", false);
            } else {
                $("#btnSave").attr("disabled",false);
                CurrentName.fetch({
                    data: $.param({name:this.name,__RequestVerificationToken:token}),
                    type:'POST',
                    success: function(data) {
                        NProgress.done();
                        if (data.get("Attr") == "Ok!") {
                            $('#name').val(data.get("Message"));
                        }  
                    }
                
                }); 
            }
            
            return this;  
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            var token = $('input[name="__RequestVerificationToken"]').val();
            var ParentId = $('#ParentId');
                        
            var param = {
                Name:$("#name").val(),
                __RequestVerificationToken: token,
                ParentId:ParentId.val()
            
            };
            
            if (param.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                $("#name").focus();

                $("#btnSave").attr("disabled", true);
                Utility.IsLoading("#loading","hide");
            } else {
                $("#btnSave").attr("disabled",false);
                $.ajax({
                    url:"Files/Create/",
                    type:"POST",
                    cache:false,
                    data:param,
                    dataType:"json",
                    success:function(d) {
                        if (d.Attr == "Ok!") {
                            Utility.IsLoading("#loading","hide");
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check",d.Message,"success");
                        } else {
                            Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        }
                        $("#name").focus();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        console.log(xhr.responseText);
                        alert(xhr.responseText);
                        Utility.prosesLoad("N");
                        Utility.IsLoading("#loading","hide");
                    }
                });
            }
            
            
            
            return this;

        }
      
    });

    return {
        FilesMoreAdd: FilesMoreAdd
    };

   
   

});


