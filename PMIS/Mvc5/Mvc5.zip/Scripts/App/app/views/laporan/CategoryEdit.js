define(function (require) {

    "use strict";

    var $                   = require('jquery'),
        Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        select2             = require('select2/select2'),

        

    CategoryEdit = Backbone.View.extend({
        template : hb.Tem('laporan/CategoryAddView'),
        initialize : function() {
            
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
            "focusout #name":"CheckName"
        },
        render: function () {
            this.$el.html(this.template(this.model.attributes));
            this.$("#btnSave").attr("disabled",false);

            return this;
        },
        CheckName : function() {
            this.name = this.$("#name").val();
            this.token = this.$("#token").val();
            
           
            if (this.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                Utility.AlertV2("check","Name is empty!","error");
                $("#name").focus();
                $("#btnSave").attr("disabled",true);
            } else {
               $("#name-id").removeClass("has-error");
               $("#name-id").addClass("has-success"); 
               $("#btnSave").attr("disabled",false);
            }
            
            return this;  
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");

            var token = $('input[name="__RequestVerificationToken"]').val();
                        
            var param = {
                Name:$("#name").val(),
                __RequestVerificationToken:token,
                CategoryId:$("#id").val()
            
            };
            
            if (param.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                $("#btnSave").attr("disabled",true);
                $("#name").focus();
                Utility.IsLoading("#loading","hide");
            } else {
                $("#btnSave").attr("disabled",false);
                $.ajax({
                    url:"Categories/Edit/",
                    type:"POST",
                    cache:false,
                    data:param,
                    dataType:"json",
                    success:function(d) {
                        if (d.Attr == "Ok!") {
                            Utility.IsLoading("#loading","hide");
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check",d.Message,"success");
                        } else {
                            Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        }
                        $("#name").focus();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        console.log(xhr.responseText);
                        alert(xhr.responseText);
                        Utility.prosesLoad("N");
                        Utility.IsLoading("#loading","hide");
                    }
                });
            }
            
            
            
            return this;

        }
      
    });

    return {
        CategoryEdit: CategoryEdit
    };

   
   

});


