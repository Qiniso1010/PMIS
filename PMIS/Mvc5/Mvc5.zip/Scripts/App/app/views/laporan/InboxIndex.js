define(function(require) {

  "use strict";

  var $ = require('jquery'),
    Handlebars = require('handlebars'),
    _ = require('underscore'),
    Backbone = require('backbone'),
    hb = require('hbtemplate'),
    Utility = require('utility'),


    InboxIndexView = Backbone.View.extend({
      template: hb.Tem('Laporan/InboxIndex'),
      initialize: function() {
        this.render;
      },
      render: function() {
        this.$el.html(this.template());
        return this;
      }

    });

  return {
    InboxIndexView: InboxIndexView
  }



});
