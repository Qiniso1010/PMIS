define(function (require) {

    "use strict";

    var $                   = require('jquery'),
        Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        select2             = require('select2/select2'),
        mod                 = require('app/modules/laporan/getFilesArsip'),
        viewmod             = require('app/views/laporan/ModalRender'),
        filex               = require('app/models/laporan/GetFiles'),
        DelFile             = require('app/models/laporan/DeleteFile'),
        mod_chat            = require('app/models/laporan/ChatModel'),
        
    LaporanDetails = Backbone.View.extend({
        template : hb.Tem('laporan/LaporanDetailsView'),
        initialize : function() {
            
            this.render;
        },
        events: {
            "change #file":"Upload",
            "click #btnRemoveFile":"RemoveFile",
            "click #btnArsilFile":"ArsipFile",
            "click #btnArsip":"OpenedArsip",
            // "keypress #message":"SendChat"
        },
        render: function () {
            this.$el.html(this.template(this.model.attributes));
            
            // define attributes
            // var current_username = $('#CurrentUsername').val();
            // var userid = $('#userid').val();
           
            // var current = $('#current').val();
            // var sharedId = $('#SharedId').val();
            // var $d = new LaporanDetails();
            // $d.RenderChat();
            
            // var RealTime = function () {
            //     $d.RenderChat();
            // }
            // setInterval(RealTime,10000);
            
            return this;
        },
        RenderChat:function () {
            var templatex = hb.Tem('Laporan/_partial/RenderChat');
            var token = $('input[name="__RequestVerificationToken"]').val();
            var laporanId = $('#id').val();
            $('#message').focus();
            var list = new mod_chat.ChatModel();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token,laporanId:laporanId }),
                type: 'POST',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    $('#discussion').html(templatex(data.attributes));
                    var height = 0;
                    var container = $('div'),
                    scrollTo = $('#message-'+data.get("CommentId"));
                    container.each(function(i, value){
                        height += parseInt($(this).height());
                    });
                    height += '';
                    container.animate({
                        scrollTop: height + container.scrollTop()
                    });
                }
            });
            return this;
        },
        SendChat:function(e) {
            if(e.keyCode == 13){
                var token = $('input[name="__RequestVerificationToken"]').val();
                var msg = $('#message').val();
                var laporanId = $('#id').val();
                var param = {
                  laporanId:laporanId,
                  message:msg,
                  __RequestVerificationToken:token
                };
                
                var $options = {};
                $options.url = "Comments/SendMessage/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    if (d.Attr == "Ok!") {
                        Utility.IsLoading("#loading","hide");
                        Utility.prosesLoad("N");
                        console.log(d.Message);
                        var $d = new LaporanDetails();
                        $d.RenderChat();
                        $('#message').val('').focus();
                    } else {
                        Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        console.log(d.Message);
                        $('#message').val('').focus();
                    }
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
             }
             
             return this;
        },
        RenderFiles: function(id) {
            var templatex = hb.Tem('Laporan/_partial/RenderFiles');
            var token = $('input[name="__RequestVerificationToken"]').val();
            
            var list = new filex.GetFiles();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token,SharedId:id }),
                type: 'POST',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    $('#file-list').html(templatex(data.attributes));
                }
            });
            return this;
        },
        OpenModalDisposisi:function() {
            
        //   new viewmoddisposisi.ModalDisposisi().render();
          return this;  
        },
        OpenedArsip:function() {
            new viewmod.Mx().render();
            return this;
        },
        RemoveFile: function(e) {
            e.preventDefault();
            
            $('#progress-bar').hide();
            Utility.IsLoading("#loading","show");
            var m = new DelFile.DeleteFile();
            
            var id = $(e.currentTarget).data("id");
            
            m.save({id:id}, {
                type: 'POST',
                dataType: 'json',
                cache:false,
                success : function(d) {
                     if (d.get("Attr") == "Ok!") {
                        Utility.AlertV2("check", d.get("Message"), "success");
                        
                        var $s = new LaporanDetails();
                        // render file
                        $s.RenderFiles($("#SharedId").val());
                        Utility.IsLoading("#loading","hide");
                    } else {
                        Utility.AlertV2("exclamation-triangle", d.get("Message"), "error");
                        
                        Utility.IsLoading("#loading","hide");
                    }
                },
                error: function(err) {
                    alert(err.responseText);
                    
                    Utility.IsLoading("#loading","hide");
                }
            });
            
            return this;
        },
        Upload: function () {
            this.name = this.$("#nomer").val();
            
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            
            var percent = $('#progress-bar');
            var fileUpload = $('#FormUpload').get(0);

            if (fileUpload.files != '') {
                var form = $('#FormUpload')[0];
                var form_data = new FormData(form);
                $.ajax({
                    xhr: function () {
                        var xhr = new window.XMLHttpRequest();
                        //Upload progress
                        xhr.upload.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total * 100;
                                percent.html(Math.round(percentComplete) + '%');
                            }
                        }, false);
                        //Download progress
                        xhr.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total * 100;
                                percent.html(Math.round(percentComplete) + '%');
                            }
                        }, false);
                        return xhr;
                    },
                    url: 'UploadLaporan/UploadFile/',
                    dataType: 'json',
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form_data,
                    type: 'post',
                    success: function (data) {
                        if (data.Attr == "Ok!") {
                            var percentValue = '100%';
                            percent.html(percentValue);
                            // $("#file-list").append("<li><a href='/Uploads/"+data.Name+"' target='_blank'>" + data.Name + "</a></li>");
                            
                            Utility.IsLoading("#loading", "hide");
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check", data.Message, "success");
                            
                            var $s = new LaporanDetails();
                            $s.RenderFiles($("#SharedId").val());
                        } else {
                            Utility.AlertV2("exclamation-triangle", data.Message, "error");
                        }

                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        console.log(xhr.responseText);
                        alert(xhr.responseText);

                        Utility.IsLoading("#loading", "hide");
                        Utility.prosesLoad("N");
                    }
                });
            }
            return this;
        },
      
    });

    return {
        LaporanDetails: LaporanDetails
    };
});

