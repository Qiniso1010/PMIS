define(function(require) {

  "use strict";

  var $ = require('jquery'),
    Handlebars = require('handlebars'),
    _ = require('underscore'),
    Backbone = require('backbone'),
    hb = require('hbtemplate'),
    Utility = require('utility'),


    LaporanIndexView = Backbone.View.extend({
      template: hb.Tem('Laporan/LaporanIndexView'),
      initialize: function() {
        this.render;
      },
      render: function() {
        this.$el.html(this.template());
        return this;
      }

    });

  return {
    LaporanIndexView: LaporanIndexView
  }



});
