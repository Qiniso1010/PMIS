define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        inputmask           = require('/Scripts/masking/jquery.inputmask.bundle.js'),

    MasterRekeningEdit = Backbone.View.extend({
        template : hb.Tem('naskah/_master/MasterRekeningAdd'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave" : "saveData"
        },
        render: function () {
            this.$el.html(this.template(this.model.attributes));
            this.$("#btnSave").attr("disabled",false);
            
            // Input Mask Nomor Rekening
            this.$('#nomor').inputmask("9.99.9.99.99.99.99.99.9.9.9.99.99");
            
            return this;
        },
        BeforeSend:function() {
            var param = {
                nomor:$("#nomor").val(),
                uraian:$("#uraian").val()
            };
            
            if (param.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                $("#name").focus();
                Utility.IsLoading("#loading","hide");
                return false;
            } else if (param.nomor == "") {
                $("#uraian-id").removeClass("has-success");
                $("#uraian-id").addClass("has-error");
                $("#uraian").focus();
                Utility.IsLoading("#loading","hide");
                return false;
            }
            
            return true;
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            
            var $options = {};
            var token = $('input[name="__RequestVerificationToken"]').val();
            
            
            // Check Form Valid Or Not
            if(this.BeforeSend()) {
                var param = {
                    Nomor:$("#nomor").val(),
                    Uraian:$("#uraian").val(),
                    __RequestVerificationToken: token,
                    RekeningId:$("#id").val()
                
                };
                $("#btnSave").attr("disabled",false);
                
                $options.url = "Rekenings/Edit/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    if (d.Attr == "Ok!") {
                        Utility.IsLoading("#loading","hide");
                        Utility.prosesLoad("N");
                        
                        swal('Ok!',d.Message,"success");
                    } else {
                        swal('Error!',d.Message,"error");
                    }
                    $("#nomor").focus();
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
                    
            } else {
                swal("Oops...", "Kolom Masih ada yang kosong!", "error");
            }
            
            return this;

        }
      
    });

    return {
        MasterRekeningEdit: MasterRekeningEdit
    };
});


