define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        ModalView           = require('backbone-modal'),
        model_profile       = require('app/models/naskah/SPPD/GetProfiles'),
        
        ModalRenderPemimpin = Backbone.ModalView.extend({
            title: "<h3>Data Pegawai</h3>",
            events: {
                "hidden.bs.modal": "onHidden",
                "click #btnInsert":"InsertToNaskah"
                
            },
            RenderProfiles: function(id) {
                var templatex = hb.Tem('Naskah/_sppd/_partial/ModalRenderPemimpin');
                var token = $('input[name="__RequestVerificationToken"]').val();
                
                var sharedid = $('#SharedId').val();
                
                var list = new model_profile.GetProfiles();

                list.fetch({
                    data: $.param({ __RequestVerificationToken: token,Tipe:'pimpinan',SharedId:sharedid }),
                    type: 'GET',
                    dataType: 'json',
                    cache:true,
                    success: function (data) {
                        $('#profile-list').html(templatex(data.attributes));
                    }
                });
                return this;
            },
            InsertToNaskah: function(e) {
                e.preventDefault();
                var id = $(e.currentTarget).data("id");
                
                var SharedId = $('#SharedId');
                var Nomor = $('#nomor');
                var token = $('input[name="__RequestVerificationToken"]').val();
                 
                var param = {
                  ProfileId:id,
                  __RequestVerificationToken:token,
                  SharedId:SharedId.val(),
                  Kode:Nomor.val(),
                  Tipe:'pimpinan',
                  tipe_doc:'spt'
                };
                
                var $options = {};
                $options.url = "Dinas/InsertToDinas/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    if (d.Attr == "Ok!") {
                        Utility.IsLoading("#loading","hide");
                        Utility.prosesLoad("N");
                        Utility.AlertV2("check",d.Message,"success");
                        // swal('Ok!',d.Message,"success");
                        
                        var $s = new ModalRenderPemimpin();
                        $s.RenderProfiles(SharedId.val());
                        
                    } else {
                        Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        //  swal('Error!',d.Message,"error");
                    }
                    $("#nomer").focus();
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
                
               
                
                return this;
            },
            postRender: function() {
                var templatex = hb.Tem('Naskah/_sppd/_partial/RenderProfileIndex');
                
                this.$body.html(templatex());
                
                this.$('#listing-grid').bootstrapTable({
                    method: 'GET',
                    url: 'Profiles/',
                    cache: false,
                    striped: false,
                    pagination: true,
                    sidePagination: "server",
                    pageSize: 20,
                    pageList: [10, 25, 50, 100, 200],
                    search: true,
                    showColumns: false,
                    showRefresh: true,
                    cardView: false,
                    showToggle: false,
                    showExport: false,
                    exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                    minimumCountColumns: 2,
                    clickToSelect: false,
                    columns: [
                    {
                        field: 'Id',
                        title: 'Item ID',
                        align: 'right',
                        valign: 'bottom',
                        sortable: true,
                        visible: false
                    }, {
                        field: 'NameAndId',
                        title: 'Name',
                        align: 'left',
                        valign: 'middle',
                        sortable: true,
                        formatter: 'Name'
                    }, 
                    {
                        field: 'Pangkat',
                        title: 'Pangkat dan Golongan',
                        align: 'right',
                        valign: 'middle',
                        sortable: true
                    }]
                });
                return this;
            },
            onHidden: function(e) {
                console.log("Modal hidden");
            }
        });

    return {
        ModalRenderPemimpin: ModalRenderPemimpin
    };
  

});


