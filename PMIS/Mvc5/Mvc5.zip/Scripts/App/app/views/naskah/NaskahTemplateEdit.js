define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        summernote          = require('summernote/summernote'),
        typeahead           = require('typeahead.bundle.min'),
        tokenfield          = require('bootstrap-tokenfield'),
        select2             = require('select2/select2'),
        bootstrapTable      = require('bootstrap-table/dist/bootstrap-table.min'),
        datepicker          = require('/Scripts/bootstrap-datepicker.js'),
        model               = require('app/models/naskah/GetSharedId'),
        filex               = require('app/models/naskah/GetFiles'),
        NProgress           = require('/Scripts/nprogress.js'),

        

    NaskahTemplateEdit = Backbone.View.extend({
        template : hb.Tem('naskah/NaskahTemplateAddView'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
            "change #file":"Upload"
        },
        render: function () {
            this.$el.html(this.template(this.model.attributes));
            
            // keterangan extended
            this.$("#templateContent").summernote({
                height: 500
            });
            
            var $SharedId = this.$('#SharedId').val();
            this.RenderFiles($SharedId);
            
            
            return this;
        },
        SharedId:function () {
            NProgress.start();
            var list = new model.GetSharedId();

            list.fetch({
                data: $.param({ Id: 'GET' }),
                type: 'GET',
                cache:false,
                success: function (data) {
                    NProgress.done();
                    $('#SharedId').val(data.get("result"));
                    var $s = new NaskahAdd()
                    $s.RenderFiles(data.get("result"));
                }
            });
            
            return this;
        },
        RenderFiles: function(id) {
            var templatex = hb.Tem('Naskah/_partial/RenderImages');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var list = new filex.GetFiles();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token,SharedId:id }),
                type: 'POST',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#img-list').html(templatex(data.attributes));
                }
            });
            return this;
        },
       Upload: function () {
            this.name = this.$("#name").val();
            
            Utility.prosesLoad("Y");
            
            if (this.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                swal("Warning!","Name is empty!","error");
                $("#name").focus();
                Utility.IsLoading("#loading","hide");
                false;
            } else {
                var percent = $('#progress-bar');
                var fileUpload = $('#FormUpload').get(0);
                
                var fileExtension = ['jpeg', 'jpg', 'png', 'gif', 'bmp'];
                
                if ($.inArray($("#file").val().split('.').pop().toLowerCase(), fileExtension) == -1) {
                    swal("Warning!","Only '.jpeg','.jpg', '.png', '.gif', '.bmp' formats are allowed.","error");
                } else {
                    Utility.IsLoading("#loading","show");
                    
                    if (fileUpload.files != '') {

                        var form = $('#FormUpload')[0];
                        var form_data = new FormData(form);
                        
                        $.ajax({
                            xhr: function () {
                                var xhr = new window.XMLHttpRequest();
                                //Upload progress
                                xhr.upload.addEventListener("progress", function (evt) {
                                    if (evt.lengthComputable) {
                                        var percentComplete = evt.loaded / evt.total * 100;
                                        percent.html(Math.round(percentComplete) + '%');
                                    }
                                }, false);
                                //Download progress
                                xhr.addEventListener("progress", function (evt) {
                                    if (evt.lengthComputable) {
                                        var percentComplete = evt.loaded / evt.total * 100;
                                        percent.html(Math.round(percentComplete) + '%');
                                    }
                                }, false);
                                return xhr;
                            },
                            url: 'UploadLaporan/UploadImages/',
                            dataType: 'json',
                            cache: false,
                            contentType: false,
                            processData: false,
                            data: form_data,
                            type: 'POST',
                            success: function (data) {

                                if (data.Attr == "Ok!") {
                                    var percentValue = '100%';
                                    percent.html(percentValue);
                                    $("#img-list").html("<img class='images-header' src='/Uploads/"+data.Name+"'>");
                                    
                                    Utility.IsLoading("#loading", "hide");
                                    Utility.prosesLoad("N");
                                    Utility.AlertV2("check", data.Message, "success");
                                    
                                    var $s = new NaskahTemplateAdd();
                                    $s.RenderFiles($("#SharedId").val());
                                } else {
                                    Utility.AlertV2("exclamation-triangle", data.Message, "error");
                                }

                            },
                            error: function (xhr, ajaxOptions, thrownError) {
                                console.log(xhr.responseText);
                                alert(xhr.responseText);

                                Utility.IsLoading("#loading", "hide");
                                Utility.prosesLoad("N");
                            }
                        });
                    }
                }

                
            }
            
            return this;
        },
        BeforeSend:function() {
            var param = {
                name:$("#name").val()
            };
            
            if (param.name == "") {
                $("#name-id").removeClass("has-success");
                $("#name-id").addClass("has-error");
                $("#name").focus();
                Utility.IsLoading("#loading","hide");
                return false;
            } 
            
            return true;
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            
            var $options = {};
            var token = $('input[name="__RequestVerificationToken"]').val();
            
            // Check Form Valid Or Not
            if(this.BeforeSend()) {
                var param = {
                    Name:$("#name").val(),
                    Content:$("#templateContent").code(),
                    __RequestVerificationToken: token,
                    SharedId:$('#SharedId').val(),
                    TemplateDocId:$('#id').val()
                
                };
                $("#btnSave").attr("disabled",false);
                
                $options.url = "TemplateDocs/Edit/";
                $options.type = "POST";
                $options.cache = false;
                $options.data = param;
                $options.dataType = "json";
                $options.success = function(d) {
                    if (d.Attr == "Ok!") {
                        Utility.IsLoading("#loading","hide");
                        Utility.prosesLoad("N");
                        Utility.AlertV2("check",d.Message,"success");
                        
                        this.s.CheckName();
                    } else {
                        Utility.AlertV2("exclamation-triangle",d.Message,"error");
                    }
                    $("#name").focus();
                };
                $options.error = function(err) {
                    alert(err.responseText);  
                    Utility.prosesLoad("N");
                    Utility.IsLoading("#loading","hide");
                };
                $.ajax($options);
                    
            } else {
                swal("Oops...", "Kolom Masih ada yang kosong!", "error");
            }
            
            return this;

        }
      
    });

    return {
        NaskahTemplateEdit: NaskahTemplateEdit
    };
});


