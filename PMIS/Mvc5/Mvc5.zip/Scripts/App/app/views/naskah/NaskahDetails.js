define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        select2             = require('select2/select2'),
        mod                 = require('app/modules/naskah/getFilesArsip'),
        viewmod             = require('app/views/naskah/ModalRender'),
        filex               = require('app/models/naskah/GetFiles'),
        DelFile             = require('app/models/naskah/DeleteFile'),
        mod_chat            = require('app/models/naskah/ChatModel'),
        mod_update          = require('app/views/naskah/ModalUpdatedLogDetail'),
        log_model           = require('app/models/naskah/GetLogs'),
        ModalLogs           = require('app/views/naskah/ModalUpdatedLogsDetailView'),
        ModalPrint          = require('app/views/naskah/ModalPrintView'),
        moment              = require('moment'),
        NProgress           = require('/Scripts/nprogress.js'),
        
        
    NaskahDetails = Backbone.View.extend({
        template : hb.Tem('naskah/NaskahDetailsView'),
        initialize : function() {
            this.render;
        },
        events: {
            "change #file":"Upload",
            "click #btnRemoveFile":"RemoveFile",
            "click #btnArsilFile":"ArsipFile",
            "click #btnArsip":"OpenedArsip",
            "click #btnTambahDraft":"OpenModalUpdate",
            "click #btnOpenChange":"OpenModalLogs",
            "click #btnPrint":"ShowToPrint",
            "click #btnAgenda":"ViewAgenda"
        },
        render: function () {
            this.$el.html(this.template(this.model.attributes));
            
            // var RealTime = function () {
            //     $d.RenderChat();
            // }
            // setInterval(RealTime,10000);
            var $id = this.$('#id').val();
            this.RenderLogs($id);
            return this;
        },
        ViewAgenda: function(e) {
            var roomId = $(e.currentTarget).data('room');
            var tanggal = $(e.currentTarget).data('tanggal');
            var tgl = moment(tanggal).format('DD-MM-YYYY');
            var sharedId = $('#SharedId').val();
            
            window.location.href = "#/agenda/meeting-room/weekly/index/"+roomId+"/"+tgl;
        },
        ShowToPrint: function(e) {
            var $id = $(e.currentTarget).data("id");
            
            new ModalPrint.ModalPrintView({id:$id}).render();
        },
        OpenModalUpdate:function(e){
          var $id = $(e.currentTarget).data("id");
          
          new mod_update.ModalUpdatedLogDetail({id:$id}).render();  
        },
        OpenModalLogs: function(e) {
          var $id = $(e.currentTarget).data("id");
        //    console.log($id)
          new ModalLogs.ModalUpdatedLogsDetailView({id:$id}).render();
        },
        RenderLogs: function(id) {
            
            var templatex = hb.Tem('Naskah/_partial/RenderDocLogsDetail');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var list = new log_model.GetLogs();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token,LaporanDocId:id ,tipe : 'SENDING'}),
                type: 'POST',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#log-lists').html(templatex(data.attributes));
                }
            });
            return this;
        },
        RenderFiles: function(id) {
            var templatex = hb.Tem('Naskah/_partial/RenderFiles');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var list = new filex.GetFiles();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token,SharedId:id }),
                type: 'POST',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#file-list').html(templatex(data.attributes));
                }
            });
            return this;
        },
        OpenedArsip:function() {
            new viewmod.Mx().render();
            return this;
        },
        RemoveFile: function(e) {
            e.preventDefault();
            NProgress.start();
            $('#progress-bar').hide();
            Utility.IsLoading("#loading","show");
            var m = new DelFile.DeleteFile();
            
            var id = $(e.currentTarget).data("id");
            
            m.save({id:id}, {
                type: 'POST',
                dataType: 'json',
                cache:false,
                success : function(d) {
                    NProgress.done();
                    if (d.get("Attr") == "Ok!") {
                        Utility.AlertV2("check", d.get("Message"), "success");
                        
                        var $s = new NaskahDetails();
                        // render file
                        $s.RenderFiles($("#SharedId").val());
                        Utility.IsLoading("#loading","hide");
                    } else {
                        Utility.AlertV2("exclamation-triangle", d.get("Message"), "error");
                        
                        Utility.IsLoading("#loading","hide");
                    }
                },
                error: function(err) {
                    alert(err.responseText);
                    
                    Utility.IsLoading("#loading","hide");
                }
            });
            
            return this;
        },
        Upload: function () {
            this.name = this.$("#nomer").val();
            
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            
            var percent = $('#progress-bar');
            var fileUpload = $('#FormUpload').get(0);

            if (fileUpload.files != '') {
                var form = $('#FormUpload')[0];
                var form_data = new FormData(form);
                $.ajax({
                    xhr: function () {
                        var xhr = new window.XMLHttpRequest();
                        //Upload progress
                        xhr.upload.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total * 100;
                                percent.html(Math.round(percentComplete) + '%');
                            }
                        }, false);
                        //Download progress
                        xhr.addEventListener("progress", function (evt) {
                            if (evt.lengthComputable) {
                                var percentComplete = evt.loaded / evt.total * 100;
                                percent.html(Math.round(percentComplete) + '%');
                            }
                        }, false);
                        return xhr;
                    },
                    url: 'UploadLaporan/UploadFile/',
                    dataType: 'json',
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form_data,
                    type: 'post',
                    success: function (data) {
                        if (data.Attr == "Ok!") {
                            var percentValue = '100%';
                            percent.html(percentValue);
                            // $("#file-list").append("<li><a href='/Uploads/"+data.Name+"' target='_blank'>" + data.Name + "</a></li>");
                            
                            Utility.IsLoading("#loading", "hide");
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check", data.Message, "success");
                            
                            var $s = new NaskahDetails();
                            $s.RenderFiles($("#SharedId").val());
                        } else {
                            Utility.AlertV2("exclamation-triangle", data.Message, "error");
                        }

                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        console.log(xhr.responseText);
                        alert(xhr.responseText);

                        Utility.IsLoading("#loading", "hide");
                        Utility.prosesLoad("N");
                    }
                });
            }
            return this;
        },
      
    });

    return {
        NaskahDetails: NaskahDetails
    };
});

