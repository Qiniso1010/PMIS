define(function (require) {

    "use strict";

    var $                   = require('jquery'),
        Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        inputmask           = require('/Scripts/masking/jquery.inputmask.bundle.js'),
        summernote          = require('summernote/summernote'),
        typeahead           = require('typeahead.bundle.min'),
        tokenfield          = require('bootstrap-tokenfield'),
        select2             = require('select2/select2'),
        datepicker          = require('/Scripts/bootstrap-datepicker.js'),
         
        model_sharedid      = require('app/models/naskah/GetSharedId'),
        model_getfiles      = require('app/models/naskah/GetFiles'),
        model_deletefiles   = require('app/models/naskah/DeleteFile'),
        model_profilelist   = require('app/models/naskah/sppd/GetProfiles'),
        model_checknomor    = require('app/models/naskah/sppd/CheckNomor'),
        model_deletepimpinan= require('app/models/naskah/sppd/DeletePimpinan'),
        model_profile       = require('app/models/naskah/SPPD/GetProfiles'),
        model_inserttanggal = require('app/models/naskah/SPPD/InsertTanggalToDinas'),
        model_rendertanggal = require('app/models/naskah/SPPD/RenderTanggal'),
        model_deletetanggal = require('app/models/naskah/SPPD/DeleteTanggal'),
        model_renderusers   = require('app/models/naskah/SPPD/RenderUsers'),
        model_batih         = require('app/models/naskah/SPPD/GetBatih'),
        model_deletebatih   = require('app/models/naskah/SPPD/DeleteBatih'),
        model_pegawai_batih = require('app/models/naskah/SPPD/RenderPegawaiAndBatih'),
        
        modal_filesarsip    = require('app/modules/naskah/getFilesArsip'),
        modal_files         = require('app/views/naskah/ModalRender'),
        
        modal_batih         = require('app/views/naskah/SPPD/modal/ModalRenderBatihSppd'),
        modal_pegawai       = require('app/views/naskah/SPPD/modal/ModalRenderPegawaiSppd'),
        // AutoComplete        = require('/Scripts/autocomplete.js'),
        NProgress           = require('/Scripts/nprogress.js'),
       
        
        

    AddSppd = Backbone.View.extend({
        template : hb.Tem('naskah/_sppd/AddSppd'),
        initialize : function() {
            this.render;
        },
        events: {
            "click #btnSave" : "saveData",
            "focusout #nomor":"CheckName",
            "change #file":"Upload",
            "click #btnRemoveFile":"RemoveFile",
            "click #btnArsilFile":"ArsipFile",
            "click #btnArsip":"OpenArsipModal",
            
            "click #btnOpenPegawai":"OpenPegawai",
            
            "click #btnDeletePegawai":"DeletePegawai",
            "click #btnDeleteTanggal":"DeleteTanggal",
            "click #btnDeleteBatih":"DeleteBatih",
            "click #btnOpenPengikutSppd":"OpenPengikutSppd"
            
        },
        render: function (sharedid,id,params) {
            this.$el.html(this.template(this.model.attributes));
            // $.noConflict(); 
            // var datepicker = $.fn.datepicker.noConflict();
            // $.fn.bootstrapDP = datepicker;  
            // this.$("#tanggal").bootstrapDP();
            // console.log(sharedid);
            this.$('#SharedId').val(sharedid);
            this.$('#SptId').val(id);
            
            // auto complete
            this.$('#rekening').autocomplete({
                source: function (request, response) {
                    $.ajax({
                        url: '/Rekenings/RekeningList',
                        data: "{ 'q': '" + request.term + "'}",
                        dataType: "json",
                        type: "GET",
                        contentType: "application/json; charset=utf-8",
                        success: function (data) {
                            response($.map(data, function (item) {
                                return {
                                    label: item.Nomor,
                                    val: item.Nomor,
                                    uraian: item.Uraian
                                }
                            }))
                        },
                        error: function (response) {
                            alert(response.responseText);
                        },
                        failure: function (response) {
                            alert(response.responseText);
                        }
                    });
                },
                select: function (e, i) {
                    // alert(i.item.uraian);
                    $("#rekening-uraian").html("<br/>(" + i.item.uraian + ")");
                    $('#rekening').val(i.item.val);
                    return false;
                },
                search: function () { $(this).addClass('loading'); },
                open: function () { $(this).removeClass('loading'); },
                minLength: 1
            });
            
            // --------------------- spt ------------------ //
            this.$("#btnSave").attr("disabled",false);
            this.$('#UserId').select2();
            
            this.$('#rekening').inputmask("9.99.9.99.99.99.99.99.9.9.9.99.99");
            this.$('#tanggal').inputmask("9999-99-99");
            this.$('#nomor').inputmask("99999.99/9999/AAAA-99999");
            
            // console.log(AutoComplete());
            
            
            if ($.fn.datepicker) { 
               this.$('#tanggal').datepicker({
                    format:'yyyy-mm-dd',
                    autoclose: false,
                    todayHighlight: true
                }).on('changeDate', function (ev) {
                    var tanggal = $('#tanggal').val();
                    var $s = new AddSpt();
                    $s.InsertTanggalToDinas(tanggal);
                });  
            }
            
            // keterangan extended
            this.$("#keterangan").summernote({
                height: 300
            });
            
            // render unit
            this.RenderUsers();
            // this.RenderTanggal();
            
            // render profile
            // this.RenderProfiles('pimpinan');
            // this.RenderProfiles('pegawai');
            
            // render files
            // this.RenderFiles(sharedid);
            
            // get shared id
            // this.SharedId('SPPD');
            // -----------------------
            
            this.RenderPegawaiAndBatih(sharedid);
            
            return this;
        },
        RenderPegawaiAndBatih: function(sharedid) {
            var templatex = hb.Tem('Naskah/_sppd/_partial/RenderPegawaiAndBatih');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            
            var m = new model_pegawai_batih.RenderPegawaiAndBatih();

            m.fetch({
                data: $.param({ __RequestVerificationToken: token,SharedId:sharedid }),
                type: 'POST',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#pegawai-list').html(templatex(data.attributes)); 
                    
                }
            });
            return this;
        },
        RenderUsers: function () {
            var templatex = hb.Tem('Naskah/_sppd/_partial/RenderUsers');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var list = new model_renderusers.RenderUsers();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token }),
                type: 'GET',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#UserId').html(templatex(data.attributes));
                }
            });
            return this;
        },
        InsertTanggalToDinas(tanggal) {
            var m = new model_inserttanggal.InsertTanggalToDinas();  
            NProgress.start();
            var token = $('input[name="__RequestVerificationToken"]').val();
            var sharedid = $('#SharedId').val();

            m.fetch({
                type: 'POST',
                dataType: 'json',
                cache:false, 
                data:$.param({Tanggal:tanggal,SharedId:sharedid,__RequestVerificationToken:token}),
                success : function(d) {
                    NProgress.done();
                    if (d.get("Attr") == "Ok!") {
                        Utility.AlertV2("check", d.get("Message"), "success");
                        
                        var $s = new AddSppd();
                        // render file
                        $s.RenderTanggal();
                        Utility.IsLoading("#loading","hide");
                        
                    } else {
                        Utility.AlertV2("exclamation-triangle", d.get("Message"), "error");
                        Utility.IsLoading("#loading","hide");
                    }
                },
                error: function(err) {
                    alert(err.responseText);
                    Utility.IsLoading("#loading","hide");
                }
            });

            return this;
        },
        RenderTanggal: function() {
            var templatex = hb.Tem('Naskah/_sppd/_partial/RenderTanggal');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var sharedidx = this.$('#SharedId').val();
            
            // console.log(sharedidx);
            
            var list = new model_rendertanggal.RenderTanggal();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token,SharedId:sharedidx }),
                type: 'GET',
                dataType: 'json',
                cache:true,
                success: function (data) {
                     NProgress.done();
                     $('#render-tanggal').html(templatex(data.attributes)); 
                    
                }
            });
            return this;
        },
        RenderProfiles: function(tipe) {
            NProgress.start();
            if (tipe == 'pegawai') {
                var templatex = hb.Tem('Naskah/_sppd/_partial/ModalRenderPegawai');
            } else {
                var templatex = hb.Tem('Naskah/_sppd/_partial/ModalRenderPemimpin');
            }
            var token = $('input[name="__RequestVerificationToken"]').val();
            
            var sharedid = $('#SharedId').val();
            
            var list = new model_profile.GetProfiles();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token,Tipe:tipe,SharedId:sharedid }),
                type: 'GET',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    if (tipe == 'pimpinan') {
                        $('#profile-list').html(templatex(data.attributes)); 
                    } else {
                        $('#pegawai-list').html(templatex(data.attributes));
                    }
                    
                }
            });
            return this;
        },
        RenderBatih: function(id) {
            NProgress.start();
            var templatex = hb.Tem('Naskah/_sppd/_partial/ModalRenderBatihSppd');
            
            var token = $('input[name="__RequestVerificationToken"]').val();
            
            var sharedid = $('#SharedId').val();
            
            var m = new model_batih.GetBatih();

            m.fetch({
                data: $.param({ __RequestVerificationToken: token,ProfileId:id,SharedId:sharedid }),
                type: 'GET',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#batih-list').html(templatex(data.attributes)); 
                    
                }
            });
            return this;
        },
        DeleteTanggal:function(e) {
          var m = new model_deletetanggal.DeleteTanggal();
          NProgress.start();
          var id = $(e.currentTarget).data('id');
          var token = $('input[name="__RequestVerificationToken"]').val();
          
          m.fetch({
              type: 'POST',
              dataType: 'json',
              cache:false, 
              data:$.param({id:id,__RequestVerificationToken:token}),
              success : function(d) {
                    NProgress.done();
                    if (d.get("Attr") == "Ok!") {
                        Utility.AlertV2("check", d.get("Message"), "success");
                        
                        var $s = new AddSppd();
                        // render file
                        $s.RenderTanggal();
                        Utility.IsLoading("#loading","hide");
                        
                    } else {
                        Utility.AlertV2("exclamation-triangle", d.get("Message"), "error");
                        Utility.IsLoading("#loading","hide");
                    }
                },
                error: function(err) {
                    alert(err.responseText);
                    Utility.IsLoading("#loading","hide");
                }
          });
          
          return this;
        },
        DeletePegawai:function(e) {
          var m = new model_deletepimpinan.DeletePimpinan();  
          var id = $(e.currentTarget).data('id');
          var token = $('input[name="__RequestVerificationToken"]').val();
          NProgress.start();
          m.fetch({
              type: 'POST',
              dataType: 'json',
              cache:false, 
              data:$.param({id:id,__RequestVerificationToken:token}),
              success : function(d) {
                    NProgress.done();
                    if (d.get("Attr") == "Ok!") {
                        Utility.AlertV2("check", d.get("Message"), "success");
                        
                        var $sharedid = $('#SharedId').val();
                        
                        var $s = new AddSppd();
                        $s.RenderPegawaiAndBatih($sharedid);
                        Utility.IsLoading("#loading","hide");
                        
                    } else {
                        Utility.AlertV2("exclamation-triangle", d.get("Message"), "error");
                        Utility.IsLoading("#loading","hide");
                    }
                },
                error: function(err) {
                    alert(err.responseText);
                    Utility.IsLoading("#loading","hide");
                }
          });
          
          return this;
        },
        DeleteBatih:function(e) {
          var m = new model_deletebatih.DeleteBatih();  
          var id = $(e.currentTarget).data('id');
          var profile_id = $(e.currentTarget).data('profile');
          NProgress.start();
          var token = $('input[name="__RequestVerificationToken"]').val();
          
          m.fetch({
              type: 'POST',
              dataType: 'json',
              cache:false, 
              data:$.param({id:id,__RequestVerificationToken:token}),
              success : function(d) {
                    NProgress.done();
                    if (d.get("Attr") == "Ok!") {
                        Utility.AlertV2("check", d.get("Message"), "success");
                        var $sharedid = $('#SharedId').val();
                        
                        var $s = new AddSppd();
                        $s.RenderPegawaiAndBatih($sharedid);
                        // $s.RenderBatih(profile_id);
                        
                        // location.reload();
                        Utility.IsLoading("#loading","hide");
                        
                    } else {
                        Utility.AlertV2("exclamation-triangle", d.get("Message"), "error");
                        Utility.IsLoading("#loading","hide");
                    }
                },
                error: function(err) {
                    alert(err.responseText);
                    Utility.IsLoading("#loading","hide");
                }
          });
          
          return this;
        },
        OpenPengikutSppd:function(e) {
            var id = $(e.currentTarget).data('id');
            
            new modal_batih.ModalRenderBatihSppd({id:id}).render();
            return this;
        },
        OpenPegawai: function() {
            if(this.BeforeSend()) {
                new modal_pegawai.ModalRenderPegawaiSppd().render();
            }
            
            return this;
        },
        OpenArsipModal:function() {
            if(this.BeforeSend()) {
                new modal_files.Mx().render();
            }
            return this;
        },
        RemoveFile: function(e) {
            e.preventDefault();
            NProgress.start();
            $('#progress-bar').hide();
            Utility.IsLoading("#loading","show");
            var m = new model_deletefiles.DeleteFile();
            
            var id = $(e.currentTarget).data("id");
            
            m.save({id:id}, {
                type: 'POST',
                dataType: 'json',
                cache:false,
                success : function(d) {
                     NProgress.done();
                     if (d.get("Attr") == "Ok!") {
                        Utility.AlertV2("check", d.get("Message"), "success");
                        
                        var $s = new AddSppd();
                        // render file
                        $s.RenderFiles($("#SharedId").val());
                        Utility.IsLoading("#loading","hide");
                        
                    } else {
                        Utility.AlertV2("exclamation-triangle", d.get("Message"), "error");
                        
                        Utility.IsLoading("#loading","hide");
                    }
                },
                error: function(err) {
                    alert(err.responseText);
                    
                    Utility.IsLoading("#loading","hide");
                }
            });
            
            return this;
        },
        SharedId:function (tipe) {
            NProgress.start();
            var list = new model_sharedid.GetSharedId();
            
            list.fetch({
                data: $.param({ Id: 'GET' }),
                type: 'GET',
                cache:false,
                success: function (data) {
                    NProgress.done();
                    if (tipe == 'SPT') {
                        $('#SharedId').val(data.get("result"));
                    } else {
                         $('#SharedIdSppd').val(data.get("result"));
                    }
                    
                    var $s = new AddSppd()
                    $s.RenderFiles(data.get("result"));
                }
            });
            
            return this;
        },
        RenderFiles: function(id) {
            var templatex = hb.Tem('Naskah/_sppd/_partial/RenderFiles');
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var list = new model_getfiles.GetFiles();

            list.fetch({
                data: $.param({ __RequestVerificationToken: token,SharedId:id }),
                type: 'POST',
                dataType: 'json',
                cache:true,
                success: function (data) {
                    NProgress.done();
                    $('#file-list').html(templatex(data.attributes));
                }
            });
            return this;
        },
        Upload: function () {
            this.name = this.$("#nomor").val();
            
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            
            if (this.name == "") {
                $("#nomer-id").removeClass("has-success");
                $("#nomer-id").addClass("has-error");
                swal("Nomor is empty!");
                $("#nomer").focus();
                Utility.IsLoading("#loading","hide");
                false;
            } else {
                var percent = $('#progress-bar');

                var fileUpload = $('#FormUpload').get(0);

                if (fileUpload.files != '') {

                    var form = $('#FormUpload')[0];
                    var form_data = new FormData(form);
                    $.ajax({
                        xhr: function () {
                            var xhr = new window.XMLHttpRequest();
                            //Upload progress
                            xhr.upload.addEventListener("progress", function (evt) {
                                if (evt.lengthComputable) {
                                    var percentComplete = evt.loaded / evt.total * 100;
                                    percent.html(Math.round(percentComplete) + '%');
                                }
                            }, false);
                            //Download progress
                            xhr.addEventListener("progress", function (evt) {
                                if (evt.lengthComputable) {
                                    var percentComplete = evt.loaded / evt.total * 100;
                                    percent.html(Math.round(percentComplete) + '%');
                                }
                            }, false);
                            return xhr;
                        },
                        url: 'UploadLaporan/UploadFile/',
                        dataType: 'json',
                        cache: false,
                        contentType: false,
                        processData: false,
                        data: form_data,
                        type: 'post',
                        success: function (data) {

                            if (data.Attr == "Ok!") {
                                var percentValue = '100%';
                                percent.html(percentValue);
                                // $("#file-list").append("<li><a href='/Uploads/"+data.Name+"' target='_blank'>" + data.Name + "</a></li>");
                                
                                Utility.IsLoading("#loading", "hide");
                                Utility.prosesLoad("N");
                                Utility.AlertV2("check", data.Message, "success");
                                
                                var $s = new AddSppd();
                                // render file
                                $s.RenderFiles($("#SharedId").val());
                            } else {
                                Utility.AlertV2("exclamation-triangle", data.Message, "error");
                            }

                        },
                        error: function (xhr, ajaxOptions, thrownError) {
                            console.log(xhr.responseText);
                            alert(xhr.responseText);

                            Utility.IsLoading("#loading", "hide");
                            Utility.prosesLoad("N");
                        }
                    });
                }
            }
            
            
            return this;
        },
        CheckName: function(e) {
            this.name = this.$("#nomor").val();
            var token = $('input[name="__RequestVerificationToken"]').val();
            NProgress.start();
            var m = new model_checknomor.CheckNomor();
            var self = this;
            
            
            if (this.name == "") {
                $("#nomor-id").removeClass("has-success");
                $("#nomor-id").addClass("has-error");
                Utility.AlertV2("check","Nomor is empty!","error");
                $("#nomor").focus();
                $("#btnSave").attr("disabled", false);
            } else {
                $("#btnSave").attr("disabled",false);
                m.fetch({
                    data: $.param({name:this.name,__RequestVerificationToken:token,tipe:'sppd'}),
                    type:'POST',
                    success: function(data) {
                        NProgress.done();
                        if (data.get("Attr") == "Ok!") {
                            $('#nomor').val(data.get("Message"));
                        }  
                    }
                
                }); 
            }
            
            return this;       
        },  
        BeforeSend:function() {
            var user = $("#UserId").val();
            var param = {
                Nomor:$("#nomor").val(),
                Perihal:$("#Maksud").val(),
                UserId:user,
                Tanggal:$('#tanggal').val(),
                Email:$('#email').val()
             
            
            };
            
            if (param.Nomor == "") {
                $("#nomor-id").removeClass("has-success");
                $("#nomor-id").addClass("has-error");
                $("#nomor").focus();

                Utility.IsLoading("#loading","hide");
                return false;
            } else if(param.Perihal == "") {
                $("#maksud-id").removeClass("has-success");
                $("#maksud-id").addClass("has-error");
                $("#Maksud").focus();

                Utility.IsLoading("#loading","hide");
                return false;
            } else if (param.Tanggal == "") {
                $("#tanggal-id").removeClass("has-success");
                $("#tanggal-id").addClass("has-error");
                $("#tanggal").focus();

                Utility.IsLoading("#loading","hide");
                return false;
            }
            
            return true;
        },
        saveData : function (event) {
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");
            
            var $options = {};
            var token = $('input[name="__RequestVerificationToken"]').val();
            var user = $("#UserId");
            var SptId = $("#SptId");
            
            
            // Check Form Valid Or Not
            if(this.BeforeSend()) {
                // if (user.val() == "" || user.val() == null) {
                //     $("#user-id").removeClass("has-success");
                //     $("#user-id").addClass("has-error");
                //     $("#UserId").focus();
                    
                //     swal("Disposisi masih kosong! " + user.val() );
                //     Utility.IsLoading("#loading","hide");
                    
                //     return false;
                // } else {
                    
                // }
                if (user.val() == "" || user.val() == null) {
                        var userx = '';
                    } else {
                        var n = user.val();
                        var userx = n.toString();
                    }
                    var param = {
                        Nomor:$("#nomor").val(),
                        Maksud:$("#Maksud").val(),
                        UserId:userx,
                        Keterangan:$("#keterangan").code(),
                        __RequestVerificationToken: token,
                        SharedId:$("#SharedId").val(),
                        TypeDoc:'SPPD',
                        SptId:SptId.val(),
                        NoRekening:$('#rekening').val(),
                        Angkutan:$('#angkutan').val(),
                        Berangkat:$('#berangkat').val(),
                        Tujuan:$('#tujuan').val()
                    };
                    $("#btnSave").attr("disabled",false);
                    
                    $options.url = "Dinas/CreateSppd/";
                    $options.type = "POST";
                    $options.cache = false;
                    $options.data = param;
                    $options.dataType = "json";
                    $options.success = function(d) {
                        if (d.Attr == "Ok!") {
                            Utility.IsLoading("#loading","hide");
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check",d.Message,"success");
                            swal("Ok!",d.Message,"success");
                            
                            // swal({   
                            //     title: "Anda ingin melanjutkan pemesanan tempat Meeting Room?",   
                            //     text: "Jika Iya maka halaman ini akan otomatis mengarahkan anda.",   
                            //     type: "info",      
                            //     showCancelButton: true,   
                            //     confirmButtonColor: "#DD6B55",   
                            //     confirmButtonText: "Yes!",   
                            //     cancelButtonText: "No!",   
                            //     closeOnConfirm: true,   
                            //     closeOnCancel: true
                            // }, 
                            // function(isConfirm) {   
                            //     if (isConfirm) {     
                            //         var $view = new NaskahAdd();
                            //         $view.ModalRoomx(param.Tanggal,param.SharedId); 
                                    
                            //         $view.CheckName(); 
                            //     } else {     
                                    
                            //         var $view = new NaskahAdd();
                            //         $view.SharedId();
                            //         $view.CheckName();  
                            //     } 
                            // });
                            this.s = new AddSppd();
                            this.s.CheckName();
                        } else {
                            // Utility.AlertV2("exclamation-triangle",d.Message,"error");
                            Utility.IsLoading("#loading","hide");
                            swal('Error!',d.Message,"error");
                        }
                        $("#nomor").focus();
                    };
                    $options.error = function(err) {
                        alert(err.responseText);  
                        Utility.prosesLoad("N");
                        Utility.IsLoading("#loading","hide");
                    };
                    $.ajax($options);
                    
            } else {
                swal("Oops...", "Kolom Masih ada yang kosong!", "error");
            }
            
            return this;

        }
      
    });

    return {
        AddSppd: AddSppd
    };
});


