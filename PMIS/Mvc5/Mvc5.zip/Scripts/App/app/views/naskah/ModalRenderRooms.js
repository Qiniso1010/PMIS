define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        summernote          = require('summernote/summernote'),
        ModalView           = require('backbone-modal'),
        moment              = require('moment'),
        
        ModalRenderRooms = Backbone.ModalView.extend({
            title: "<h3>Pilih Meeting Room</h3>",
            events: {
                "hidden.bs.modal": "onHidden",
                "click #btnSelect":"InsertToDokumen"
            },
            InsertToDokumen : function(e) {
                e.preventDefault();
                var id = $(e.currentTarget).data("id");
                var name = $(e.currentTarget).data("name");
                
                $('#NameRoom').val(name);
                $('#IdRoom').val(id);
                
                var tanggal = $("#tanggal").val();
                
                var tgl = moment(tanggal).format('DD-MM-YYYY');
                // alert(tanggal);
                var sharedid = $('#SharedId').val();
                // alert(sharedid);
                
                window.location.href = "#/agenda/meeting-room/weekly/add/"+id+"/"+tgl+"/07:00:00/"+tgl+"/?sid="+sharedid;
                
                // alert(name);
                // alert(id);
                
                
                
                // var list = new models.NaskahTemplateFindByIdModel();
                
                // list.fetch({
                //     data: $.param({ id: id }),
                //     type: 'GET',
                //     cache:false,
                //     success: function (data) {
                //         $('#keterangan').code(data.get("rows").Content);
                //         $('#ImgHeader').attr("src","/Uploads/"+data.get("file").Name);
                //         $('#ImageHeaderPath').val(data.get("file").Name);
                //     }
                // });
                
               
                
                return this;
            },
            postRender: function(tanggal,sharedid) {
                // alert(tanggal);
                // alert(sharedid);
                
                this.Table();
                return this;
            },
            Table:function() {
                var templatex = hb.Tem('Naskah/_partial/RenderRooms');
                
                this.$body.html(templatex());
                
                $('#listing-grid').bootstrapTable({
                    method: 'GET',
                    url: 'Rooms/',
                    cache: true,
                    striped: false,
                    pagination: true,
                    sidePagination: "server",
                    pageSize: 20,
                    pageList: [10, 25, 50, 100, 200],
                    search: true,
                    showColumns: false,
                    showRefresh: true,
                    cardView: false,
                    showToggle: false,
                    showExport: false,
                    exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                    minimumCountColumns: 2,
                    clickToSelect: false,
                    columns: [
                    {
                        field: 'Id',
                        title: 'Item ID',
                        align: 'right',
                        valign: 'bottom',
                        sortable: true,
                        visible: false
                    }, {
                        field: 'NameAndId',
                        title: 'Name',
                        align: 'left',
                        valign: 'middle',
                        sortable: true,
                        formatter: 'Name'
                    }]
                });
            }
        });

    return {
        ModalRenderRooms: ModalRenderRooms
    };
  

});


