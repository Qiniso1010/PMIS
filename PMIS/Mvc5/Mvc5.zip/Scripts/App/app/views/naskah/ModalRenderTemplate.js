define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        summernote          = require('summernote/summernote'),
        ModalView           = require('backbone-modal'),
        filex               = require('app/models/naskah/GetFiles'),
        models              = require('app/models/naskah/NaskahTemplateFindByIdModel'),
        
        ModalRenderTemplate = Backbone.ModalView.extend({
            title: "<h3>Dokumen Template</h3>",
            events: {
                "hidden.bs.modal": "onHidden",
                "click #btnSelect":"InsertToDokumen"
            },
            InsertToDokumen : function(e) {
                e.preventDefault();
                var id = $(e.currentTarget).data("id");
                
                var list = new models.NaskahTemplateFindByIdModel();
                
                list.fetch({
                    data: $.param({ id: id }),
                    type: 'GET',
                    cache:false,
                    success: function (data) {
                        $('#keterangan').code(data.get("rows").Content);
                        $('#ImgHeader').attr("src","/Uploads/"+data.get("file").Name);
                        $('#ImageHeaderPath').val(data.get("file").Name);
                    }
                });
                 
                // var SharedId = $('#SharedId');
                // var Name = $('#nomer');
                // var token = $('input[name="__RequestVerificationToken"]').val();
                 
                // var param = {
                //   id:id,
                //   __RequestVerificationToken:token,
                //   SharedId:SharedId.val(),
                //   Name:Name.val()
                // };
                
                // var $options = {};
                // $options.url = "UploadLaporan/BulkFileFromArsip/";
                // $options.type = "POST";
                // $options.cache = false;
                // $options.data = param;
                // $options.dataType = "json";
                // $options.success = function(d) {
                //     if (d.Attr == "Ok!") {
                //         Utility.IsLoading("#loading","hide");
                //         Utility.prosesLoad("N");
                //         Utility.AlertV2("check",d.Message,"success");
                        
                //         var $s = new Mx();
                //         $s.RenderFiles(SharedId.val());
                        
                //     } else {
                //         Utility.AlertV2("exclamation-triangle",d.Message,"error");
                //     }
                //     $("#nomer").focus();
                // };
                // $options.error = function(err) {
                //     alert(err.responseText);  
                //     Utility.prosesLoad("N");
                //     Utility.IsLoading("#loading","hide");
                // };
                // $.ajax($options);
                
               
                
                return this;
            },
            postRender: function() {
                var templatex = hb.Tem('Naskah/_partial/RenderTemplate');
                
                this.$body.html(templatex());
                
                $('#listing-grid').bootstrapTable({
                    method: 'GET',
                    url: 'TemplateDocs/',
                    cache: true,
                    striped: false,
                    pagination: true,
                    sidePagination: "server",
                    pageSize: 20,
                    pageList: [10, 25, 50, 100, 200],
                    search: true,
                    showColumns: false,
                    showRefresh: true,
                    cardView: false,
                    showToggle: false,
                    showExport: false,
                    exportTypes: ['json', 'xml', 'csv', 'txt', 'sql', 'excel'],
                    minimumCountColumns: 2,
                    clickToSelect: false,
                    columns: [
                    {
                        field: 'Id',
                        title: 'Item ID',
                        align: 'right',
                        valign: 'bottom',
                        sortable: true,
                        visible: false
                    }, {
                        field: 'NameAndId',
                        title: 'Name',
                        align: 'left',
                        valign: 'middle',
                        sortable: true,
                        formatter: 'Name'
                    }]
                });
                return this;
            }
        });

    return {
        ModalRenderTemplate: ModalRenderTemplate
    };
  

});


