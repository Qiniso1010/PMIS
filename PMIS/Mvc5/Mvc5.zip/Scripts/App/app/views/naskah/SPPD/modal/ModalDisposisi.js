define(function (require) {

    "use strict";

    var $                   = require('jquery'),
        Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        Utility             = require('utility'),
        HandlerHelper       = require('handlebarshelper'),
        typeahead           = require('typeahead.bundle.min'),
        tokenfield          = require('bootstrap-tokenfield'),
        ModalView           = require('backbone-modal'),
        select2             = require('select2/select2'),
        
        model_unitlist      = require('app/models/naskah/UnitsList'),
        summernote          = require('summernote/summernote'),
        view_dinasdetails   = require('app/views/naskah/NaskahDetails'),
        
        ModalDisposisi = Backbone.ModalView.extend({
            title: "<h3>Disposisi</h3>",
            buttons: [{
                className: "btn-success btn-custom btn-flat ok",
                label: "Send"
            }],
            events: {
                "click .modal-footer a.ok": "onAction",
                "hidden.bs.modal": "onHidden",
            },
            postRender: function() {
                this.onRender();
                return this;
            },
            onRender: function() {
                var templatex = hb.Tem('Naskah/_partial/UnitListingDetails');
                this.$body.html(templatex());
                
                this.$("#keterangan").summernote({
                    height: 200
                });
                
                this.$('#Unit').select2();
                
                // render email
                this.RenderEmail();
                
                var token = $('input[name="__RequestVerificationToken"]').val();
                var m = new model_unitlist.UnitsList();

                m.fetch({
                    data: $.param({ __RequestVerificationToken: token }),
                    type: 'GET',
                    dataType: 'json',
                    cache:true,
                    success: function (data) {
                        $('#Unit').html(templatex(data.attributes));
                    }
                });

                return this;
            },
            RenderEmail:function() {
                
                this.$("#email").tokenfield({
                    autocomplete: {
                        source: function (request, response) {
                            $.getJSON("Sharing/EmailList/?term=" + request.term, function (data) {
                                response($.map(data, function (value, key) {
                                    return {
                                        label: value.Email,
                                        value: key.Email
                                    };
                                }));
                            });
                        },
                        delay: 100
                    },
                    showAutocompleteOnFocus: true
                });  
                
                return this;
            },
            onAction: function() {
                var $unit = $("#Unit").val();
                var $SharedId = $("#SharedId").val();
                var $Id = $("#id").val();
                var $Pesan = $("#keterangan").code();
                
                var $Email = $('#email');
                
                Utility.IsLoading("#loading","show");
                Utility.prosesLoad("Y");
                
                if ($unit == "" && $Email.val() == "") {
                    swal("Email or Disposisi is empty!");
                    Utility.IsLoading("#loading","hide");
                    
                    return false;
                } else {
                    var token = $('input[name="__RequestVerificationToken"]').val();
                    
                    if ($unit == "" || $unit == null) {
                        var unitx = '';
                    } else {
                        var unitx = $unit.toString();
                    }
                    
                    var param = {
                        DinasId:$Id,
                        SharedId:$SharedId,
                        __RequestVerificationToken:token,
                        UserId:unitx,
                        Keterangan:$Pesan,
                        Email:$Email.val()
                    };
                    
                    var $options = {};
                    
                    $options.url = "Dinas/SendDisposisi/";
                    $options.type = "POST";
                    $options.cache = false;
                    $options.data = param;
                    $options.dataType = "json";
                    
                    $options.success = function(d) {
                        if (d.Attr == "Ok!") {
                            Utility.IsLoading("#loading","hide");
                            Utility.prosesLoad("N");
                            Utility.AlertV2("check",d.Message,"success");
                            
                            var $v = new view_dinasdetails.NaskahDetails();
                            $v.render();
                        } else {
                            Utility.AlertV2("exclamation-triangle",d.Message,"error");
                        }
                    };
                    
                    $options.error = function(err) {
                        alert(err.responseText);  
                        Utility.IsLoading("#loading","hide");
                    };
                    
                    $.ajax($options);
                    
                }
                
                
                return this;
            },
            onHidden: function(e) {
                console.log("Modal hidden");
            },
        });

    return {
        ModalDisposisi: ModalDisposisi
    };
  

});


