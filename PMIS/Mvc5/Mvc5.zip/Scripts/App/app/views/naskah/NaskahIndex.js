define(function(require) {

  "use strict";

    var Handlebars      = require('handlebars'),
        _               = require('underscore'),
        Backbone        = require('backbone'),
        hb              = require('hbtemplate'),
        Utility         = require('utility'),
        NProgress       = require('/Scripts/nprogress.js'),


    NaskahIndexView = Backbone.View.extend({
      template: hb.Tem('Naskah/NaskahIndexView'),
      initialize: function() {
        this.render;
      },
      render: function() {
        this.$el.html(this.template());
        NProgress.done();
        return this;
      }

    });

  return {
    NaskahIndexView: NaskahIndexView
  }



});
