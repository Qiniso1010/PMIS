define(function (require) {

    "use strict";

    var Handlebars          = require('handlebars'),
        _                   = require('underscore'),
        Backbone            = require('backbone'),
        hb                  = require('hbtemplate'),
        models              = require('app/models/systems/GetCurrentPasswordModel'),
        Utility             = require('utility')
        

    return Backbone.View.extend({
        template : hb.Tem('systems/GantiPasswordIndexView'),
        initialize : function() {
            this.render;
        },
        events: {
            "focusout #oldPassword":"checkOldPassword",
            "click #btnSave":"savePassword"
        },
        render: function (key) {
            this.$el.html(this.template(this.model.attributes));
            this.$('#token').val(key);
            $("#h1-header").html("Users <small>Change Password</small>");
            $("#header-page").html("Change Password");
            
            this.$("#btnSave").attr("disabled",true);
            this.$("#oldPassword").focus();
            
            var htm = "";
            htm += "<li class='nav-users'><a href='javascript:;' id='back' onclick='return window.history.back();' role='button'> <i class='fa fa-arrow-left'></i> Back </a></li>";
            $("#navigasi").html(htm);


            $("#subPage").html("Change Your Password");
           
            return this;
        },
        checkOldPassword : function(e) {
            this.oldPassword = this.$("#oldPassword").val();
            this.token = this.$("#token").val();
            
            var currentPassword = new models.GetCurrentPasswordModel({oldPassword : this.oldPassword});
            var self = this;
            
            currentPassword.fetch({
                data: $.param({current:this.oldPassword,token:this.token}) ,
                success: function(data) {
                    if (data.get("status") == "correct") {
                        $("#current-password").removeClass("has-error");
                        $("#current-password").addClass("has-success");
                        Utility.AlertV2("check","current password correct!","info");
                        $("#btnSave").attr("disabled",false);
                    } else {
                        $("#current-password").removeClass("has-success");
                        $("#current-password").addClass("has-error");
                        $("#oldPassword").focus();
                        $("#btnSave").attr("disabled",true);
                        Utility.AlertV2("remove","Invalid current password, please try again","error");
                    }   
                }

            });

            return this;
        },
        savePassword : function(e) {
            Utility.IsLoading("#loading","show");
            Utility.prosesLoad("Y");

            this.oldPassword = this.$("#oldPassword").val();
            this.newPassword = this.$("#newPassword").val();
            this.confPassword = this.$("#confPassword").val();
            this.token = this.$("#token").val();
            
            this.param = {
                'oldPassword':this.oldPassword,
                'newPassword':this.newPassword,
                'confPassword':this.confPassword,
                'token':this.token
            };


            this.jsonData = JSON.stringify(this.param);

            if (this.newPassword == "" || this.newPassword == null) {
                $("#new-password").removeClass("has-success");
                $("#new-password").removeClass("has-error");
                $("#new-password").addClass("has-error");
                Utility.AlertV2("remove","Please enter new password","error");
                Utility.IsLoading("#loading","hide");
            } else if (this.newPassword.length < 5) {
                Utility.AlertV2("remove","Minimum of 5 characters required","error");
                $("#new-password").removeClass("has-success");
                $("#new-password").removeClass("has-error");
                $("#new-password").addClass("has-error");
                $("#newPassword").focus();
                $("#newPassword").addClass("error");
                Utility.IsLoading("#loading","hide");
            } else if (this.confPassword.length < 5) {
                Utility.AlertV2("remove","Minimum of 5 characters required","error");
                Utility.IsLoading("#loading","hide");
                $("#conf-password").removeClass("has-success");
                $("#conf-password").removeClass("has-error");
                $("#conf-password").addClass("has-error");
                $("#confPassword").focus();
                $("#confPassword").addClass("error");
            } else if (this.newPassword != this.confPassword) {
                Utility.AlertV2("remove","New password and its confirmation do not match","error");
                Utility.IsLoading("#loading","hide");
                $("#conf-password").removeClass("has-success");
                $("#conf-password").removeClass("has-error");
                $("#conf-password").addClass("has-error");
                $("#newPassword").focus();
                $("#confPassword").addClass("error");
                $("#newPassword").addClass("error");
            } else {
                $.ajax({
                    url:"users/ChangePassword",
                    cache: false,
                    type: 'POST',
                    data: this.jsonData,
                    dataType: 'json',
                    success: function (d) {
                        if (d.status == "success") {
                            Utility.AlertV2("check","Password success saved","success");
                        } else {
                            Utility.AlertV2("remove","Password fail saved","error");
                        }
                        Utility.prosesLoad("N");
                        Utility.IsLoading("#loading", "hide");
                    }
                });

            }

            
            return this;
        }
      
    });


});