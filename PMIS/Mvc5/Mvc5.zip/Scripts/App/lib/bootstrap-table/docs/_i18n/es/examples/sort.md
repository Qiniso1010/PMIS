# Sort []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/sort.md)

---

## Basic Sort

Use las opciones `sortName`, `sortOrder`, `sortable`, y las opciones de columna `sortable`, `order` para setear el ordenamiento básico de bootstrap table. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/18/embedded/html,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## Custom Sort

Use la opción de columna `sorter` para definir una ordenamiento customizable of bootstrap table. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/19/embedded/html,js,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>