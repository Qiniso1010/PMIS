﻿var DashboardActionView = Handlebars.template({"compiler":[6,">= 2.0.0-beta.1"],"main":function(depth0,helpers,partials,data) {
    return " <section class=\"content-header\">      \r\n    <h1 id=\"h1-header\">\r\n    </h1>\r\n</section>";
},"useData":true});